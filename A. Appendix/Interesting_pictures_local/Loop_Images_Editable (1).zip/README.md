# ACU and VCU simple loop images

#geometry/acu #geometry/vcu #thermal-hardware #cad-extraction #trident

The PNGs are ready to use; SVGs retain editable text and vector outlines. `build_images.py` rebuilds them from `geometry.json` with Python, NumPy, Matplotlib and Shapely. The geometry file contains the projected CAD silhouettes, source filenames, source hashes, object references and VCU jacket cylinder measurements. This style revision uses stronger outlines and inset vector shading to give the pipes a dimensional technical-illustration appearance similar to the supplied TAMU drawing.

## What the colors mean

- Blue is confined to the cooling-jacket shell body. Surrounding pipe, connection ducts, ports, closures, upper hardware and expansion tank are neutral gray.
- Red is confined to the CAD-defined ACU heating-tape body. Its modeled axial length is 1238.25 mm; bare main pipe remains visible at both ends.
- Following the user's request, the VCU lower inclined leg now carries a long, straight red schematic heater. It occupies the central 90% of the CAD straight, leaving exposed gray pipe at both ends. This is an illustrative heater extent, not a newly extracted CAD measurement. No bend or exit pipe is colored red.

## Sources and boundaries

**ACU primary source: Annotated_ACU(2).FCStd — CAD extraction.** Pipe bodies Part__Feature140 and Part__Feature143; main exits Part__Feature141 and Part__Feature142; cooling-jacket shell Part__Feature145; heating tape Part__Feature146. Jacket end closures and connection ducts Part__Feature181, 182, 187, 188, 189 and 190 are gray. Upper hardware is a simplified subset of the saved CAD, not a complete assembly illustration. No sensing locations are asserted in these images.

ACU shell: 1016.0 mm long, OD 158.75 mm. Its centerline endpoints are the named Cooling_Jacket_Start_Point and Cooling_Jacket_End_Point datums. Heater tape: 1238.25 mm long, with approximately 42.943 mm and 31.750 mm of straight pipe between the tape ends and the adjacent straight tangents. Exact coordinates and provenance remain in the ACU Revision B coordinate package.

**VCU primary source: UTDTloopWithOpticsAndHXRev8.STEP — CAD extraction.** This newly uploaded file was loaded and its extracted loop geometry matched the earlier VCU extraction exactly. The shell is `Exhanger(3ftUTDT)/NAUO40/3in3ftCutSS_44635K443`, with 1017.5875 mm axial length and 88.9 mm OD. The native display is rotated so that the expansion tank appears at upper left: page horizontal = -CAD Z, page vertical = CAD Y. The figure preserves projected angles and relative dimensions.

VCU shell axis endpoints, native CAD XYZ in mm:

| Endpoint | X | Y | Z |
| --- | ---: | ---: | ---: |
| Upstream | 629.806632 | 2315.411494 | 2978.615230 |
| Downstream | 629.806632 | 2138.709279 | 1976.487171 |

**Secondary VCU evidence:** UTDTloopWithOpticsAndHX.STEP was inventoried; it does not identify a separate heater body. `tamu_loop_labeled (3).pdf` was visually reviewed as a style/label reference; its whole-leg “Heating Leg” coloring does not establish the shorter heater extent requested here, and its sensor names were not transferred to these CAD models. The native `UT_TRIDENT_loop_As_ConstructedRev.2.SLDDRW` could not be interpreted as an authoritative drawing in this environment; a PDF export may provide the missing heater dimensions.

## VCU illustrative heater convention

The lower inclined CAD straight is about 1532.700 mm long. The illustration uses 5% and 95% axial stations for the red band's two ends, with a display width of 54.8386 mm. These are drawing choices authorized by the user's request for a long straight heater section. They must not replace authoritative heater dimensions in a thermal model or in the existing coordinate package.

## Rendering scope

These are simplified front-elevation CAD silhouettes, not fabrication drawings. Sensor bodies, small fittings and some external hardware are omitted. Matched-panel images use the same vertical physical scale. Projected silhouette simplification is 0.08 mm after tessellation; the figures do not assign manufacturing tolerances or modify the original CAD. The ACU modeled heater join gap remains in source geometry.
