"""Rebuild PNG/SVG figures from extracted CAD silhouettes. Requires matplotlib/numpy."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.path import Path as MPath
from matplotlib.patches import PathPatch
from matplotlib.colors import to_rgb
from shapely.geometry import Polygon
from shapely import make_valid

ROOT=Path(__file__).resolve().parent
D=json.loads((ROOT/'geometry.json').read_text())
GRAY='#adb4ba';EDGE='#20262b';TEXT='#22282d';BLUE='#205c9e';BLUE_FILL='#8aafd3';RED='#b5252c';RED_FILL='#d77777'
plt.rcParams.update({'font.family':'DejaVu Sans','svg.fonttype':'none','font.size':11,'savefig.facecolor':'white'})
def drawpoly(ax,p,fc,ec='none',lw=0,z=2):
        vs=[];cs=[]
        for ring in [p['outer']]+p['holes']:
            vs.extend(ring);cs.extend([MPath.MOVETO]+[MPath.LINETO]*(len(ring)-2)+[MPath.CLOSEPOLY])
        ax.add_patch(PathPatch(MPath(vs,cs),facecolor=fc,edgecolor=ec,lw=lw,joinstyle='round',zorder=z))
def shape(ax,r):
    role=r['role'];fc,ec=(BLUE_FILL,BLUE) if role=='jacket' else (RED_FILL,RED) if role=='heater' else (GRAY,EDGE)
    thermal=role in ['heater','jacket'];z=4 if thermal else 2
    # Inset vector bands add a cylindrical highlight without moving the outer boundary.
    for p in r['polygons']:
        drawpoly(ax,p,fc,ec,1.5 if thermal else 1.15,z)
        poly=make_valid(Polygon(p['outer'],p['holes']))
        depth=16 if role in ['pipe','exit'] else 20 if role=='heater' else 37 if role=='jacket' else 25
        base=np.array(to_rgb(fc));target=np.array(to_rgb('#f6f9fc' if role=='jacket' else '#fff4f2' if role=='heater' else '#ffffff'))
        for i in range(1,19):
            q=poly.buffer(-depth*i/20,join_style='round')
            if q.is_empty:break
            pieces=[q] if q.geom_type=='Polygon' else [v for v in q.geoms if v.geom_type=='Polygon']
            color=base+(target-base)*(1-np.exp(-i/4.5))
            for v in pieces:drawpoly(ax,{'outer':list(v.exterior.coords),'holes':[list(t.coords) for t in v.interiors]},color,z=z+.01*i)
        drawpoly(ax,p,'none',ec,1.5 if thermal else 1.15,z+.3)

def vcu_heater():
    # User-requested long straight schematic heater, centered on the CAD straight.
    a=np.array([-1733.75736958,510.931324291]);b=np.array([-3243.171975336,777.081844361])
    d=b-a;n=np.array([-d[1],d[0]])/np.linalg.norm(d)
    a,b=a+.05*d,a+.95*d;half_width=27.4193
    points=[a-half_width*n,b-half_width*n,b+half_width*n,a+half_width*n,a-half_width*n]
    return {'role':'heater','polygons':[{'outer':[list(p) for p in points],'holes':[]}],'source_object':'User-requested schematic heater; central 90% of Rev8 bottom straight'}
def label(ax,text,point,xytext,ha='left',size=11):
    ax.annotate(text,xy=point,xytext=xytext,ha=ha,va='center',fontsize=size,color=TEXT,
                arrowprops={'arrowstyle':'-','color':EDGE,'lw':.8,'connectionstyle':'arc3,rad=0'},
                bbox={'facecolor':'white','edgecolor':'none','pad':2},zorder=9)
def flow(ax,x,y0,y1):
    ax.annotate('',xy=(x,y1),xytext=(x,y0),arrowprops={'arrowstyle':'-|>','color':EDGE,'lw':1.2},zorder=8)
def panel(ax,key):
    records=D[key]
    for r in sorted(records,key=lambda r:r['role'] in ['heater','jacket']):shape(ax,r)
    if key=='vcu':shape(ax,vcu_heater())
    ax.set_aspect('equal');ax.axis('off');ax.set_ylim(-190,3350)
    if key=='acu':
        ax.set_xlim(-1830,540)
        label(ax,'Upper assembly\n(simplified)',(-1302,3010),(-820,3090),size=10)
        label(ax,'Cooling jacket\n1,016.0 mm',(-550,2365),(-340,2710),ha='center')
        label(ax,'Heater tape\n1,238.25 mm',(-660,943),(-660,640),ha='center')
        label(ax,'TLEP',(-1302,2620),(-1660,2690),size=10)
        label(ax,'BREP',(0,330),(210,330),size=10)
        ax.text(-1620,1650,'Upcomer',rotation=90,ha='center',va='center',color=TEXT)
        ax.text(335,1650,'Downcomer',rotation=90,ha='center',va='center',color=TEXT)
        flow(ax,-1510,1450,1890);flow(ax,220,1890,1450)
    else:
        ax.set_xlim(-3770,-1180)
        label(ax,'Expansion tank',(-3234,3040),(-2720,3070),size=10)
        label(ax,'Cooling jacket\n1,017.59 mm',(-2477,2260),(-2490,2580),ha='center')
        label(ax,'TLEP',(-3234,2690),(-3570,2700),size=10)
        label(ax,'BREP',(-1752,240),(-1500,240),size=10)
        ax.text(-3550,1550,'Upcomer',rotation=90,ha='center',va='center',color=TEXT)
        ax.text(-1420,1490,'Downcomer',rotation=90,ha='center',va='center',color=TEXT)
        flow(ax,-3430,1330,1770);flow(ax,-1540,1770,1330)
        label(ax,'Straight heater section',(-2460,640),(-2520,300),ha='center',size=11)
    ax.set_title(key.upper()+' LOOP',fontsize=21,fontweight='bold',color=TEXT,pad=18,loc='left')

def single(key):
    fig=plt.figure(figsize=(7.2,9.6));ax=fig.add_axes([.045,.095,.91,.81]);panel(ax,key)
    fig.text(.08,.965,'THERMAL HARDWARE & LOOP GEOMETRY',fontsize=9,color=EDGE)
    fig.text(.08,.067,'Blue: cooling jacket.  Red: heater.  Gray: pipe and connections.',fontsize=8,color=EDGE)
    foot='Source: '+D['sources'][key]['file']+' | CAD extraction'
    fig.text(.08,.039,foot,fontsize=8,color=EDGE)
    note='Sensors and small fittings omitted; upper hardware simplified.' if key=='acu' else 'Heater shown schematically as requested; other geometry follows Rev8.'
    fig.text(.08,.021,note,fontsize=8,color=EDGE)
    stem='ACU_Loop_Simple' if key=='acu' else 'VCU_Loop_Simple'
    fig.savefig(ROOT/(stem+'.png'),dpi=250);fig.savefig(ROOT/(stem+'.svg'));plt.close(fig)
for k in ['acu','vcu']:single(k)
fig=plt.figure(figsize=(14.4,9.6))
for i,k in enumerate(['acu','vcu']):
    ax=fig.add_axes([.035+i*.49,.13,.45,.76]);panel(ax,k)
fig.text(.06,.967,'ACU & VCU  |  THERMAL HARDWARE',fontsize=12,color=TEXT,fontweight='bold')
fig.text(.06,.09,'Blue: cooling jackets.   Red: straight heater sections.   Gray: piping and connections.',fontsize=11,color=TEXT)
fig.text(.06,.064,'VCU heater shown schematically; ACU heater follows its modeled tape extent.',fontsize=10,color=EDGE)
fig.text(.06,.034,'CAD sources: Annotated_ACU(2).FCStd  /  UTDTloopWithOpticsAndHXRev8.STEP',fontsize=9,color=EDGE)
fig.text(.06,.014,'Simplified orthographic silhouettes; sensors and small fittings omitted. Panels use the same vertical scale.',fontsize=8,color=EDGE)
fig.savefig(ROOT/'ACU_VCU_Loops.png',dpi=200);fig.savefig(ROOT/'ACU_VCU_Loops.svg');plt.close(fig)
print('Created 3 PNG and 3 editable SVG figures.')
