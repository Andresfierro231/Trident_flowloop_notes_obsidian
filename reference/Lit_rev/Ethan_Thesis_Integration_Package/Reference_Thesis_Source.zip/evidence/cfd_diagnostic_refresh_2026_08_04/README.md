# CFD diagnostic refresh (2026-08-04)

This compact package supports the new Chapter 3 Salt1 coarse-regime row and
the accepted Salt2/Salt4 +/-10% final-ten patch heat partitions.

- `salt14_coarse_upcomer_regime.csv` contains the common-plane Salt1--Salt4
  `Re`, `Ri`, backflow-area, reverse/forward-transport, and alignment values.
- `pm10_patch_heat_terminal10.csv` contains the four thesis heat-table rows.
- `pm10_patch_heat_terminal10_terms.csv` retains terminal-window spread and
  drift for every signed patch class.
- `PROVENANCE_MANIFEST.csv` preserves SHA-256 bindings to the upstream package.

Upstream source:
`repo://ethan_runs/work_products/2026-08/2026-08-04/2026-08-04_csem_missing_cfd_diagnostics_refresh/`.
The Salt1 quantities are single-time coarse diagnostics, and the PM10 heat
partition is a post-grading no-refit join. Neither is a 1D runtime input,
closure fit, ranking result, or pristine prospective validation result.
