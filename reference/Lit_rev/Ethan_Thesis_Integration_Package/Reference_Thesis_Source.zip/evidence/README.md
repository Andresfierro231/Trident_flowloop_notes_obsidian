# Compact Dissertation Evidence

This directory retains only the evidence needed to audit principal manuscript
claims, reproduce the active result/figure checks, and locate the complete
historical support tree.

The full pre-prune evidence tree is preserved at:

`../csem-Masters-dissertation-evidence-archive-2026-07-31-0423ca4/evidence/`

Its source is CSEM commit
`0423ca400367ff721b6389a331058fec5cfedc77`, immediately before evidence-removal
commit `df26c9b`. The archive contains 699 files totaling 241,657,601 bytes.

## Retained locally

- `CLAIM_SOURCE_MANIFEST.csv`: compact claim-to-source and limitation routing.
- `FIGURE_SOURCE_MANIFEST.csv`: active figure outputs, source inputs, hashes,
  and regeneration commands.
- `RETAINED_EVIDENCE_MANIFEST.csv`: deterministic digests for compact package
  directories used by repository QA.
- `UPSTREAM_SOURCE_LOCATOR_MANIFEST.csv`: portable `repo://ethan_runs/...`
  locators, paths resolved from the paper root, and SHA-256 bindings for the
  canonical upstream artifacts.  It contains no machine-specific absolute
  working directory.
- `pressure_demand_ledger_v2_2026_08_03/`: compact pressure-balance and model
  leverage evidence, with LF normalization and its machine-local-to-portable
  rewrite bound in `PORTABLE_COPY_MANIFEST.csv`.
- `heat_path_identifiability_2026_08_03/`: compact nonlinear five-channel
  attribution and practical-rank decisions used by Chapters 4--6.
- `localized_conjugate_model_2026_08_03/`: compact full-insulation conjugate-
  model definition, nominal scores, parameter selections, and validation
  boundary.
- `localized_heat_path_audit_2026_08_10/`: exact compact CFD and localized
  heat ledgers, four-junction extracts, and derived comparisons used to test
  whether improved TP/TW agreement also reproduces the CFD loss partition.
- `mdot_trend_refresh_2026_08_10/`: localized nominal and complete six-case
  mass-flow inputs for the two-panel development/test trend figure.
- `tp_temperature_elevation_2026_08_10/`: compact nominal Salt1--Salt4 TP
  temperatures, TP2-referenced heights, and source hashes for the CFD-versus-
  localized-1D and C5/C6/P1/localized model-progression temperature-elevation
  figures.
- `cfd_mdot_salt1_4_refresh_2026_08_03/`: canonical terminal nominal
  Salt1--Salt4 CFD mass-flow targets and reproducible post-solve, no-refit
  score overlays for the manuscript's nominal comparisons.
- `cfd_diagnostic_refresh_2026_08_04/`: method-matched Salt1--Salt4 coarse
  upcomer diagnostics and final-ten patch heat partitions for the accepted
  Salt2/Salt4 +/-10% continuation cases.
- `s13_uncertainty_disposition_2026_07_31/`: repaired exact-label QOI
  definitions and diagnostic temporal/medium--fine comparisons.  This package
  explicitly keeps formal GCI, QOI release, and coefficient admission closed.
- `source_packages/upcomer_cross_section_salt14_figure/`: audited PDF-native
  Salt1--Salt4 midpoint cross sections and machine-readable metric/status
  provenance used in the lower panel of Figure~3.3.
- `predictive_model_score_release_2026_07_28/`: frozen score tables and sensor
  rows used by scientific-triage and final-readiness checks.
- the exact inputs used by the active manuscript figure-generation scripts,
  including the recirculation source composite and its status record.

Historical writer packets, duplicated presentation assets, broad snapshots,
and superseded diagnostics belong in the sibling archive rather than the active
paper checkout. Do not silently strengthen a claim because its full support is
archived; carry the boundary recorded in `CLAIM_SOURCE_MANIFEST.csv`.

The compact claim-controlling files remain in this checkout so a standalone
paper clone can audit its tables and figures.  Heavy native CFD output and full
work-product trees remain in their source repositories.  Resolve logical
source locators through `UPSTREAM_SOURCE_LOCATOR_MANIFEST.csv`; do not commit a
site-specific `/scratch/...` path as provenance.
