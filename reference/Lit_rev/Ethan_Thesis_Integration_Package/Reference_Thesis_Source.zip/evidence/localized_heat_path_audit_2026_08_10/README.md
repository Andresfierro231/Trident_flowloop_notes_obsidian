# Localized-model heat-path attribution audit

This compact package supports the Chapter 5 comparison between the frozen
localized full-insulation model and the nominal CFD heat-loss partition.  It
answers a narrower question than the temperature and mass-flow scorecards:
after each model has solved, where does its energy ledger say that heat was
removed?

## Controlling inputs

- `cfd_nominal_heat_source_sink_summary.csv` is a byte-exact copy of the
  final-ten-saved-time nominal CFD heat ledger used in Chapter 3.
- `localized_frozen_heat_ledger.csv` is a byte-exact copy of the frozen
  localized-model heat ledger.
- `cfd_junction_split_heat_ledger.csv` concatenates the four physical-junction
  rows from the Salt1 final-ten-time postprocess with the retained Salt2--Salt4
  split ledger.  Source hashes and deterministic selection are recorded in
  `SOURCE_MANIFEST.csv`.
- `localized_junction_region_source.csv` is a deterministic extraction of the
  four predeclared model junction hosts from each of the eight frozen nominal
  localized runs.  It records the source URI and SHA-256 for every raw JSON.
- `SOURCE_MANIFEST.csv` binds all copied and extracted inputs to their upstream
  repository sources.

The analysis is regenerated with:

```bash
python3.11 scripts/analysis/build_localized_heat_path_audit.py
python3.11 scripts/analysis/build_localized_heat_path_audit.py --check
```

`--refresh-inputs` is the explicit import path when the upstream Ethan
work-products are available.  The default build and `--check` use only the
paper-local compact inputs.

## Derived outputs

- `heat_path_case_comparison.csv`: casewise sink magnitudes and normalized
  three-path shares for both localized hydraulic settings.
- `heat_path_summary_metrics.csv`: ranges, mean model/CFD ratios, MAPE, and
  signed bias for each attribution comparison.
- `junction_region_comparison.csv`: Salt1--Salt4 absolute and normalized
  four-junction comparisons.
- `junction_distribution_summary.csv`: mean junction shares and total-
  variation distance.

The reader-facing publication products are
`tables/generated/localized_heat_path_summary.tex` and
`figures/pdf/localized_heat_path_comparison.pdf`; the analysis is in
`reports/LOCALIZED_HEAT_PATH_AUDIT_2026-08-10.md`.  Figure panel (a) normalizes
the three compared sinks independently within each CFD or localized ledger, so
every stack equals 100% and no bar height implies equal absolute heat input or
total removal.  Panel (b) is independently normalized within each system's
junction-region loss.

## Claim boundary

This is a post-solve attribution diagnostic, not strict component validation.
The CFD ledger contains realized wall-flux groups, while the localized model
uses imposed setup sources and its solved boundary circuit.  Its ordinary-
ambient footprint and four selected junction hosts do not exactly match the
CFD patch groups.  The Salt1 split is reduced over the same final ten saved
times as its aggregate; the retained Salt2--Salt4 splits use separate terminal
wall-flux samples.  Consequently, the magnitude and normalized-location
comparisons can reveal compensation and misallocation, but they cannot identify
the fitted residual conductance with a unique hardware component.
