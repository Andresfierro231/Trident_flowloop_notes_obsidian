---
title: Nominal CFD and localized 1D TP temperature-elevation figure data
date: 2026-08-10
status: complete
task: csem-tp-cfd-1d-elevation-figures-2026-08-10
provenance:
  - work_products/2026-08/2026-08-02/2026-08-02_development_aware_conjugate_loop_model/sensor_prediction_errors.csv
  - work_products/2026-07/2026-07-22/2026-07-22_TP_TW_vs_elevation/plot.py
tags: [csem-thesis, TP, CFD, 1D-model, temperature, elevation]
related:
  - scripts/figures/generate_tp_temperature_elevation.py
---

# Nominal CFD and localized 1D TP temperature profiles

This compact package supports temperature-versus-height figures for the six TP
locations in nominal Salt1--Salt4. It compares the CFD target temperatures with
the temperature-leading localized 1D setting reported in the thesis:
`RW_outer_bridge2p500_r0p600__rad__coupled`.

## Data and coordinate rules

- `tp_nominal_cfd_localized_1d.csv` contains 24 rows: four cases by six TP
  sensors.
- CFD and model temperatures are copied without rounding from the nominal
  sensor-score package.
- Heights reuse the earlier temperature-elevation plotting convention. The
  absolute sensor coordinates are shifted so TP2 is 0 m.
- Curves connect TP1 through TP6 in sensor-number order and close the loop from
  TP6 back to TP1. Both the CFD and localized 1D markers carry TP labels because
  height alone does not describe the full loop path.

## Scientific boundary

Salt1--Salt4 were used for model development. The figure shows agreement on
those known CFD cases; it is not a prospective validation figure. The selected
1D row is the low-resistance, temperature-leading localized setting. It is not
the separate CFD-flow-oriented resistance setting.

## Regeneration

From the thesis repository root:

```bash
python3 scripts/figures/generate_tp_temperature_elevation.py
```

The script validates one row per case and TP sensor, checks every stored signed
error, and writes individual Salt1--Salt4 panels plus one combined panel in
PDF, SVG, and PNG formats.

The separate model-progression figure is regenerated with:

```bash
python3 scripts/figures/generate_tp_temperature_elevation_model_forms.py
```

It compares CFD with the complete nominal TP rows for C5, C6, P1, and the
localized 1D model. C5, C6, and P1 come from
`predictive_model_score_release_2026_07_28/all_model_training_sensor_scores.csv`;
the localized row and common CFD targets come from this package's compact CSV.
The legend reports each model's TP RMSE over all four nominal cases. CFD and
localized markers retain color-matched TP labels; the other forms use distinct
colors, markers, and line styles to keep the four-panel layout readable.

Suggested caption: *Nominal CFD and localized 1D bulk-fluid temperatures at
TP1--TP6 versus height above TP2. The localized 1D setting is the
temperature-leading low-resistance model developed using the same Salt1--Salt4
CFD cases. Lines connect sensors in TP-number order, close from TP6 to TP1, and
guide the eye; they do not represent a continuous vertical temperature field.*

Suggested model-progression caption: *Nominal CFD TP temperatures and the C5,
C6, P1, and localized 1D model progression at TP1--TP6 versus height above TP2.
Legend values are TP RMSE over the four nominal development cases. Curves
connect sensors in TP-number order and close from TP6 to TP1 only to guide the
eye; they do not represent continuous vertical temperature fields. C5, C6, and
P1 use model-development compensation, and the localized parameters were also
selected using the nominal cases; this is not prospective validation.*
