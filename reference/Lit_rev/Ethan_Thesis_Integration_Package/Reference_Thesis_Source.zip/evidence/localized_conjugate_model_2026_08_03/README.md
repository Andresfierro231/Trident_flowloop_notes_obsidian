---
provenance:
  - repo://ethan_runs/work_products/2026-07/2026-07-31/2026-07-31_localized_two_coordinate_predictive_model
tags: [evidence, conjugate-wall, full-insulation, model-development]
related:
  - chapters/04_reduced_model_methodology.tex
  - chapters/05_model_assessment_and_interpretation.tex
  - chapters/06_conclusions.tex
task: TODO-CSEM-HEATPATH-LOCALIZED-MODEL-INTEGRATION-2026-08-03
date: 2026-08-03
type: evidence_readme
status: complete
---
# Localized full-insulation conjugate-model evidence

This compact package controls the dissertation's localized conjugate-model
definition, nominal Salt1--Salt4 scores, parameter-selection history, and
validation boundary.  It retains the complete thermal and hydraulic score
tables, frozen selections, numerical policy, high-power disposition, and
summary while leaving solved states and implementation source in the Ethan
workspace.

The 2.5-W/K residual bridge was selected on nominal TP/TW and is neither a
measured conductance nor uniquely assigned to physical hardware.  The 0.60 and
1.10 resistance multipliers belong to separate experimental- and CFD-flow
objectives.  High-power rows remain stress tests because stationarity,
same-QOI TP/TW, uncertainty, and the declared energy gate are incomplete.
Nothing in this package establishes prospective validation or a universal
coefficient set.

`SOURCE_MANIFEST.csv` binds every compact file to its unchanged upstream
artifact and SHA-256 digest.
