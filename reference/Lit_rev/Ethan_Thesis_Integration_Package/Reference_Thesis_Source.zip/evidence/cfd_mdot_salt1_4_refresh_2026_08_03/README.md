---
title: Canonical Salt1--Salt4 CFD mass-flow target refresh
date: 2026-08-03
status: active
provenance:
  - repo://ethan_runs/work_products/2026-07/2026-07-28/2026-07-28_csem_cfd_run_matrix_release/
  - repo://ethan_runs/work_products/2026-07/2026-07-31/2026-07-31_two_state_upcomer_prototype/
tags: [cfd, mass-flow, salt1, terminal-window, no-refit, retrospective]
related:
  - evidence/predictive_model_score_release_2026_07_28/
  - evidence/two_state_paper_integration_2026_08_02/
  - evidence/localized_conjugate_model_2026_08_03/
---

# Canonical Salt1--Salt4 CFD mass-flow target refresh

This overlay corrects a stale target-coverage statement in the manuscript.  A
terminal Salt1 Jin-continuation mass-flow reference is available and was
already classified as nominal training evidence by the July 28 CFD run-matrix
release.  The older score builders inherited a July 16 target dictionary that
contained only Salt2--Salt4; that omission was a data-contract limitation, not
absence of Salt1 CFD output.

`canonical_cfd_mdot_targets.csv` freezes one consistent nominal scoring basis:
the magnitude of the representative lower/heater monitor mean over each
canonical 300-s terminal window.  Native monitor signs are negative because
of the declared face orientation; the positive magnitudes are compared with
the positive 1D circulation convention.  All four rows contain 301 samples
and pass the retained-window stationarity screen.

`build_refresh.py` keeps every previously completed model prediction fixed and
recomputes only the post-solve target join and aggregate CFD mass-flow MAPE.
No solver is rerun, no coefficient is refitted, and no candidate is reselected.
The refreshed rows are therefore retrospective diagnostic evaluations, not
pristine validation.  In particular, P2-CFD's 0.80 resistance multiplier was
historically selected using the older Salt2--Salt4 residual set; its refreshed
Salt1--Salt4 score does not alter that calibration history.

The overlay also preserves the principal scientific dispositions:

- P2-CFD remains the lowest nominal CFD-mass-flow-error candidate.
- Area-aware upcomer momentum remains better than the P1 baseline, while the
  conservative exchange state still provides no thermal gain over that host.
- The localized 1.10 resistance row remains the lowest CFD-flow comparator,
  but it is target-informed and its fitted thermal bridge is not physical
  validation.
- The all-channel heat-path intervention still does not reconcile circulation
  and remains ineligible for predictive ranking.

Run `python3 evidence/cfd_mdot_salt1_4_refresh_2026_08_03/build_refresh.py` from
the dissertation root to reproduce the CSV and JSON products.  Exact source
paths and hashes are recorded in `SOURCE_MANIFEST.csv`.
