#!/usr/bin/env python3
"""Build the no-refit Salt1--Salt4 CFD mass-flow score refresh.

The model predictions are immutable inputs from previously completed packages.
Only the post-solve target join and aggregate CFD mass-flow MAPE are refreshed.
"""

from __future__ import annotations

import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path
from typing import Any


HERE = Path(__file__).resolve().parent
PAPER = HERE.parents[1]
ETHAN = PAPER.parents[2] / "ethan_runs"

OSCILLATION = (
    ETHAN
    / "work_products/2026-07/2026-07-15/2026-07-15_salt_oscillation_expanded_case_set"
    / "oscillation_stats.csv"
)
STEADY = (
    ETHAN
    / "work_products/2026-07/2026-07-09/2026-07-09_timeseries_steadystate"
    / "steady_state_summary.csv"
)
PREDICTIVE = PAPER / "evidence/predictive_model_score_release_2026_07_28"
TWO_STATE = PAPER / "evidence/two_state_paper_integration_2026_08_02"
TWO_STATE_PHYSICS = (
    ETHAN
    / "work_products/2026-07/2026-07-31/2026-07-31_two_state_upcomer_prototype"
    / "physics_campaign/audience_case_tp_tw_mdot_scorecard.csv"
)
LOCALIZED = (
    ETHAN
    / "work_products/2026-07/2026-07-31/2026-07-31_localized_two_coordinate_predictive_model"
)
HEAT_PATH = (
    ETHAN
    / "work_products/2026-07/2026-07-31/2026-07-31_heat_path_counterfactual_attribution"
    / "diagnostic_case_scorecard.csv"
)
FACTORIAL = (
    ETHAN
    / "work_products/2026-07/2026-07-28/2026-07-28_f3_eta_junction_mdot_factorial"
    / "case_scorecard.csv"
)

TARGET_WINDOWS = {
    "salt_2": (7615.0, 7915.0),
    "salt_3": (7318.0, 7618.0),
    "salt_4": (9700.0, 10000.0),
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    if not rows:
        raise ValueError(f"refusing to write empty table: {path}")
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def ape(prediction: float, target: float) -> float:
    return 100.0 * abs(prediction - target) / target


def target_rows() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    salt1 = [
        row
        for row in read_csv(OSCILLATION)
        if row["case_key"] == "salt1_nominal"
        and row["group"] == "mdot"
        and row["series_role"] == "representative"
    ]
    if len(salt1) != 1:
        raise ValueError(f"expected one Salt1 representative mass-flow row, found {len(salt1)}")
    row = salt1[0]
    rows.append(
        {
            "case_id": "salt_1",
            "case_label": "Salt1 nominal",
            "signed_cfd_mdot_mean_kg_s": float(row["osc_mean"]),
            "cfd_mdot_target_magnitude_kg_s": abs(float(row["osc_mean"])),
            "representative_series": row["series_name"],
            "sample_count": int(row["n_window"]),
            "window_start_s": float(row["t_start"]),
            "window_end_s": float(row["t_end"]),
            "corrected_sem_kg_s": float(row["unc_sem_corrected"]),
            "relative_drift": float(row["rel_drift_over_window"]),
            "stationarity_verdict": row["verdict"],
            "source_path": OSCILLATION.relative_to(ETHAN).as_posix(),
        }
    )
    steady = read_csv(STEADY)
    for case_id, fluid in (("salt_2", "salt2"), ("salt_3", "salt3"), ("salt_4", "salt4")):
        start, end = TARGET_WINDOWS[case_id]
        matches = [
            row
            for row in steady
            if row["fluid"] == fluid
            and row["group"] == "mdot"
            and float(row["t_start"]) == start
            and float(row["t_end"]) == end
        ]
        if len(matches) != 1:
            raise ValueError(f"expected one {case_id} terminal mass-flow row, found {len(matches)}")
        row = matches[0]
        rows.append(
            {
                "case_id": case_id,
                "case_label": case_id.replace("salt_", "Salt") + " nominal",
                "signed_cfd_mdot_mean_kg_s": float(row["osc_mean"]),
                "cfd_mdot_target_magnitude_kg_s": abs(float(row["osc_mean"])),
                "representative_series": row["series"],
                "sample_count": int(row["n_window"]),
                "window_start_s": float(row["t_start"]),
                "window_end_s": float(row["t_end"]),
                "corrected_sem_kg_s": float(row["unc_sem_corrected"]),
                "relative_drift": float(row["rel_drift_over_window"]),
                "stationarity_verdict": row["verdict"],
                "source_path": STEADY.relative_to(ETHAN).as_posix(),
            }
        )
    return rows


def target_map(rows: list[dict[str, Any]]) -> dict[str, float]:
    return {row["case_id"]: float(row["cfd_mdot_target_magnitude_kg_s"]) for row in rows}


def predictive_scores(targets: dict[str, float]) -> list[dict[str, Any]]:
    cases = read_csv(PREDICTIVE / "all_model_training_case_scores.csv")
    old_scores = read_csv(PREDICTIVE / "all_model_training_scorecard.csv")
    grouped: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in cases:
        grouped[row["candidate_id"]].append(row)
    output = []
    for row in old_scores:
        model_rows = grouped[row["model_id"]]
        errors = [
            ape(float(item["predicted_mdot_kg_s"]), targets[item["case_id"]])
            for item in model_rows
        ]
        output.append(
            {
                "publication_id": row["publication_id"],
                "model_id": row["model_id"],
                "tp_rows": row["tp_rows"],
                "tw_rows": row["tw_rows"],
                "tp_rmse_K": row["tp_rmse_K"],
                "tw_rmse_K": row["tw_rmse_K"],
                "balanced_tp_tw_rmse_K": row["balanced_tp_tw_rmse_K"],
                "experimental_mdot_mape_pct": row["experimental_mdot_mape_pct"],
                "cfd_mdot_mape_pct_salt1_4": sum(errors) / len(errors),
                "root_acceptance_fraction": row["root_acceptance_fraction"],
                "score_policy": row["score_policy"],
                "protected_target_used": row["protected_target_used"],
                "refresh_disposition": "post_solve_no_refit_retrospective_target_refresh",
            }
        )
    return output


def two_state_scores(targets: dict[str, float]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    cases = read_csv(TWO_STATE / "audience_case_tp_tw_mdot_scorecard.csv")
    nested = [row for row in read_csv(TWO_STATE_PHYSICS) if row["candidate_id"] == "C_r020_a150"]
    for row in nested:
        row["model_id"] = row["candidate_id"]
        row["role"] = row["role"]
    combined = cases + nested
    case_output = []
    grouped: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in combined:
        grouped[row["model_id"]].append(row)
        target = targets[row["case_id"]]
        prediction = float(row["predicted_mdot_kg_s"])
        case_output.append(
            {
                "model_id": row["model_id"],
                "role": row["role"],
                "case_id": row["case_id"],
                "tp_rmse_K": row["tp_rmse_K"],
                "tw_rmse_K": row["tw_rmse_K"],
                "predicted_mdot_kg_s": prediction,
                "experimental_mdot_target_kg_s": row["experimental_mdot_target_kg_s"],
                "experimental_mdot_error_pct": row["experimental_mdot_error_pct"],
                "cfd_mdot_target_kg_s": target,
                "cfd_mdot_error_pct": 100.0 * (prediction - target) / target,
                "protected_target_used": False,
            }
        )
    old_models = {
        row["model_id"]: row for row in read_csv(TWO_STATE / "mechanism_model_comparison.csv")
    }
    model_output = []
    for model_id, model_rows in sorted(grouped.items()):
        if model_id not in old_models:
            continue
        old = old_models[model_id]
        errors = [
            ape(float(row["predicted_mdot_kg_s"]), targets[row["case_id"]])
            for row in model_rows
        ]
        model_output.append(
            {
                "model_id": model_id,
                "interpretation": old["interpretation"],
                "tp_rmse_K": old["tp_rmse_K"],
                "tw_rmse_K": old["tw_rmse_K"],
                "experimental_mdot_mape_pct": old["experimental_mdot_mape_pct"],
                "cfd_mdot_mape_pct_salt1_4": sum(errors) / len(errors),
                "complete_case_count": len(model_rows),
                "physical_admission": old["physical_admission"],
                "refresh_disposition": "post_solve_no_refit_retrospective_target_refresh",
            }
        )
    return case_output, model_output


def localized_scores(targets: dict[str, float]) -> list[dict[str, Any]]:
    old = {
        row["candidate_id"]: row for row in read_csv(LOCALIZED / "hydraulic_resistance_scores.csv")
    }
    candidates = (
        "RW_outer_bridge2p500_r0p600__rad__coupled",
        "RW_outer_bridge2p500_r1p100__rad__coupled",
    )
    output = []
    for candidate_id in candidates:
        errors = []
        for case_id, target in targets.items():
            payload = json.loads(
                (LOCALIZED / "raw_runs" / f"{candidate_id}__{case_id}.json").read_text(encoding="utf-8")
            )
            errors.append(ape(float(payload["runtime"]["mdot_kg_s"]), target))
        row = old[candidate_id]
        output.append(
            {
                "candidate_id": candidate_id,
                "major_loss_multiplier": row["major_loss_multiplier"],
                "balanced_tp_tw_rmse_K": row["balanced_tp_tw_rmse_K"],
                "experimental_mdot_mape_pct": row["experimental_mdot_mape_pct"],
                "cfd_mdot_mape_pct_salt1_4": sum(errors) / len(errors),
                "case_count": len(errors),
                "protected_target_used": False,
                "refresh_disposition": "post_solve_no_refit_retrospective_target_refresh",
            }
        )
    return output


def heat_path_scores(targets: dict[str, float]) -> list[dict[str, Any]]:
    rows = read_csv(HEAT_PATH)
    states = (
        "baseline",
        "plus__heater__cooler__ordinary_ambient__test_section__junction",
    )
    output = []
    for state in states:
        selected = [
            row for row in rows if row["mode"] == "fully_coupled" and row["state_id"] == state
        ]
        errors = [
            ape(float(row["predicted_mdot_kg_s"]), targets[row["case_id"]])
            for row in selected
        ]
        output.append(
            {
                "state_id": state,
                "case_count": len(selected),
                "cfd_mdot_mape_pct_salt1_4": sum(errors) / len(errors),
                "predictive_ranking_eligible": False,
                "refresh_disposition": "post_solve_no_refit_retrospective_target_refresh",
            }
        )
    return output


def factorial_scores(targets: dict[str, float]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    grouped: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in read_csv(FACTORIAL):
        grouped[row["candidate_id"]].append(row)
    scores = {
        candidate: sum(
            ape(float(row["predicted_mdot_kg_s"]), targets[row["case_id"]]) for row in rows
        )
        / len(rows)
        for candidate, rows in grouped.items()
    }
    cells = {
        (0, 0): scores["C2_passive_h2_f3_friction"],
        (1, 0): scores["C5_f3_eta_with_junction"],
        (0, 1): scores["C6_f3_no_junction_eta1"],
        (1, 1): scores["C4_passive_h2_combined"],
    }
    eta = 0.5 * ((cells[(1, 0)] - cells[(0, 0)]) + (cells[(1, 1)] - cells[(0, 1)]))
    no_junction = 0.5 * (
        (cells[(0, 1)] - cells[(0, 0)]) + (cells[(1, 1)] - cells[(1, 0)])
    )
    interaction = (cells[(1, 1)] - cells[(0, 1)]) - (cells[(1, 0)] - cells[(0, 0)])
    score_rows = [
        {
            "candidate_id": candidate,
            "cfd_mdot_mape_pct_salt1_4": value,
            "refresh_disposition": "post_solve_no_refit_retrospective_target_refresh",
        }
        for candidate, value in sorted(scores.items())
    ]
    effect_rows = [
        {"effect": "heater_eta_on_average", "delta_cfd_mdot_mape_pct_salt1_4": eta},
        {"effect": "no_junction_average", "delta_cfd_mdot_mape_pct_salt1_4": no_junction},
        {"effect": "eta_by_no_junction_interaction", "delta_cfd_mdot_mape_pct_salt1_4": interaction},
    ]
    return score_rows, effect_rows


def main() -> None:
    targets_rows = target_rows()
    targets = target_map(targets_rows)
    predictive = predictive_scores(targets)
    two_state_cases, two_state_models = two_state_scores(targets)
    localized = localized_scores(targets)
    heat_path = heat_path_scores(targets)
    factorial, factorial_effects = factorial_scores(targets)
    outputs = {
        "canonical_cfd_mdot_targets.csv": targets_rows,
        "predictive_model_scorecard_salt1_4.csv": predictive,
        "two_state_case_scorecard_salt1_4.csv": two_state_cases,
        "two_state_model_scorecard_salt1_4.csv": two_state_models,
        "localized_model_scorecard_salt1_4.csv": localized,
        "heat_path_scorecard_salt1_4.csv": heat_path,
        "factorial_model_scorecard_salt1_4.csv": factorial,
        "factorial_effects_salt1_4.csv": factorial_effects,
    }
    for filename, rows in outputs.items():
        write_csv(HERE / filename, rows)
    source_paths = [
        OSCILLATION,
        STEADY,
        PREDICTIVE / "all_model_training_case_scores.csv",
        PREDICTIVE / "all_model_training_scorecard.csv",
        TWO_STATE / "audience_case_tp_tw_mdot_scorecard.csv",
        TWO_STATE / "mechanism_model_comparison.csv",
        TWO_STATE_PHYSICS,
        LOCALIZED / "hydraulic_resistance_scores.csv",
        LOCALIZED / "hydraulic_run_matrix.csv",
        HEAT_PATH,
        FACTORIAL,
    ]
    write_csv(
        HERE / "SOURCE_MANIFEST.csv",
        [
            {
                "source_path": path.relative_to(PAPER).as_posix()
                if path.is_relative_to(PAPER)
                else "repo://ethan_runs/" + path.relative_to(ETHAN).as_posix(),
                "sha256": sha256(path),
                "mutation": "read_only",
            }
            for path in source_paths
        ],
    )
    summary = {
        "schema_version": 1,
        "target_population": "nominal Salt1--Salt4 canonical terminal-window CFD mass flow",
        "target_sign_policy": "compare positive model circulation to magnitude of signed CFD monitor mean",
        "join_policy": "post-solve no-refit retrospective diagnostic",
        "target_case_count": 4,
        "predictive_model_scores": {
            row["publication_id"]: row["cfd_mdot_mape_pct_salt1_4"] for row in predictive
        },
        "two_state_model_scores": {
            row["model_id"]: row["cfd_mdot_mape_pct_salt1_4"] for row in two_state_models
        },
        "localized_model_scores": {
            row["candidate_id"]: row["cfd_mdot_mape_pct_salt1_4"] for row in localized
        },
        "heat_path_scores": {
            row["state_id"]: row["cfd_mdot_mape_pct_salt1_4"] for row in heat_path
        },
        "protected_target_used": False,
        "model_refit_performed": False,
        "physical_validation_claim_allowed": False,
    }
    (HERE / "summary.json").write_text(json.dumps(summary, indent=2, sort_keys=True) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
