---
provenance:
  - repo://ethan_runs/work_products/2026-07/2026-07-31/2026-07-31_heat_path_counterfactual_attribution
  - repo://ethan_runs/work_products/2026-07/2026-07-31/2026-07-31_closure_ablation_identifiability
tags: [evidence, heat-path, nonlinear-attribution, identifiability]
related:
  - chapters/04_reduced_model_methodology.tex
  - chapters/05_model_assessment_and_interpretation.tex
task: TODO-CSEM-HEATPATH-LOCALIZED-MODEL-INTEGRATION-2026-08-03
date: 2026-08-03
type: evidence_readme
status: complete
---
# Nonlinear heat-path and practical-identifiability evidence

This compact package controls the dissertation's five-channel counterfactual
and ten-coordinate local-identifiability claims.  The full Ethan packages
retain raw solved states, validity ledgers, higher-order interaction tables,
figures, and reproduction scripts; this paper copy retains only the result and
decision tables needed for standalone claim audit.

The 256 channel-intervention calculations are diagnostic.  Their replacement
operators are anchored to CFD heat-channel totals and are excluded from
predictive ranking.  The reported rank is practical and local to the declared
Salt1--Salt4 cases, normalization, parameter scales, perturbations, sensor
policy, and 0.05 relative singular-value threshold.  It is not structural
identifiability and does not physically admit a closure.

`SOURCE_MANIFEST.csv` binds every compact file to its unchanged upstream
artifact and SHA-256 digest.
