# Implementation-to-thesis alignment corrections

These corrections distinguish the current operational code from older method
summaries and from conceptual model locations in Chapter 5. They do not require
an immediate manuscript edit, but a writer should apply them when the solver
method is next revised.

## 1. Parent-segment count

The code has 12 parent segments. One current evidence-release summary says
"13" and then lists 12 names. Use 12.

Authority: `geometry.py::_base_segments_cache`.

## 2. Actual state versus conceptual state vector

The code's `SegmentState` stores bulk `T_in`, `T_out`, and `T_avg`, heat
ledgers, resistance diagnostics, algebraic wall/surface estimates, and optional
exchange ledgers. It does not store per-segment inlet/outlet static pressure.

Chapter 5's vector containing `p_s,in` and `p_s,out` is therefore a conceptual
future model location, not the current Python state object.

Authority: `solver.py::SegmentState`.

## 3. Wall model

The ordinary solver does not integrate a wall energy equation, axial wall
conduction, wall storage, or separate wall degrees of freedom. It evaluates a
steady radial resistance path and derives `T_pipe_outer_wall_K` and
`T_outer_surface_K` algebraically.

Preferred wording: "steady 1D bulk-fluid model with algebraic radial
wall/insulation resistance networks."

Authority:
`solver.py::wall_and_insulation_resistances_per_length`.

## 4. Active friction dispatcher

The active default pressure form is `friction_closures.py::dp_F1`, which uses
`64/Re` without a Reynolds-number branch. The standalone
`solver.py::friction_factor` helper contains `0.3164 Re^-0.25` above 2300 but
has no call sites in the current solver.

Do not describe the active default pressure loss as switching to Blasius.

## 5. Internal heat-transfer branch

The internal Nusselt helper does switch at `Re=2300`: below the threshold it
uses the maximum of 4.36 and the developing laminar relation; above it uses
Dittus--Boelter. This branch is used in passive-wall and HX resistance
calculations.

Authority: `solver.py::internal_nusselt`.

## 6. HX flow arrangement flag

`air_counterflow` is a scenario/config/reporting field, but the core
`_hx_airside_transfer` function always evaluates the counterflow effectiveness
relation. A false flag currently does not select a parallel-flow formula.

## 7. Outer-iteration count field

`max_outer_iterations` is serialized but is not consumed by the core solver.
The actual hard-coded iteration counts are:

- six updates for passive outer-surface coefficients;
- ten fixed-point updates per segment;
- up to three temperature-range expansions;
- 25 temperature-root bisection steps; and
- 25 mass-flow-root bisection steps.

## 8. Root fallback

When a bracket is absent, the code retains the smallest-residual scan point for
diagnostics but rejects it. Do not imply that the fallback becomes an accepted
solution.

## 9. Optional hooks versus baseline physics

UMX1, AMX1, TSWFC2, F4--F6, profile-descriptor modifiers, explicit external
boundary tables, and 3D prescribed source/loss imports are real code paths.
They are not all active at once and are not implied by the baseline solver.
Their status must travel with any result.

## 10. Diagnostic segment Richardson number

`compute_segment_ri` is a post-solve diagnostic, not an input to the default
F1 pressure balance. It hard-codes the Jin density slope when estimating beta
and estimates wall-to-bulk temperature from a reduced heat ledger. It should
not be described as a general self-consistent mixed-convection closure for
every property set.

## 11. Numerical acceptance versus scientific admission

`accepted_for_validation=True` means the root, residual, search-bound, and
property checks passed for the selected model. It does not admit a closure,
freeze a candidate, or establish predictive validation. The policy metadata
continues to mark ordinary outputs as pending revalidation.
