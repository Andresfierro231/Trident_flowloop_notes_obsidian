---
provenance:
  - ../../../cfd-modeling-tools/tamu_first_order_model/Fluid/tamu_loop_model_v2/solver.py
  - ../../../cfd-modeling-tools/tamu_first_order_model/Fluid/tamu_loop_model_v2/geometry.py
  - ../../../cfd-modeling-tools/tamu_first_order_model/Fluid/tamu_loop_model_v2/materials.py
  - ../../../cfd-modeling-tools/tamu_first_order_model/Fluid/tamu_loop_model_v2/friction_closures.py
  - ../../../cfd-modeling-tools/tamu_first_order_model/Fluid/tamu_loop_model_v2/config_loader.py
  - ../../../cfd-modeling-tools/tamu_first_order_model/Fluid/tamu_loop_model_v2/external_boundary.py
tags: [thesis-evidence, one-dimensional-solver, thermo-hydraulics, methods]
related:
  - evidence/governing_equations_glossary/README.md
  - evidence/writer_control_surface/README.md
  - evidence/one_d_physics_solver_description_2026_07_28/thesis_alignment_corrections.md
task: csem-latex-evidence-1d-physics-solver-description-2026-07-28
date: 2026-07-28
role: Writer
status: current
---

# Complete implementation description of the predictive 1D physics solver

## Purpose and authority

This packet describes the predictive `Fluid/tamu_loop_model_v2` solver as it is
implemented on 2026-07-28. It is a writer-facing implementation record, not
thesis prose and not evidence that every optional closure is scientifically
admitted.

The description was audited against the live source tree at
`../../../cfd-modeling-tools` relative to the thesis-repository root, whose
recorded Git `HEAD` was
`34af0397beadcd00e7d1f6520f01ff3946209aa9`. Several solver files had
uncommitted research changes, so the file hashes in
`source_snapshot_manifest.csv`, rather than the commit alone, identify the
exact implementation described here.

The primary authority is the code. Earlier method summaries and thesis text
were used only as cross-checks. Where they disagree with the current code, the
implementation distinctions in `thesis_alignment_corrections.md` control this
packet.

## One-sentence description

The solver is a deterministic, steady, single-phase, one-dimensional closed-loop
thermo-hydraulic model that finds a constant loop mass flow and a periodic
bulk-temperature field by nesting a temperature-periodicity solve inside a
buoyancy-versus-loss pressure-root solve.

It is not a transient solver, a time integrator, a CFD field solver, or an
experimental data-assimilation method.

## What is prescribed, what is solved, and what is kept out

For a case, the forward solver receives:

- loop geometry and material identities;
- working-fluid and property-package identity;
- heater power and test-section electrical power;
- ambient temperature;
- insulation and radiation settings;
- cooling-air inlet temperature and volumetric flow;
- a selected cooling-jacket mode;
- a hydraulic-loss configuration; and
- any explicitly selected, runtime-legal optional closure inputs.

It solves for:

- one steady mass flow rate, \(\dot m\), around the closed loop;
- the periodic bulk-fluid temperature at the loop start, located at TP3;
- inlet, outlet, and average bulk temperature for every numerical segment;
- the loop buoyancy pressure;
- the distributed and lumped hydraulic loss;
- ambient heat loss by segment;
- cooling-jacket duty and air outlet temperature in predictive HX mode;
- algebraic pipe-wall and outer-surface temperature estimates;
- TP and TW predictions at the sensor coordinates; and
- detailed source, sink, resistance, closure, root, and validity ledgers.

Measured TP/TW temperatures, measured mass flow, measured velocity, measured
cooler duty, and measured air outlet temperature are loaded into a separate
`ValidationRecord`. They are merged only by the reporting layer after the
forward solve. They are not ordinary inputs to the active predictive path.

Diagnostic modes can import prescribed 3D source or loss profiles, but those
modes are not equivalent to a predictive setup-only solve and must retain their
diagnostic labels.

## Physical and numerical model in compact form

The loop is reduced to an ordered set of one-dimensional control volumes. A
single \(\dot m\) passes through every ordinary segment. For numerical segment
\(i\), the implemented temperature update is

\[
T_{i,\mathrm{out}}
=T_{i,\mathrm{in}}
+\frac{
Q_{i,\mathrm{source}}
+Q_{i,\mathrm{axial\ mix}}
-Q_{i,\mathrm{HX}}
-Q_{i,\mathrm{ambient}}
-Q_{i,\mathrm{main\rightarrow reservoir}}
}{
\dot m\,c_p(T_{i,\mathrm{avg}})
}.
\]

The signs above match the code: source and conservative mixing gain are
positive into the main stream; HX, ambient, and main-to-reservoir exchange are
positive removal magnitudes.

For a trial \(\dot m\), the solver chooses the loop-start temperature \(T_0\)
so that

\[
\mathcal R_T(T_0;\dot m)
=T_{\mathrm{end}}-T_0=0.
\]

The resulting temperature and density field gives the buoyancy pressure

\[
\Delta p_b
=\sum_i-\rho(T_{i,\mathrm{avg}})\,g\,\Delta y_i.
\]

Hydraulic losses are evaluated from distributed friction, localized
coefficients, development-reset coefficients, four default 90-degree turns,
four default 20-degree turns, and the test-section contraction/expansion when
enabled. The outer residual is

\[
\mathcal R_p(\dot m)
=\Delta p_{\mathrm{loss}}-\Delta p_b.
\]

The accepted mass flow is a bracketed root of \(\mathcal R_p=0\), subject to
the additional acceptance checks described below.

## Geometry and direction of the march

The physical parent geometry contains 12 parent segments, not 13. Flow order is:

| Order | Parent segment | Nominal length | Role |
|---:|---|---:|---|
| 1 | `left_lower_vertical` | 14.34 in | lower upcomer |
| 2 | `test_section` | 7.32 in | bare quartz test section |
| 3 | `left_upper_vertical` | 14.34 in | upper upcomer |
| 4 | `top_horizontal_inlet` | 1 in | top connector |
| 5 | `cooled_incline_pre_hx` | 12 in | cooler incline before jacket |
| 6 | `cooled_incline_hx_active` | 12 in | active air cooling jacket |
| 7 | `cooled_incline_post_hx` | 12 in | cooler incline after jacket |
| 8 | `top_horizontal_exit` | 1 in | connector to downcomer |
| 9 | `right_vertical` | 36 in | downcomer |
| 10 | `bottom_horizontal_inlet` | 1 in | connector to heater |
| 11 | `heated_incline` | 36 in | full-wrap heater tape |
| 12 | `bottom_horizontal_exit` | 1 in | connector back to TP3 |

The ordinary steel-pipe inner and outer diameters are 0.87 and 1.00 in. The
quartz test section is 0.835 in ID and 0.943 in OD, is uninsulated, and carries
the test-section electrical source. The active HX is the middle 12 in of the
36-in upper incline. Its idealized outer shell diameter is 2.0 in.

The default numerical geometry:

- splits parents at tracked sensor locations;
- adds subdivisions until no child is longer than 0.15 m;
- preserves the parent identity, parent fractional coordinates, source
  allocation, and physical correlation length; and
- keeps child length for local area and energy allocation.

The July 27 implementation explicitly reconstructs the physical parent length
when evaluating internal Nusselt, external natural-convection, and HX
correlations. This prevents mesh refinement from falsely restarting thermal
development or redefining the physical natural-convection length.

## Thermophysical properties

Properties are evaluated at local bulk or film temperatures rather than held
globally constant.

The default molten-salt package is `salt_jin`:

\[
\rho(T)=2293.6-0.7497T,
\]

\[
c_p=1423.47\ {\rm J\,kg^{-1}\,K^{-1}},
\]

\[
k(T)=0.78-0.00125T+1.6\times10^{-6}T^2,
\]

\[
\mu(T)=0.001149
\exp\left(-\frac{810.896}{T}+\frac{780600}{T^2}\right)
\ {\rm Pa\,s}.
\]

The code also retains named `salt_kirst`, `salt_current`, and
`salt_promoted` alternatives. `salt_current` linearly interpolates the tracked
400--605 K property table. `salt_kirst` uses the same density, conductivity,
and constant heat capacity as `salt_jin` but a different inverse-temperature
viscosity relation. Water uses inherited polynomial fits.

The baseline salt cases use heater powers of 232.3, 265.7, 297.5, and 337.6 W
for Salt 1--4, plus 37 W through the quartz test section. Active water cases
must have zero test-section power.

The code checks that density, heat capacity, conductivity, and viscosity remain
finite and positive at all computed bulk temperatures. Water states above
333.15 K are rejected by policy. The solver does not currently enforce a
separate explicit high/low temperature validity envelope for every salt
correlation.

## Internal convection

For each segment,

\[
Re=\frac{\rho U D}{\mu},
\qquad
Pr=\frac{c_p\mu}{k}.
\]

The implemented Nusselt helper is

\[
Nu=
\begin{cases}
\max\left[
4.36,\,
1.86\left(\dfrac{Re\,Pr}{L_c/D}\right)^{1/3}
\right], & Re<2300,\\[6pt]
0.023Re^{0.8}Pr^{0.4}, & Re\ge2300.
\end{cases}
\]

Here \(L_c\) is the physical parent characteristic length, even when the
parent is numerically subdivided. The internal coefficient is

\[
h_i=M_{h,i}\frac{Nu\,k_f}{D_i},
\]

where \(M_{h,i}=1\) in the baseline. Optional per-parent or profile-descriptor
multipliers can modify it.

The turbulent branch exists in the internal heat-transfer helper, but the
nominal molten-salt loop is normally in the low-Reynolds-number laminar regime.

## Passive wall-to-ambient heat loss

Except for the active HX, a non-adiabatic baseline segment uses a cylindrical
resistance network per unit length:

\[
R_i'=\frac{1}{h_i\pi D_i},
\qquad
R_w'=\frac{\ln(D_o/D_i)}{2\pi k_w},
\]

\[
R_{\mathrm{ins}}'
=\frac{\ln(D_{\mathrm{ins},o}/D_o)}
{2\pi k_{\mathrm{ins}}},
\qquad
R_o'=\frac{1}{(h_o+h_{\mathrm{rad}})\pi D_{\mathrm{ext}}}.
\]

The total resistance is

\[
R_{\mathrm{tot}}'
=R_i'+R_w'+R_{\mathrm{ins}}'+R_o'.
\]

The baseline loss is one-way removal:

\[
q_{\mathrm{amb}}'
=\frac{\max(T_b-T_a,0)}{R_{\mathrm{tot}}'},
\qquad
Q_{\mathrm{amb}}=q_{\mathrm{amb}}'L.
\]

The `max` means the baseline model does not add heat from a hotter ambient to a
colder fluid.

Natural convection is computed from air properties at film temperature. A
Churchill--Chu-type vertical-surface relation and a horizontal-cylinder
relation are blended by the sine of the absolute segment inclination.
Radiation is linearized as

\[
h_{\mathrm{rad}}
=\varepsilon\sigma
(T_s+T_{\mathrm{sur}})
(T_s^2+T_{\mathrm{sur}}^2).
\]

The outer-surface temperature and the temperature-dependent external
coefficients are updated for six fixed iterations. The final algebraic wall
estimates are

\[
T_s=T_a+q'R_o',
\qquad
T_{w,o}=T_b-q'(R_i'+R_w').
\]

`T_pipe_outer_wall_K` is therefore a pipe-wall estimate and
`T_outer_surface_K` is the insulation or exposed outer-surface estimate. They
are not independent time-dependent wall states.

The `external_boundary_table` mode can replace a parent loss with one or more
role-local setup rows. A row supplies a conductance \(hA\), or \(h\) and area,
an ambient temperature, a declared drive-temperature selector, and optional
radiation fields. Parent-level rows are distributed over refined children by
physical span fraction. The dictionary loader rejects prohibited runtime
shortcuts such as realized validation outputs.

## Heater and test-section sources

In baseline mode, parent power is distributed uniformly by each refined
child's fraction of the physical parent.

- `heated_incline` receives `heater_power_W`.
- `test_section` receives `test_section_power_W`.

An optional `tw4_to_tp3_three_span` heater mode redistributes the heater power
among the final three quarters of the heater parent using normalized weights
for `tw4_to_tw5`, `tw5_to_tw6`, and `tw6_to_tp3`. The default weights are
0.45, 0.35, and 0.20.

The baseline test section remains a bare-quartz segment with an electrical
source and ordinary passive external loss. The optional TSWFC2 node models
described below are disabled by default.

## Cooling-jacket model

Three model modes are wired:

1. `predictive_airside_hx`: calculate duty from the fluid and air states;
2. `imposed_qhx`: distribute a declared total HX duty over the active HX
   length; and
3. `adiabatic`: set all ambient loss to zero and force all modeled heating
   through the HX.

The active predictive HX uses the 2.0-in idealized shell and the pipe OD to
form an annular air flow area and hydraulic diameter. Fluid-side and air-side
Nusselt numbers are evaluated with the same piecewise helper. The per-length
resistances are

\[
R_i'=\frac{1}{h_i\pi D_i},
\qquad
R_w'=\frac{\ln(D_o/D_i)}{2\pi k_w},
\qquad
R_a'=\frac{1}{h_a\pi D_o}.
\]

The conductance is

\[
UA=\alpha_{UA}\frac{L}{R_i'+R_w'+R_a'},
\]

where the default scenario value is \(\alpha_{UA}=1\). Some named diagnostic
scenarios use other values.

With

\[
C_h=\dot m c_{p,f},\qquad
C_c=\dot m_a c_{p,a},\qquad
C_r=\frac{C_{\min}}{C_{\max}},\qquad
NTU=\frac{UA}{C_{\min}},
\]

the code always evaluates the counterflow effectiveness relation

\[
\epsilon=
\begin{cases}
\dfrac{NTU}{1+NTU}, & C_r\approx1,\\[6pt]
\dfrac{1-\exp[-NTU(1-C_r)]}
{1-C_r\exp[-NTU(1-C_r)]}, & \text{otherwise}.
\end{cases}
\]

Then

\[
Q_{\mathrm{HX}}
=\epsilon C_{\min}
\max(T_{f,\mathrm{in}}-T_{a,\mathrm{in}},0),
\]

\[
T_{a,\mathrm{out}}
=T_{a,\mathrm{in}}+\frac{Q_{\mathrm{HX}}}{C_c}.
\]

The air temperature is marched from one refined HX child to the next. The
reported HX outer-surface estimate is a shell surrogate,

\[
T_{\mathrm{shell}}
=T_{a,\mathrm{avg}}+\frac{Q_{\mathrm{HX}}}{L}R_a'.
\]

The scenario field `air_counterflow` is serialized but not consulted by the
current core function; the effectiveness formula is counterflow regardless of
that flag.

## Hydraulic model

The active default distributed-friction form is `F1` in
`friction_closures.py`:

\[
f_D=\frac{64}{Re},
\qquad
\Delta p_{f,i}
=f_{D,i}\frac{L_i}{D_i}\frac{\rho_iU_i^2}{2}.
\]

This default F1 implementation remains \(64/Re\) for every Reynolds number.
The unused convenience function `solver.friction_factor()` contains a
turbulent Blasius branch, but the actual pressure-loss loop dispatches through
`friction_closures.compute_dp()`. A thesis description of the active F1
pressure model should therefore not claim that it switches to Blasius above
\(Re=2300\).

The selectable friction library also contains:

- `F3_hagenbach`: F1 plus a one-time \(K=1.33\) entry defect at each physical
  parent inlet;
- `F3_hagenbach_always`: the same entry defect on every numerical segment;
- `F3_shah_apparent`: Shah developing-flow apparent friction at physical
  parent inlets, F1 elsewhere;
- `F4_leg_class`: a diagnostic leg-class calibration;
- `F5_ri_corrected`: a diagnostic Richardson-number framework whose current
  fitted correction coefficients are zero, so it reduces to F3 Shah; and
- `F6_phi_re`: a diagnostic leg-class Reynolds multiplier calibrated over a
  narrow Salt2--4 range.

F4--F6 are wired research forms, not admitted general closures.

The baseline `MinorLosses` adds:

- a distributed-loss multiplier of 1.0;
- four 90-degree turns with \(K=1.0\) each;
- four 20-degree turns with \(K=0.10\) each;
- optional per-segment localized fixed \(K\);
- separately ledgered reset/development \(K\); and
- test-section contraction and expansion losses.

Distributed losses use local segment density and velocity. The default turn
sum uses a reference dynamic pressure based on the mean segment temperature and
the main-pipe velocity. The test-section diameter-change terms also use that
reference dynamic pressure. Parent-level localized coefficients are divided
over refined children by parent fraction so refinement does not multiply the
physical \(K\).

Buoyancy and irreversible loss remain separate. Buoyancy is never embedded
inside the friction closure.

## Nested nonlinear solution algorithm

The actual call hierarchy is:

```text
solve_case
  -> build and validate geometry and scenario contracts
  -> scan trial mass flows
     -> pressure_residual
        -> solve_temperature_periodicity
           -> scan trial loop-start temperatures
              -> march_temperatures
                 -> fixed-point segment energy update
           -> bracket and bisect temperature-periodicity residual
        -> calculate buoyancy pressure
        -> calculate distributed and minor losses
     -> bracket and bisect pressure residual
  -> apply root and physical-validity acceptance checks
  -> construct ModelResult and reporting ledgers
```

### Segment fixed point

For a trial \((\dot m,T_0)\), the model marches once around the ordered segment
list. Each segment performs at most 10 local iterations:

1. set \(T_{\mathrm{avg}}=(T_{\mathrm{in}}+T_{\mathrm{out}})/2\);
2. evaluate properties, thermal resistances, ambient loss, and HX loss at that
   state;
3. update the outlet temperature from the finite-segment energy balance;
4. stop when the raw update changes by less than \(10^{-9}\) K; otherwise
   under-relax with a 0.5/0.5 average.

There is no separate rejection test if one segment reaches the 10-iteration
limit. Global temperature periodicity and property checks provide the later
fail-closed tests.

### Inner temperature-periodicity root

At fixed \(\dot m\), the residual is
\(\mathcal R_T=T_{\mathrm{end}}-T_0\).

- Without a warm start, the initial scan uses 21 evenly spaced temperatures.
- With a warm start, it combines 9 global points, 13 local points, and the
  guess.
- The lower bound is 25 K below the colder of ambient and inlet air.
- The upper bound is at least 250 K above the warmer boundary and is enlarged
  using a heating-over-\(\dot m c_p\) scale.
- If the best point is at an endpoint, the range may expand up to three times.
- The first sign-changing interval is bisected for 25 iterations.
- If no bracket is found, the lowest-residual trial is returned for diagnosis,
  but `root_found=False`.

### Outer mass-flow root

The default search range is \(10^{-5}\) to 0.2 kg/s.

- Without a warm start, 20 logarithmically spaced mass flows are evaluated.
- With a warm start, a global grid, a local grid, and the previous solution
  are combined.
- Every mass-flow evaluation contains a complete inner periodic-temperature
  solve.
- All sign-changing pressure brackets are identified.
- If more than one bracket exists, the implementation chooses the bracket with
  the highest upper mass-flow endpoint.
- The selected bracket is bisected for 25 iterations.
- If no pressure bracket exists, the smallest-residual scan point is retained
  for diagnostics but the result is rejected.

Warm starts change search efficiency and local grid placement; they do not
change the equations or acceptance tolerances.

## Root and validity acceptance

A result is accepted for validation metrics only if all of the following pass:

- a pressure root was bracketed;
- the accepted mass flow is below 99% of the configured upper search bound;
- the temperature-periodicity root was found;
- \(|T_{\mathrm{end}}-T_0|\le0.25\) K;
- the pressure residual is no larger than
  \[
  \max\left(0.25\ {\rm Pa},\,
  0.05\max(|\Delta p_b|,|\Delta p_{\mathrm{loss}}|)
  \right);
  \]
- all computed bulk temperatures are finite;
- all evaluated density, heat capacity, conductivity, and viscosity values are
  finite and positive; and
- water remains at or below 333.15 K.

The code reports `accepted`, `rejected`, or `invalid`, together with a specific
rejection reason. Numerical root acceptance is not the same thing as scientific
closure admission or paper eligibility. The current policy metadata still
labels ordinary outputs `not_paper_eligible_pending_revalidation`.

## Sensor predictions

Sensors come from the tracked provisional sensor registry.

TP predictions:

- TP3 is the solved loop-start bulk temperature;
- other TP values are linearly interpolated along loop arc length between
  segment bulk-temperature endpoints; and
- the source parent, fraction, interpolation status, and notes are recorded.

TW predictions:

- ordinary TW sensors use the algebraic pipe outer-wall estimate;
- TW10 uses the active-HX outer-surface/shell estimate;
- refined wall samples are interpolated only within the sensor's physical
  parent; and
- if a pipe-wall estimate is unavailable, an outer-surface value can be used as
  a fallback for a non-TW10 channel.

These predictions are model-to-sensor projection operations. They are not
measured boundary conditions.

## Optional physics and diagnostic hooks

All of the following are real code paths, but all are disabled or neutral in
the baseline unless explicitly selected.

### Per-parent and profile-descriptor modifiers

Internal HTC, friction, external convection, radiation, and insulation can
receive declared per-parent multipliers. Profile-descriptor modes can add
shape and developing-length signals before those multipliers are applied.
Unsupported parent regions receive the configured neutral behavior rather than
automatic full-loop extrapolation.

### UMX1 throughflow/reservoir exchange

`energy_conserving_exchange_v1` adds a second algebraic reservoir temperature
on selected upcomer parents. The main-to-reservoir exchange is

\[
Q_{m\rightarrow r}
=\lambda_{\mathrm{UMX}}\dot m c_p f_{\mathrm{parent}}
(T_m-T_r).
\]

Setup-only reservoir heat rows can add a source or an \(hA(T_r-T_a)\) term.
The reservoir state is advanced with the same \(\dot m c_p\) scale, and the
ledger defines the opposing reservoir-to-main term so the local exchange
residual is zero by construction. This is a bounded model hook, not a resolved
two-dimensional recirculation field.

### AMX1 conservative axial mixing

AMX1 first performs the ordinary temperature march. It then builds conservative
pairwise or parent-cell exchange terms,

\[
Q_{i\rightarrow i+1}
=\lambda_{\mathrm{AMX}}\dot m c_{p,\mathrm{pair}}
(T_i-T_{i+1}),
\]

optionally clips the temperature drive, and repeats the entire march once with
the conservative source/sink ledger. Pairwise gains and losses sum to zero.

### TSWFC2 distributed test-section wall/fluid nodes

The TSWFC2 modes evaluate one or more axial node rows with

\[
Q_{\mathrm{node}}=hA(T_{\mathrm{drive}}-T_a)_+.
\]

Modes can:

- replace the baseline ambient closure;
- report the node ledger without replacing the baseline;
- retain at least the larger of baseline-covered and node heat; or
- preserve baseline total heat while exposing a signed unresolved residual.

The node wall temperatures are algebraic drops through the existing internal
and wall resistances. No wall storage or transient wall equation is introduced.

### Explicit 3D contract imports

The `three_d_coupling.py` path can map a normalized external contract to
prescribed segment source or loss dictionaries. Those paths are useful for
diagnostic replay and translation tests. They should not be described as the
ordinary predictive solver because realized CFD heat/source data can enter the
march when those flags are enabled.

## Configuration and campaign execution

`config_loader.py` reads:

- `configs/cases.yaml` for forward case inputs;
- `configs/scenarios.yaml` for reusable physics/control settings; and
- `configs/campaigns.yaml` for case selections, scenario selections, output
  roots, and minor-loss presets.

The preferred `run_resumable.py` workflow separates:

1. `prepare`: record the configs, geometry, sensor table, campaign metadata,
   and deterministic scenario plan;
2. `solve-scenario`: run one ordered scenario block and write each case
   immediately; and
3. `finalize`: merge manifests and regenerate aggregate reporting products.

Cases are ordered Salt1--4 then Water1--4. Each successful case becomes the
warm start for the next nearby case. A failed case clears the warm start. The
runner records an error and traceback instead of silently skipping the case.

## What the solver does not do

The current implementation does not:

- integrate transient mass, momentum, or energy equations;
- model startup, oscillatory natural circulation, freezing, or phase change;
- solve an axial wall-conduction equation;
- solve wall heat storage;
- march static pressure as a per-segment state;
- resolve radial or cross-sectional fluid velocity profiles;
- resolve recirculation unless an optional reduced exchange hook is selected;
- assimilate TP/TW measurements into the predictive state;
- infer uncertainty intervals inside `solve_case`;
- make closure admission decisions from numerical convergence alone; or
- guarantee that every serialized scenario field changes the physics.

In particular, `max_outer_iterations` is currently not used by the core solver,
and `air_counterflow` does not switch the HX effectiveness relation.

## Implementation details that should control thesis wording

1. Call the code a **steady 1D bulk-fluid solver with algebraic radial
   wall/insulation resistances**, or a **steady thermo-hydraulic loop solver**.
   Do not imply that it integrates a transient conjugate fluid-wall system.
2. State that the geometry has **12 parent segments**, optionally refined into
   numerical children.
3. Do not place static pressure in the actual marched `SegmentState`. The code
   returns loop-total buoyancy, loss, and pressure residual; detailed static
   pressure is not a primary state.
4. Describe F1 as the active default \(64/Re\) distributed-friction reference.
   Do not attribute the unused `friction_factor()` turbulent switch to the
   active F1 dispatcher.
5. Describe TW values as resistance-network-derived surface estimates and TP
   values as bulk-temperature projections.
6. Separate numerical acceptance from scientific admission. A bracketed,
   converged root is a valid numerical result under the selected assumptions;
   it does not validate the chosen closure.
7. Keep optional UMX1, AMX1, TSWFC2, F4--F6, profile-descriptor, and explicit
   3D replay modes labeled as optional or diagnostic unless a later evidence
   packet changes their status.

## Suggested writer summary

The one-dimensional solver closes two coupled periodic balances. For each trial
mass flow, it finds the loop-start temperature that makes a segmentwise steady
energy march periodic. The resulting temperature-dependent density field gives
the buoyancy head, while local properties, geometry, distributed friction, and
minor losses give the resisting pressure. A second bracketed root solve adjusts
mass flow until the two pressures balance. Heater power, passive radial heat
loss, and a predictive air-side effectiveness--NTU cooler determine the
temperature field. Measurements are projected and compared only after the
forward solution. Optional recirculation, axial-mixing, external-boundary,
test-section-node, and CFD-replay hooks are explicit model variants rather than
hidden changes to the governing balances.

## Companion files

- `implementation_equation_map.csv`: equation/function/source crosswalk.
- `mode_matrix.csv`: defaults, alternatives, and status of every major model
  switch.
- `source_snapshot_manifest.csv`: exact source hashes and working-tree status.
- `thesis_alignment_corrections.md`: specific corrections to older writer
  summaries and current conceptual text.
