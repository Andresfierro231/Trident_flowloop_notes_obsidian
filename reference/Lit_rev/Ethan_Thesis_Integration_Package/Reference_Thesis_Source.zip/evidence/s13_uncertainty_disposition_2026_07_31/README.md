---
provenance:
  - tools/analyze/build_s13_paper_integration.py
  - work_products/2026-07/2026-07-27/2026-07-27_s13_tp_first_same_label_sampler_repair/exact_contract_audit.csv
  - work_products/2026-07/2026-07-27/2026-07-27_s13_tp_first_same_label_sampler_repair/same_qoi_temporal_uncertainty_case_mesh.csv
  - work_products/2026-07/2026-07-27/2026-07-27_s13_tp_first_same_label_sampler_repair/same_qoi_medium_fine_comparison.csv
tags: [s13, work-product, paper-integration, same-qoi-uq, mesh-sensitivity]
related:
  - reports/2026-07/2026-07-31/2026-07-31_s13_paper_integration/README.md
  - operational_notes/2026-07-27_s13_tp_first_same_label_sampler_repair_start_here.md
task: TODO-S13-PAPER-INTEGRATION-REPORT-2026-07-31
date: 2026-07-31
role: Writer / Reviewer / Tester
type: work_product
status: complete
---
# S13 paper-integration work product

This package converts the repaired S13 exact-label and same-QOI uncertainty
evidence into two compact, generated paper tables. The paired report defines
the geometry, four QOIs, signs, exact-label contract, temporal-UQ mathematics,
diagnostic medium/fine comparison, P-to-C interpretation, recommended
two-state model structure, claim boundaries, and copy-ready paper text.

## Headline result

The maximum diagnostic medium/fine differences are 0.503% for trusted-wall
duty, 95.499% for positive-outward exchange flow, 24.149% for turnover time,
and 52.908% for wall/core contrast. The corresponding maximum available
same-QOI temporal components are 0.00365%, 2.068%, 2.022%, and 0.142%.
Integrated wall duty is therefore comparatively stable, while the internal
exchange and temperature-partition proxies are not mesh-robust on the
available terminal candidates.

These are diagnostic comparisons, not formal GCI. The medium/fine/coarse
physical times differ, the masks are mesh-specific, and no admitted exact-label
coarse member completes a common three-mesh family.

## Files

- `paper_qoi_definition_crosswalk.csv`: QOI symbol, plain-language and exact
  definition, unit, sign, spatial basis, paper relevance, model implication,
  and claim boundary.
- `paper_results_summary.csv`: source-derived maximum temporal and
  medium/fine differences, locations, ratios, interpretation, and fail-closed
  GCI/admission flags.
- `reports/2026-07/2026-07-31/2026-07-31_s13_paper_integration/README.md`:
  full paper-integration narrative.

## Reproduce

```bash
python3.11 tools/analyze/build_s13_paper_integration.py --check
```

The builder asserts 72/72 exact-contract passes, 24 medium/fine temporal rows,
12 coarse temporal rows, 12 diagnostic medium/fine comparisons, four closed
formal-GCI/admission gates, and the exact expected headline maxima before
writing the tables.

## Guardrails

No native CFD output, registry/admission state, predictive score, external
source, or thesis file was changed. The package does not release source
properties, wall duty, a wall-resistance term, or an exchange coefficient.
