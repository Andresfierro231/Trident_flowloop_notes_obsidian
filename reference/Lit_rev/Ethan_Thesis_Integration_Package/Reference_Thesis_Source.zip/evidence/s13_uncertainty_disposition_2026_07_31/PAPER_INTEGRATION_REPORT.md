---
provenance:
  - work_products/2026-07/2026-07-27/2026-07-27_s13_tp_first_same_label_sampler_repair/exact_contract_audit.csv
  - work_products/2026-07/2026-07-27/2026-07-27_s13_tp_first_same_label_sampler_repair/same_qoi_temporal_uncertainty_case_mesh.csv
  - work_products/2026-07/2026-07-27/2026-07-27_s13_tp_first_same_label_sampler_repair/same_qoi_temporal_uncertainty_cross_mesh_status.csv
  - work_products/2026-07/2026-07-27/2026-07-27_s13_tp_first_same_label_sampler_repair/same_qoi_medium_fine_comparison.csv
  - work_products/2026-07/2026-07-27/2026-07-27_s13_tp_first_same_label_sampler_repair/same_qoi_uncertainty_gate.csv
  - tools/analyze/build_s13_paper_integration.py
tags: [s13, paper-integration, exact-label, same-qoi-uq, mesh-sensitivity, upcomer, predictive-1d]
related:
  - work_products/2026-07/2026-07-31/2026-07-31_s13_paper_integration/README.md
  - operational_notes/2026-07-27_s13_tp_first_same_label_sampler_repair_start_here.md
  - reports/2026-07/2026-07-31/2026-07-31_closure_ablation_identifiability/README.md
  - operational_notes/2026-07-31_LOCALIZED_THERMAL_HYDRAULIC_MODEL_ROADMAP.md
task: TODO-S13-PAPER-INTEGRATION-REPORT-2026-07-31
date: 2026-07-31
role: Writer / Reviewer / Tester
type: report
status: complete
---
# S13 exact-label and same-QOI uncertainty: paper-integration report

## Executive finding

S13 is a CFD diagnostic study of the heated right-leg/upcomer region, not a
new reduced model. It separates four quantities that a one-dimensional model
can otherwise confound: wall-to-fluid heat transfer, one-way exchange from a
wall-adjacent control volume to the core, the associated turnover time, and a
wall-to-core temperature contrast.

The repaired sampler passes all 72 exact label/time/mask/source/value checks.
The three-window temporal component is small relative to the diagnostic
medium/fine difference for every quantity. Most importantly, the maximum
medium/fine difference is only 0.503% for wall duty, but 95.499% for the
outward exchange-flow proxy, 24.149% for the turnover-time proxy, and 52.908%
for the wall/core temperature contrast. The available refined terminal
candidates therefore support a limited but useful conclusion: integrated wall
duty is comparatively stable, while the inferred internal exchange and
temperature structure are not mesh-robust.

This result strengthens the P-to-C modeling argument. The P models showed that
the paper's aggregate outputs contain a dominant thermal direction and a
dominant hydraulic direction. S13 shows why the successor C form should not
collapse both into another global insulation or scalar circulation correction:
nearly the same wall duty can coexist with markedly different inferred
exchange, turnover, and wall/core contrast. The evidence motivates a separate,
conservative upcomer state/exchange model, but it does **not** identify or
validate its coefficient.

Formal same-time three-mesh GCI is not available. Medium, fine, and coarse rows
refer to different physical times and mesh-specific masks, and no admitted
exact-label coarse member forms a common mesh family. The medium/fine values in
this report are diagnostic terminal-candidate differences, not discretization
uncertainties, released coefficients, or evidence of grid convergence.

## Why this study was needed

The reduced-model results reveal a recurring ambiguity. A model can match TP
fluid temperatures or TW wall temperatures after changing heat retention, yet
still represent circulation poorly; conversely, a pressure-loss change can
improve mass flow without resolving local thermal placement. Aggregate TP/TW
and mass-flow scores alone cannot establish whether the missing behavior lies
in the wall heat path, cross-stream exchange, recirculation storage, or their
interaction.

S13 addresses that ambiguity using four CFD-derived quantities evaluated on
one declared spatial operator. The purpose is not to fit a closure directly.
It is to ask a more basic model-form question: which parts of the heated-leg
behavior appear stable enough to preserve as separate operators, and which
parts require new resolution or independent evidence?

The study also repairs two methodological weaknesses that would otherwise make
the comparison uninterpretable:

1. each value is tied to an exact case, mesh, QOI label, terminal role, time,
   geometry mask, source family, and finite-value check; and
2. temporal variation is calculated from the same QOI formula on the same mesh,
   rather than borrowed from a different temperature, endpoint, probe, or
   profile.

## Reader crosswalk: S13, P models, C models, TP, and TW

| Term | Meaning in this paper | Role in this study |
|---|---|---|
| S13 | Internal study identifier for the trusted-wall/upcomer-exchange CFD diagnostic | Supplies spatially resolved, read-only evidence; it is not a predictive model |
| TP | Fluid-temperature sensor family used for post-solve scoring | Aggregate validation output affected by wall duty, axial transport, and recirculation |
| TW | Wall-temperature sensor family used for post-solve scoring | Aggregate validation output affected by wall resistance, local duty, and fluid-side state |
| P1 | Temperature-oriented reduced-model reference: Shah friction with the empirical global 0.08 insulation-resistance compensation | Shows the attainable low-error thermal state but does not physically establish the 0.08 term |
| P2 | Same global thermal compensation with the F6 pressure-loss form; P2-exp and P2-CFD denote objective-specific hydraulic selections | Shows that circulation can be changed largely independently of the successful P1 temperature state |
| C models | Predictive successor family intended to replace diagnostic CFD-informed or global empirical corrections with setup-computable operators | S13 informs the needed state structure and validation observables; it does not admit a C closure |

The crosswalk prevents a common overstatement. S13 does not prove that P1 or
P2 contains the correct mechanism. It explains why their aggregate successes
and failures point toward distinct thermal and circulation coordinates in the
next model family.

## Geometry and sampling operator

For each Salt2, Salt3, and Salt4 medium and fine mesh, the sampler constructs a
mesh-specific seeded control volume, \(\Omega_s\), from cells adjacent to the
three trusted right-leg wall patches:

- `pipeleg_right_01_lower`;
- `pipeleg_right_02_middle`; and
- `pipeleg_right_03_upper`.

Its boundary is partitioned into the trusted wall surface \(\Gamma_w\), an
internal exchange interface \(\Gamma_e\) between seeded and adjacent core
cells, and lower/upper cap or open-boundary faces. The cap patches are
`ncc_pipeleg_right_01_lower_start` and
`ncc_pipeleg_right_03_upper_end`. The control volume is one cell layer adjacent
to the trusted wall and is therefore a diagnostic near-wall volume, not a
geometrically fixed continuum subdomain shared exactly by every mesh.

### Global-face-vector repair

OpenFOAM face geometry is indexed globally, but the original extraction path
looked up selected area vectors using a serial local iteration index. That can
silently assign the wrong normal to an otherwise valid interface row. The
repair first obtains the released global face IDs, then stores
\(\mathbf A_f\) in a dictionary keyed by that global ID. For an internal face,
the native OpenFOAM owner-to-neighbour vector is reversed when the seeded cell
is the neighbour so that \(\mathbf A_{out,f}\) always points out of
\(\Omega_s\). The exact-contract audit then verifies the label, time, mask,
source family, finiteness, diagnostic status, and read-only release status of
every scalar result.

## Quantities of interest

Let \(A_f\) be face area, \(\mathbf A_{out,f}\) the area vector directed out of
the seeded volume, and let the face velocity and density on the internal
interface be arithmetic averages of the seeded- and core-cell values:

\[
\mathbf U_f=\frac{\mathbf U_{s,f}+\mathbf U_{c,f}}{2},
\qquad
\rho_f=\frac{\rho_{s,f}+\rho_{c,f}}{2}.
\]

### Wall duty

\[
Q_{wall}=-\sum_{f\in\Gamma_w}q''_{OF,f}A_f.
\]

OpenFOAM's wall heat-flux field uses the native outward wall-patch sign. The
leading minus sign makes positive \(Q_{wall}\) denote heat entering the seeded
fluid. This is a direct trusted-wall integral, distinct from a source-side
static heat input.

### Positive-outward exchange-flow proxy

\[
\dot m_f=\rho_f\mathbf U_f\!\cdot\!\mathbf A_{out,f},
\qquad
\dot m_+=\sum_{f\in\Gamma_e}\max(\dot m_f,0).
\]

This is a one-way kinematic proxy. It intentionally does not cancel positive
outflow against negative inflow, and it is not the net mass balance of the
control volume. It must not be called a measured recirculation rate or an
admitted exchange coefficient.

### Recirculation turnover-time proxy

\[
\dot V_+=\sum_{f\in\Gamma_e:\dot m_f>0}\frac{\dot m_f}{\rho_f},
\qquad
\tau_{recirc}=\frac{V_{CV}}{\max(\dot V_+,\epsilon)}.
\]

The small positive \(\epsilon\) only prevents division by zero. The resulting
quantity is a control-volume turnover scale, not a Lagrangian residence-time
measurement.

### Wall/core temperature contrast

\[
\Delta T_{w-c}=\langle T_w\rangle_{A,\Gamma_w}
-\langle T_c\rangle_{A,\Gamma_e}.
\]

The second term is the area-weighted temperature of the core-side cells
adjacent to the exchange interface. Although the machine label contains
`bulk`, it is not a loop-wide or cross-sectionally mixed bulk temperature. The
sampled contrasts are negative, meaning the trusted-wall average is below the
adjacent core-side average under this sign convention.

The complete definition table, including units, signs, spatial bases, model
implications, and claim boundaries, is generated as
`paper_qoi_definition_crosswalk.csv` in the companion work product.

## Exact-label design and uncertainty mathematics

For every medium/fine case-mesh pair and QOI, the sampler reads three native
terminal candidate times with roles \(y_-\), \(y_0\), and \(y_+\):

| Case | Medium times (s) | Fine times (s) | Current-coarse times (s) |
|---|---:|---:|---:|
| Salt2 | 516 / 517 / 518 | 397 / 398 / 399 | 7914 / 7915 / 7916 |
| Salt3 | 1338 / 1339 / 1340 | 531 / 532 / 533 | 7617 / 7618 / 7619 |
| Salt4 | 1157 / 1158 / 1159 | 415 / 416 / 417 | 9999 / 10000 / 10001 |

The conservative same-mesh temporal component is

\[
u_t(y)=\max\left(|y_0-y_-|,|y_+-y_0|\right),
\qquad
r_t(y)=100\frac{u_t(y)}{|y_0|}.
\]

The three-window half-range,

\[
u_{t,HR}=\frac{\max(y_-,y_0,y_+)-\min(y_-,y_0,y_+)}{2},
\]

is retained as a secondary descriptive quantity. Neither expression is a
confidence interval; it measures local neighbour-window drift on one fixed
mesh, mask, source, and QOI definition.

The terminal-candidate medium/fine comparison is

\[
\delta_{mf}=100\frac{|y_{m,0}-y_{f,0}|}{|y_{f,0}|}.
\]

Because \(y_{m,0}\) and \(y_{f,0}\) occur at different physical times and use
mesh-specific masks, \(\delta_{mf}\) is only a diagnostic sensitivity. It is
not a Richardson error estimate and is not combined with \(u_t\).

## Verification and provenance result

The canonical read-only Slurm execution (`3311146`) completed all six
medium/fine case-mesh pairs with zero sampling errors. The repaired package
contains:

- 18 terminal-window reductions;
- 72 exact-label QOI rows and 72/72 contract passes;
- 24 medium/fine same-QOI temporal triplets;
- 12 current-coarse same-QOI temporal triplets, for 36 available per-mesh
  temporal components;
- 12 diagnostic medium/fine comparisons; and
- four fail-closed QOI-level uncertainty gates.

No duplicate heavy run was launched. Native solver output was read only.

## Results

### Compact QOI result

| QOI | Maximum relative temporal component (%) | Location | Maximum diagnostic medium/fine difference (%) | Location | Interpretation |
|---|---:|---|---:|---|---|
| \(Q_{wall}\) | 0.003646 | Salt4 coarse | 0.502917 | Salt3 | Comparatively stable integrated wall-duty diagnostic |
| \(\dot m_+\) | 2.067709 | Salt4 fine | 95.499343 | Salt2 | Not mesh-robust on available terminal candidates |
| \(\tau_{recirc}\) | 2.022030 | Salt4 fine | 24.149197 | Salt2 | Not mesh-robust on available terminal candidates |
| \(\Delta T_{w-c}\) | 0.141840 | Salt4 fine | 52.908054 | Salt4 | Not mesh-robust on available terminal candidates |

The medium/fine difference is 138 times the maximum available temporal
component for wall duty, 46 times for outward exchange flow, 12 times for
turnover time, and 373 times for the wall/core contrast. These ratios show that
the reported discrepancy is not explained by the local three-window drift
alone. They do not isolate mesh error from different-time or mask effects.

### Casewise diagnostic medium/fine difference

| Case | \(Q_{wall}\) (%) | \(\dot m_+\) (%) | \(\tau_{recirc}\) (%) | \(\Delta T_{w-c}\) (%) |
|---|---:|---:|---:|---:|
| Salt2 | 0.0247 | 95.4993 | 24.1492 | 52.3984 |
| Salt3 | 0.5029 | 84.5827 | 19.6936 | 52.7512 |
| Salt4 | 0.3442 | 91.1065 | 22.4211 | 52.9081 |

The pattern repeats across all three cases: wall duty changes by less than
0.51%, whereas the one-way exchange and contrast diagnostics change by tens of
percent. The direction is also coherent. Medium \(\dot m_+\) is substantially
higher than fine in every case; medium \(\tau_{recirc}\) is lower; and the
magnitude of the negative medium wall/core contrast is larger. This coherence
makes the result valuable as a model-form warning, but the gate failures
prevent a quantitative continuum extrapolation.

## Interpretation for the paper

### What is directly observed

1. The exact-label and finiteness contract is complete.
2. Local three-window drift is modest for these terminal candidates.
3. Integrated trusted-wall duty is much less sensitive between the available
   refined candidates than the three near-wall exchange/contrast proxies.
4. The medium/fine terminal rows are not at common physical times and do not
   share an admitted mesh-equivalent mask.

### What may reasonably be inferred

The available evidence suggests that reproducing total wall duty is a weaker
requirement than reproducing the internal thermal-hydraulic state. A reduced
model can therefore match an integrated heat path while still missing how
fluid is partitioned between a near-wall recirculating region and the core.
This is consistent with the P-model observation that a thermal correction can
recover TP/TW behavior without simultaneously recovering circulation.

The inference is about model structure, not physical attribution. S13 cannot
determine whether the refined differences arise from discretization, unequal
physical state, the one-cell mask definition, turbulence/numerical behavior,
or some combination. It therefore supports separating the wall and exchange
operators, but not assigning the discrepancy to a particular mechanism.

### What is not supported

The study does not support any of the following claims:

- that the medium or fine proxy is a converged truth;
- that a formal grid-convergence index has been calculated;
- that the observed medium/fine difference is entirely discretization error;
- that \(\dot m_+\) is a conserved exchange flow or measured recirculation rate;
- that \(\tau_{recirc}\) is a physical residence time;
- that a scalar exchange coefficient can be fitted or released from these rows;
- that the sampled \(Q_{wall}\), source properties, or a wall-resistance term
  is released for predictive runtime use; or
- that S13 validates the two-state upcomer model.

## Link to the main P-model results

P1's global 0.08 insulation-resistance compensation produces the best released
balanced TP/TW state, while P2 changes the hydraulic loss form and improves the
mass-flow comparison with only a small change in balanced temperature error.
The closure-identifiability study independently found two dominant response
directions under the primary TP/TW/mass-flow policy: a thermal-inventory
direction and an aggregate hydraulic-resistance direction.

S13 adds spatial evidence to that aggregate result:

| Main-paper observation | S13 contribution | Consequence for a C model |
|---|---|---|
| P1 can reproduce a useful temperature state with an empirical global thermal compensation | Stable integrated wall duty does not imply stable exchange or wall/core structure | Replace the global compensation with named wall/ambient/source paths and retain a separate internal-state diagnostic |
| P2 can improve circulation without destroying the P1 temperature state | Exchange/turnover diagnostics are distinct from total wall duty | Keep the primary thermal and hydraulic coordinates separate |
| TP and TW residuals do not uniquely identify local closures | The interface contrast is highly sensitive to the mesh-specific representation | Do not infer wall resistance or exchange from aggregate TP/TW alone |
| A richer upcomer form is proposed for C models | S13 defines candidate observables for exchange and turnover | Validate the new state against independently robust profile, reverse-flow, or exchange evidence before promotion |

Thus the P models diagnose the low-dimensional response directions, while S13
helps translate those directions into a more explicit physical architecture
for the C models.

## Model form implied by S13

The most defensible richer candidate is an axially distributed two-state
upcomer with a throughflow/core state \(T_c(z,t)\) and a wall-adjacent
recirculating state \(T_r(z,t)\). A generic conservative energy structure is

\[
\rho c_p A_c\frac{\partial T_c}{\partial t}
+\dot m c_p\frac{\partial T_c}{\partial z}
=q'_c+\mathcal E(T_r,T_c),
\]

\[
\rho c_p A_r\frac{\partial T_r}{\partial t}
+\dot m_r c_p\frac{\partial T_r}{\partial z}
=q'_w-\mathcal E(T_r,T_c),
\]

where the exchange operator appears with equal and opposite signs so that it
cannot create energy. Depending on the final derivation,
\(\mathcal E\) may be expressed as an enthalpy exchange
\(\dot m_e c_p(T_r-T_c)\), a conductance-like term, or a bounded combination.
S13 does not choose among those forms or supply \(\dot m_e\). Its findings
impose requirements instead:

- keep wall duty \(q'_w\) distinct from exchange \(\mathcal E\);
- conserve mass and energy between states;
- distribute the model axially rather than represent the three wall sections
  only through one global node;
- do not calibrate exchange and wall resistance from the same TP/TW residual;
- expose state predictions that can be compared with reverse-flow fraction,
  axial velocity/enthalpy profiles, recirculation-zone extent, or a
  mesh-robust exchange observable; and
- retain the frozen fit split (Salt1--Salt4, 1000 W, and 1500 W) and no-refit
  test split (500 W and 1012.8 W) already declared for the two-state avenue.

A simpler one-state model with one global insulation multiplier and one scalar
exchange coefficient is not favored: it asks two poorly separated parameters
to absorb a discrepancy that the current outputs cannot identify. A
temperature-dependent friction law remains useful as a falsification
comparator, but S13 alone does not establish it as a recirculation closure.

## Why formal GCI remains fail-closed

A formal Richardson/GCI study requires a common QOI evaluated at a common
physical state with a declared refinement sequence and a sufficiently
equivalent spatial operator. It then requires an observed convergence ratio,
an apparent order, and an asymptotic-range assessment. S13 presently has only
the first part—the same algebraic QOI labels within each mesh.

The physical times differ substantially, the seeded control volume is
mesh-specific, and no admitted exact-label coarse member completes the same
mesh family. Consequently, an apparent order computed from these rows would
mix temporal-state and operator changes with spatial refinement. Reporting
such a number would add precision without validity.

To repair this in a future CFD campaign, predeclare common output times or a
state-equivalence rule, construct geometrically equivalent masks independent
of a single cell layer, retain the same field/source/sign definitions, use at
least three ordered meshes, demonstrate terminal stationarity, and then apply
Richardson/GCI only if the QOI exhibits an admissible convergence sequence.

## Copy-ready paper text

### Motivation and method

To distinguish integrated wall heating from unresolved upcomer exchange, four
quantities were extracted from the Salt2--Salt4 CFD fields on medium and fine
meshes. A wall-adjacent control volume was formed from cells adjoining three
trusted heated-leg wall patches. Its boundary was partitioned into the wall,
an internal interface to adjacent core cells, and end-cap faces. The sampled
quantities were the signed wall-heat-flux integral, the positive-outward
one-way mass flux through the internal interface, a turnover-time proxy formed
from the control-volume volume divided by positive-outward volumetric flux,
and the area-averaged wall-to-core temperature contrast. Face normals were
reconstructed by global OpenFOAM face ID and oriented outward from the seeded
control volume. Every result was required to match its declared case, mesh,
terminal role, physical time label, geometry mask, source family, and QOI
definition.

For each case-mesh-QOI tuple, local terminal-window variation was estimated as
the larger absolute change from the central terminal candidate to its
immediate earlier or later neighbor. Medium/fine terminal differences were
also computed for the same QOI definition. Because the medium and fine
terminal candidates occur at different physical times and use mesh-specific
control-volume masks, these differences were treated only as diagnostic mesh
sensitivity; they were not interpreted as formal Richardson errors or GCI.

### Results and discussion

All 72 exact-label contract rows passed and all 24 medium/fine same-QOI
temporal triplets were complete. Across the available coarse, medium, and fine
per-mesh triplets, the maximum relative temporal components were 0.00365% for
wall duty, 2.068% for positive-outward exchange flow, 2.022% for turnover time,
and 0.142% for wall/core temperature contrast. The maximum diagnostic
medium/fine differences were 0.503%, 95.499%, 24.149%, and 52.908%,
respectively. The same qualitative ordering occurred in Salt2, Salt3, and
Salt4: integrated wall duty changed little, whereas the inferred exchange and
temperature-partition quantities changed by tens of percent.

These results indicate that agreement in total wall-to-fluid heat transfer
does not guarantee agreement in the internal upcomer state. This distinction
helps interpret the reduced-model results: the temperature-oriented P1 path
and circulation-oriented P2 path reveal separable aggregate thermal and
hydraulic response directions, while S13 shows that a separate exchange or
recirculation state may be required to represent their spatial coupling. The
evidence therefore motivates an axially distributed two-state upcomer model in
which wall heating and state exchange are separate, conservative operators.
It does not provide an independently validated exchange coefficient, nor does
it establish the physical attribution of the empirical P-model corrections.

### Limitations sentence

The medium/fine comparisons are diagnostic terminal-candidate sensitivities,
not formal grid-convergence estimates, because the meshes were sampled at
different physical times with mesh-specific masks and no admitted exact-label
coarse member; coefficient admission and production use therefore remained
fail-closed.

## Recommended paper tables and figure

1. **Main or methods table:** use the four-row QOI definition crosswalk. Caption:
   “S13 quantities of interest, spatial operators, signs, and interpretation
   boundaries. The exchange and turnover quantities are diagnostic one-way
   proxies and are not closure coefficients.”
2. **Main results table:** use the compact four-row results table above.
   Caption: “Maximum same-QOI temporal component and diagnostic medium/fine
   terminal-candidate difference across Salt2--Salt4. Medium/fine values are
   not formal GCI because physical times and mesh masks differ.”
3. **Optional figure:** plot paired log-scale bars for maximum temporal
   component and maximum medium/fine difference for each QOI. Place an explicit
   `diagnostic, not GCI` banner in the panel. The visual point is the separation
   between stable integrated wall duty and unstable exchange/contrast
   structure, not a convergence rate.
4. **Supplementary table:** publish the casewise medium/fine percentages and
   the exact time table so the non-equivalence is visible rather than buried in
   a footnote.

## Reproduction and source map

Rebuild the paper tables with:

```bash
python3.11 tools/analyze/build_s13_paper_integration.py --check
```

Primary evidence files are:

- `exact_contract_audit.csv` for the 72/72 identity and finiteness checks;
- `same_qoi_temporal_uncertainty_case_mesh.csv` for the 24 medium/fine
  temporal triplets;
- `same_qoi_temporal_uncertainty_cross_mesh_status.csv` for the non-combined
  coarse/medium/fine temporal disposition;
- `same_qoi_medium_fine_comparison.csv` for the 12 diagnostic comparisons;
- `same_qoi_uncertainty_gate.csv` for the four formal-GCI/admission decisions;
- `paper_qoi_definition_crosswalk.csv` for definitions and claim boundaries;
  and
- `paper_results_summary.csv` for the four generated headline rows.

## Guardrails

This report did not mutate native CFD output, external Fluid source, the case
registry, admission state, predictive scores, or the thesis repository. It
does not release source/property data, \(Q_{wall}\), a wall correction, or an
exchange coefficient for predictive runtime use.
