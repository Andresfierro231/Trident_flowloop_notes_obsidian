#!/usr/bin/env python3
"""Rebuild tight review composites from rendered side-z upcomer PNG panels."""

from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont


PACKAGE = Path(__file__).resolve().parents[1]
FIGURES = PACKAGE / "figures"
COMPOSITES = FIGURES / "composites"
COMPONENT = "upcomer"
VIEW = "side_z"

SOURCE_ORDER = [
    ("Salt1", "viscosity_screening_salt_test_1_jin_coarse_mesh"),
    ("Salt2", "val_salt_test_2_coarse_mesh_laminar"),
    ("Salt3", "viscosity_screening_salt_test_3_jin_coarse_mesh"),
    ("Salt4", "viscosity_screening_salt_test_4_jin_coarse_mesh"),
]

FAMILIES = {
    "y_velocity_side_z": {
        "stem_token": "velocity_y_component_arrows",
        "short_title": "Y velocity",
        "subtitle": "side-z",
    },
    "velocity_magnitude_side_z": {
        "stem_token": "velocity_magnitude_arrows",
        "short_title": "Velocity\nmagnitude",
        "subtitle": "side-z",
    },
}

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)


@dataclass(frozen=True)
class Box:
    left: int
    top: int
    right: int
    bottom: int

    def clamp(self, width: int, height: int) -> "Box":
        return Box(
            max(0, self.left),
            max(0, self.top),
            min(width, self.right),
            min(height, self.bottom),
        )

    @property
    def width(self) -> int:
        return self.right - self.left

    @property
    def height(self) -> int:
        return self.bottom - self.top

    def as_pillow(self) -> tuple[int, int, int, int]:
        return (self.left, self.top, self.right, self.bottom)


def load_font(name: str, size: int) -> ImageFont.FreeTypeFont:
    candidates = [
        Path("/usr/share/fonts/dejavu") / name,
        Path("/usr/share/fonts/truetype/dejavu") / name,
    ]
    for candidate in candidates:
        if candidate.exists():
            return ImageFont.truetype(str(candidate), size=size)
    return ImageFont.load_default()


TITLE_FONT = load_font("DejaVuSans-Bold.ttf", 70)
METRIC_FONT = load_font("DejaVuSans.ttf", 34)


def contiguous_runs(indices: np.ndarray) -> list[tuple[int, int]]:
    if indices.size == 0:
        return []
    breaks = np.where(np.diff(indices) > 1)[0]
    starts = np.r_[indices[0], indices[breaks + 1]]
    ends = np.r_[indices[breaks], indices[-1]]
    return [(int(start), int(end)) for start, end in zip(starts, ends)]


def largest_column_run(mask: np.ndarray, x_min: int, x_max: int, threshold: int) -> tuple[int, int]:
    column_hits = mask.sum(axis=0)
    candidate = np.where((np.arange(mask.shape[1]) >= x_min) & (np.arange(mask.shape[1]) <= x_max) & (column_hits > threshold))[0]
    runs = contiguous_runs(candidate)
    if not runs:
        raise ValueError(f"no column run found in x=[{x_min}, {x_max}] with threshold={threshold}")
    return max(runs, key=lambda run: column_hits[run[0] : run[1] + 1].sum())


def detect_regions(image: Image.Image) -> tuple[Box, Box]:
    rgb = np.asarray(image.convert("RGB"))
    height, width = rgb.shape[:2]
    nonwhite = np.any(rgb < 245, axis=2)

    pipe_run = largest_column_run(nonwhite, width // 4, int(width * 0.72), threshold=260)
    pipe_cols = nonwhite[:, pipe_run[0] : pipe_run[1] + 1]
    pipe_rows = np.where(pipe_cols.sum(axis=1) > 2)[0]
    pipe_box = Box(
        pipe_run[0] - 170,
        int(pipe_rows.min()) - 20,
        pipe_run[1] + 120,
        int(pipe_rows.max()) + 20,
    ).clamp(width, height)

    bar_mask = nonwhite[:, int(width * 0.88) :]
    bar_cols = np.where(bar_mask.sum(axis=0) > 8)[0]
    bar_rows = np.where(bar_mask.sum(axis=1) > 1)[0]
    if bar_cols.size == 0 or bar_rows.size == 0:
        raise ValueError("no scalar-bar region found")
    scalar_box = Box(
        int(width * 0.88) + int(bar_cols.min()) - 24,
        int(bar_rows.min()) - 28,
        int(width * 0.88) + int(bar_cols.max()) + 24,
        int(bar_rows.max()) + 28,
    ).clamp(width, height)
    return pipe_box, scalar_box


def draw_centered_text(draw: ImageDraw.ImageDraw, box: Box, text: str, font: ImageFont.ImageFont, fill: tuple[int, int, int]) -> None:
    lines = text.splitlines()
    line_heights = []
    line_widths = []
    for line in lines:
        bbox = draw.textbbox((0, 0), line, font=font)
        line_widths.append(bbox[2] - bbox[0])
        line_heights.append(bbox[3] - bbox[1])
    total_height = sum(line_heights) + max(0, len(lines) - 1) * 8
    y = box.top + max(0, (box.height - total_height) // 2)
    for line, width, line_height in zip(lines, line_widths, line_heights):
        x = box.left + max(0, (box.width - width) // 2)
        draw.text((x, y), line, font=font, fill=fill)
        y += line_height + 8


def panel_path(family: str, source_id: str) -> Path:
    stem_token = str(FAMILIES[family]["stem_token"])
    return (
        FIGURES
        / family
        / source_id
        / COMPONENT
        / "png"
        / f"{source_id}_{COMPONENT}_{stem_token}_{VIEW}.png"
    )


def load_downward_velocity_metrics() -> dict[str, float]:
    status_path = PACKAGE / "y_velocity_side_z_status.json"
    payload = json.loads(status_path.read_text())
    metrics = {}
    for result in payload.get("results", []):
        source_id = result.get("source_id")
        color_range = result.get("local_color_range") or result.get("color_range")
        if source_id and color_range:
            metrics[str(source_id)] = abs(float(color_range[0]))
    return metrics


def build_panel(
    family: str,
    label: str,
    source_id: str,
    downward_velocity_metrics: dict[str, float],
    include_scalar_bar: bool,
) -> tuple[Image.Image, dict[str, object]]:
    image_path = panel_path(family, source_id)
    image = Image.open(image_path).convert("RGB")
    pipe_box, scalar_box = detect_regions(image)

    pipe = image.crop(pipe_box.as_pillow())
    pipe_x_scale = 1.18
    pipe = pipe.resize((max(1, int(pipe.width * pipe_x_scale)), pipe.height), Image.Resampling.LANCZOS)
    scalar = image.crop(scalar_box.as_pillow())

    top_band = 190
    bottom_band = 35
    target_height = max(pipe.height + top_band + bottom_band, 2625)
    scalar_scale = min(2.05, (target_height - 80) / max(1, scalar.height))
    scalar = scalar.resize(
        (max(1, int(scalar.width * scalar_scale)), max(1, int(scalar.height * scalar_scale))),
        Image.Resampling.LANCZOS,
    )

    pad_left = 16
    pipe_scalar_gap = 95
    pad_right = 22
    if include_scalar_bar:
        panel_width = pad_left + pipe.width + pipe_scalar_gap + scalar.width + pad_right
    else:
        panel_width = pad_left + pipe.width + pad_right
    panel = Image.new("RGB", (panel_width, target_height), WHITE)

    pipe_y = top_band
    pipe_x = pad_left
    scalar_x = pad_left + pipe.width + pipe_scalar_gap
    scalar_y = (target_height - scalar.height) // 2
    panel.paste(pipe, (pipe_x, pipe_y))
    if include_scalar_bar:
        panel.paste(scalar, (scalar_x, scalar_y))

    draw = ImageDraw.Draw(panel)
    title_box = Box(pipe_x, 16, pipe_x + pipe.width, 92)
    draw_centered_text(draw, title_box, label, TITLE_FONT, BLACK)
    max_down = downward_velocity_metrics.get(source_id)
    if max_down is None:
        metric_text = "max down U_y: n/a"
    else:
        metric_text = f"max down U_y\n{max_down:.3f} m/s"
    metric_box = Box(pipe_x, 96, pipe_x + pipe.width, 175)
    draw_centered_text(draw, metric_box, metric_text, METRIC_FONT, BLACK)

    return panel, {
        "family": family,
        "label": label,
        "source_id": source_id,
        "input_path": str(image_path.relative_to(PACKAGE)),
        "pipe_box": f"{pipe_box.left}:{pipe_box.top}:{pipe_box.right}:{pipe_box.bottom}",
        "scalar_bar_box": f"{scalar_box.left}:{scalar_box.top}:{scalar_box.right}:{scalar_box.bottom}",
        "scalar_bar_scale": f"{scalar_scale:.6g}",
        "pipe_x_scale": f"{pipe_x_scale:.6g}",
        "include_scalar_bar": str(include_scalar_bar).lower(),
        "max_downward_U_y_m_per_s": "" if max_down is None else f"{max_down:.9g}",
        "panel_width": panel.width,
        "panel_height": panel.height,
    }


def build_composite(family: str) -> list[dict[str, object]]:
    panels = []
    rows = []
    downward_velocity_metrics = load_downward_velocity_metrics()
    for index, (label, source_id) in enumerate(SOURCE_ORDER):
        panel, row = build_panel(
            family,
            label,
            source_id,
            downward_velocity_metrics,
            include_scalar_bar=index == len(SOURCE_ORDER) - 1,
        )
        panels.append(panel)
        rows.append(row)

    gap = 42
    margin = 35
    width = sum(panel.width for panel in panels) + gap * (len(panels) - 1) + 2 * margin
    height = max(panel.height for panel in panels) + 2 * margin
    composite = Image.new("RGB", (width, height), WHITE)

    x = margin
    for panel in panels:
        composite.paste(panel, (x, margin + (height - 2 * margin - panel.height) // 2))
        x += panel.width + gap

    outputs = [
        FIGURES / f"{family}_composite_labeled.png",
        COMPOSITES / f"{family}_trimmed_composite_labeled.png",
    ]
    COMPOSITES.mkdir(parents=True, exist_ok=True)
    for output in outputs:
        composite.save(output, optimize=True)

    for row in rows:
        row["output_paths"] = ";".join(str(path.relative_to(PACKAGE)) for path in outputs)
        row["composite_width"] = composite.width
        row["composite_height"] = composite.height
    return rows


def main() -> None:
    manifest_rows = []
    for family in FAMILIES:
        manifest_rows.extend(build_composite(family))

    manifest_path = COMPOSITES / "review_composite_layout_manifest.csv"
    with manifest_path.open("w", newline="") as stream:
        writer = csv.DictWriter(
            stream,
            fieldnames=[
                "family",
                "label",
                "source_id",
                "input_path",
                "pipe_box",
                "scalar_bar_box",
                "scalar_bar_scale",
                "pipe_x_scale",
                "include_scalar_bar",
                "max_downward_U_y_m_per_s",
                "panel_width",
                "panel_height",
                "composite_width",
                "composite_height",
                "output_paths",
            ],
        )
        writer.writeheader()
        writer.writerows(manifest_rows)

    print(f"rebuilt {len(FAMILIES) * 2} composite PNGs")
    print(f"wrote {manifest_path.relative_to(PACKAGE)}")


if __name__ == "__main__":
    main()
