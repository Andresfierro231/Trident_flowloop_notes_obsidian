# Salt1--Salt4 upcomer midpoint cross sections

This compact package supplies the lower PDF panel of dissertation Figure 3.3.
It was imported on 2026-08-04 from the audited Ethan work product:

`repo://ethan_runs/work_products/2026-08/2026-08-03/2026-08-03_upcomer_cross_section_salt14_figure/`

The portable path from the paper root is:

`../../../ethan_runs/work_products/2026-08/2026-08-03/2026-08-03_upcomer_cross_section_salt14_figure/`

## Retained files

- `salt1_4_upcomer_midplane_signed_uy_polygon_horizontal.pdf`: PDF generated
  by the upstream `scripts/build_polygon_composite.py`; SHA-256
  `609a86e3e6daf773d35d5b5f31bd6be0c2918d233186eee3ae9ea2bc73483a19`.
- `composite_polygon_status.json`: shared axes, color range, arrow scale,
  reverse-flow metrics, and metric audit; SHA-256
  `649fcae84977a69fc31f93ec55b12d0d9f42a4a702fcb727035829f02a5766e8`.

The August 4 publication refresh enlarged all titles, labels, ticks, metric
boxes, the quiver key, and the definition footer for manuscript-scale
legibility without changing the plotted data, shared color range, or arrows.

## Claim boundary

The terminal midpoint planes show simultaneous forward and reverse axial
transport and case-dependent secondary-flow structure. Reverse-flow area
fraction is the polygon area with cell-centered `U_y < 0` divided by total
area. The density-free reverse-flow transport proxy weights the same cells by
`|U_y| A`; it is not a mass-flow fraction. Salt2--Salt4 have the same spatial
reverse-flow mask (244 of 920 cells) and therefore the same area fraction, but
their transport proxies differ. These snapshots do not establish stationarity,
mesh independence, an onset threshold, or an exchange coefficient.
