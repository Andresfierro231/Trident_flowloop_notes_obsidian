# Frozen two-state paper-integration evidence

This compact package supports the Chapter 4--6 two-state upcomer additions.
It is a byte-identical subset of the canonical Ethan package at:

`../../../../../ethan_runs/work_products/2026-07/2026-07-31/2026-07-31_two_state_upcomer_prototype/predictivity_campaign/`

The controlling frozen contract hash is
`e6af474b8da5b1e0f8230edd6c1d884ef33b8b198abd7e7e7b75a5459ac9dd14`.
The package is a nominal retrospective mechanism and sensitivity study.  It
contains no protected high-heat or prospective-insulation target, and it does
not physically admit a two-state exchange closure.

## Claim routes

- Equations, parameters, split, source hashes, and runtime policy:
  `FROZEN_PREDICTIVITY_CONTRACT.json`.
- Machine decision, numerical gates, runtime details, and limitations:
  `RIGOROUS_PREDICTIVITY_DECISION.json`.
- Complete aggregate and casewise TP/TW/experimental-mdot/CFD-mdot values:
  `audience_model_tp_tw_mdot_scorecard.csv` and
  `audience_case_tp_tw_mdot_scorecard.csv`.
- Superseded nested result and valid/invalid mechanism rows:
  `mechanism_model_comparison.csv`.
- Fixed-forward-inlet mixing falsification:
  `boundary_condition_falsification.csv`.
- Conservation, boundary, temperature, and linear-system gates:
  `native_bvp_gates.csv`.
- Target-free grid coarsening:
  `native_bvp_grid_convergence.csv`.
- Sensor-level direction of change:
  `native_sensor_direction_audit.csv`.
- Regional hydraulic leverage and target requirements:
  `component_pressure_sensitivity_summary.csv` and
  `hydraulic_target_requirement_summary.csv`.
- Temperature-dependent-friction double-count boundary:
  `decreasing_fT_double_count_audit.csv`.
- Frozen 68-rank execution matrix and target-use audit:
  `frozen_run_matrix.csv`.

`SOURCE_MANIFEST.csv` records the upstream path and SHA-256 digest for every
copied file.  The paper-root-relative and repository-logical forms of those
paths are registered in `../UPSTREAM_SOURCE_LOCATOR_MANIFEST.csv`; no absolute
working-directory path is required.  The two manuscript figures are
byte-identical copies of the
canonical PDFs; their hashes and regeneration command are recorded in
`../FIGURE_SOURCE_MANIFEST.csv`.

## Do not infer

- The selected `r=0.02`, `alpha=0.15`, or `chi=0.02` is not an admitted
  physical coefficient or uncertainty interval.
- The one-way TW shift is not a conjugate wall prediction.
- The pressure target extrapolations are measurement requirements, not fitted
  component losses.
- The predeclared 1000/1500 W development, 500/1012.8 W no-refit, and
  prospective-insulation results remain outside this nominal package.
