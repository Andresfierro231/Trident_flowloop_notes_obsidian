# Mass-flow trend refresh

This compact package supplies the localized-model points added to
`figures/pdf/csem_scientific_triage_mdot_trend.pdf`. It covers the two
frozen localized settings over the four nominal development cases and the six
heater-power test cases: Salt2 at $-10\%$, $-5\%$, $+5\%$, and $+10\%$, plus
Salt4 at $-10\%$ and $+10\%$.

`localized_mdot_cases.csv` extracts only setup heater power and solved mass
flow from each frozen terminal JSON. `localized_six_case_scorecard.csv` is a
value-preserving CSV copy of the released aggregate grade.
`temperature_parity_six_case_sensor_scores.csv` is the 390-row compact plotting
population for P1, P2-CFD, and Localized-CFD: 24 TP and 28 TW training rows plus
36 TP and 42 TW test rows per model. Its test population exactly matches the
six-case result table. `SOURCE_MANIFEST.csv` records each upstream path and
SHA-256 digest.

The figure generator joins these rows with the retained P-series nominal,
Salt2 $\pm5\%$, and Salt2/Salt4 $\pm10\%$ evidence. It performs no solver run,
fit, candidate selection, or target update. The six test outcomes had been
encountered previously, and the localized-CFD hydraulic multiplier was
selected using nominal CFD mass flow. The plot is therefore a retrospective
grade, not prospective validation.
