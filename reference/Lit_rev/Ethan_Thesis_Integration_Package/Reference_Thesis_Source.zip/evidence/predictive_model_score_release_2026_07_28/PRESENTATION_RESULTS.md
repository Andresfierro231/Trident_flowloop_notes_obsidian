---
provenance:
  - all_model_training_scorecard.csv
  - holdout_candidate_scorecard.csv
  - holdout_case_scorecard.csv
tags: [thesis, defense, predictive-1d, holdout, results]
related:
  - SCORING_AND_HOLDOUT_METHOD.md
  - MODEL_CLOSURE_NARRATIVE.md
task: TODO-CSEM-PREDICTIVE-SCORE-RELEASE-2026-07-28
date: 2026-07-28
role: Writer
type: presentation-brief
status: complete
---
# Presentation-ready predictive-model results

## Headline

The nine model forms have complete, common-policy nominal training grades and
complete grades on the declared Salt2 -5%/+5% heater-power holdout partition.
All 18 holdout roots were accepted. The holdout preserves the same qualitative
model choice reached on training data: P1 remains the balanced-temperature
leader, while P2-CFD remains the CFD-mass-flow leader.

## Common-policy results

| Role | Model | Training TP | Training TW | Training balanced | Training CFD mdot | Holdout TP | Holdout TW | Holdout balanced | Holdout CFD mdot |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| TP training leader | C6 | 7.958 K | 10.457 K | 9.292 K | 37.346% | 7.697 K | 10.788 K | 9.370 K | 40.242% |
| balanced-temperature model | P1 | 7.987 K | **10.414 K** | **9.280 K** | 42.411% | 7.702 K | **10.754 K** | **9.354 K** | 43.846% |
| experimental-mdot compromise | P2-exp | 7.971 K | 10.691 K | 9.430 K | 18.259% | **7.686 K** | 11.056 K | 9.521 K | 18.468% |
| CFD-mdot-calibrated model | P2-CFD | 8.040 K | 10.944 K | 9.602 K | **3.505%** | 7.765 K | 11.325 K | 9.710 K | **3.409%** |

Training includes Salt1--Salt4 nominal. Holdout includes Salt2 at -5% and +5%
heater power. TP includes TP2; TW excludes TW4--TW6 and TW10.

## What transferred

- P1 balanced temperature changes from 9.280 K in training to 9.354 K on the
  declared holdout, a difference of only +0.074 K.
- P2-exp balanced temperature changes from 9.430 K to 9.521 K, while CFD-mdot
  MAPE remains essentially unchanged at 18.259% versus 18.468%.
- P2-CFD balanced temperature changes from 9.602 K to 9.710 K, while CFD-mdot
  MAPE changes from 3.505% to 3.409%.
- The declared segment thermal map remains decisively rejected: P3/P4
  holdout balanced errors are approximately 163.5--163.7 K.
- The F3 junction/eta branch C5 remains poor thermally, with a 26.714 K
  holdout balanced error.

## Recommended defense wording

“Under one declared sensor policy, all nine physical model forms were graded
on four nominal development cases and two fit-forbidden Salt2 power
perturbations. The balanced-temperature model, P1, produced 9.28 K training and
9.35 K holdout RMSE. A separately labeled CFD-mdot-calibrated P2 branch
produced 3.50% training and 3.41% holdout CFD-mdot MAPE at a modest temperature
cost. These results demonstrate stable retrospective transfer across the
declared split; they do not constitute pristine prospective or experimental
validation.”

## Limits that remain visible

1. The PM5 cases are the declared holdout partition, but their CFD outcomes had
   prior repository exposure. They must be called retrospective holdout.
2. P2-CFD was calibrated after nominal CFD-mdot residuals were known. Its PM5
   result is no-refit transfer after that calibration, not validation of a
   universal friction law.
3. P1/P2 use a global 0.08 base-insulation-thickness multiplier. The solver
   applies it before recomputing cylindrical insulation resistance; it is not
   a direct resistance multiplier or measured as-built insulation.
4. No current form explicitly resolves the upcomer throughflow and
   recirculation streams as separate states.
5. The older CFD affine discrepancy ROM has a different sensor population and
   is not merged into this R2 table.

## Assets

- `holdout_model_comparison_presentation.pdf`: preferred vector defense figure.
- `all_model_training_scores.pdf`: nominal training comparison.
- `table_predictive_model_training_scores.tex`: LaTeX training table.
- `table_predictive_model_pm5_holdout_scores.tex`: LaTeX holdout table.
- `SCORING_AND_HOLDOUT_METHOD.md`: method and reproduction reference.
