---
provenance:
  - config/thesis_scoring_policy.yaml
  - work_products/2026-07/2026-07-16/2026-07-16_tp2_1d_model_evidence/README.md
  - work_products/2026-07/2026-07-28/2026-07-28_f3_eta_junction_mdot_factorial/README.md
  - work_products/2026-07/2026-07-28/2026-07-28_thesis_predictive_closure_campaign/PREDECLARED_CANDIDATES.json
  - reports/2026-07/2026-07-22/2026-07-22_litrev_latest_modeling_handoff/README.md
  - ../cfd-modeling-tools/tamu_first_order_model/Fluid/tamu_loop_model_v2/friction_closures.py
tags: [thesis, predictive-1d, closure-selection, TP2, CFD-affine, model-grading]
related:
  - operational_notes/2026-07-28_thesis_predictive_closure_campaign.md
  - operational_notes/maps/forward-predictive-model.md
  - work_products/2026-07/2026-07-28/2026-07-28_thesis_predictive_closure_campaign
task: TODO-THESIS-PREDICTIVE-CLOSURE-CAMPAIGN-2026-07-28
date: 2026-07-28
role: Writer / Reviewer
type: thesis-ready report
status: complete
---
# Predictive one-dimensional model: closure selection and grading

## Scope and claim boundary

This report documents how the current one-dimensional natural-circulation
model forms were chosen, what each form assumes, how they were scored, and why
the physical predictive model and the CFD-affine discrepancy model must be
reported as separate products.

The physical candidates are steady, segment-resolved `fluid+walls` models.
They use setup-known geometry, heater power, air-side conditions, material
properties, and predeclared closure dictionaries. CFD TP, TW, and mass-flow
targets are joined only after the solver writes its predictions. The campaign
is a Salt1–Salt4 nominal training/model-comparison study. It is not a pristine
protected validation and it does not, by itself, release unresolved
source/property admission gates.

The CFD-affine model is an empirical discrepancy model:

\[
T_{\mathrm{affine}} = aT_{\mathrm{1D}}+b.
\]

It is useful as a compact CFD-ROM benchmark, but \(a\) and \(b\) are not
friction factors, heat-transfer coefficients, or other physical closures.

## Why TP2 was excluded—and why that exclusion is no longer justified

TP2 was originally excluded because its provisional Cartesian coordinate did
not lie consistently on the one-dimensional loop path. With that coordinate,
the generic arc-interpolation routine emitted a non-finite TP2 prediction.
Excluding a non-finite row was appropriate at that stage; it prevented an
undefined value from silently entering the aggregate.

The exclusion became stale after the July 16 TP2 evidence package defined and
audited a one-dimensional projection:

- physical location: bottom of the right downcomer;
- canonical 1D location:
  `right_downcomer_bottom_horizontal_junction`;
- computational representation: end of `right_vertical`, equivalently the
  start of `bottom_horizontal_inlet`;
- allowed use: post-solve validation and grading;
- forbidden uses: runtime temperature input and fit/calibration target.

The present campaign requires five explicit gates before TP2 enters an
aggregate:

1. the source segment is named;
2. the one-dimensional projection is defined;
3. the projected prediction is finite for every scored case;
4. TP2 is absent from runtime inputs;
5. TP2 is absent from fit targets.

All five gates passed before solver launch. The campaign therefore uses six TP
rows per case. Merely deleting `TP2` from an exclusion list would not have been
sufficient; the runner replaces the solver's non-finite generic projection
with the audited end-of-downcomer state and records the prediction source.

The thesis-facing policy is:

> TP includes TP2; TW excludes TW4–TW6 and TW10.

TW4–TW6 and TW10 remain in per-sensor tables and plots as diagnostic evidence;
they are omitted only from aggregate grades and model selection.

## Governing model

The model closes a steady loop energy balance and a loop pressure balance.
At a high level,

\[
\dot Q_{\mathrm{heater\rightarrow salt}}
-\dot Q_{\mathrm{HX}}
-\dot Q_{\mathrm{passive}}
-\dot Q_{\mathrm{other}}=0
\]

and

\[
\Delta p_{\mathrm{buoyancy}}
-\Delta p_{\mathrm{distributed}}
-\Delta p_{\mathrm{entry}}
-\Delta p_{\mathrm{minor}}=0.
\]

Density, viscosity, heat capacity, and thermal conductivity vary with the
local bulk state. The geometry is split at sensor locations and is further
subdivided to a maximum axial length of 0.01875 m. The nonlinear solution is
accepted only if both pressure and temperature roots are bracketed, the final
root status is accepted, and the energy/periodicity residual passes.

This architecture is consistent with the literature-review recommendation to
use a segmentwise, developing-flow network rather than a single global
friction factor, global Nusselt number, or global UA. It does not yet resolve a
simultaneous throughflow/recirculation cell in the upcomer.

## Model-form genealogy

### Fully developed laminar reference, F1

The reference Darcy factor is

\[
f_D=\frac{64}{Re}, \qquad
\Delta p=f_D\frac{L}{D}\frac{\rho U^2}{2}.
\]

This is a useful limiting reference, but the literature review does not
support it as a universal active closure after bends, junctions, entrance
resets, or strong thermal development.

### F3 Hagenbach entry defect

The first developing-pressure correction retained fully developed
distributed friction and added a one-time entry defect at the first
subsegment of each physical section:

\[
\Delta p_{\mathrm{F3,H}}=
\frac{64}{Re}\frac{L}{D}\frac{\rho U^2}{2}
+K_\infty\frac{\rho U^2}{2},
\qquad K_\infty=1.33.
\]

This form is simple and numerically robust, but \(K_\infty\) represents the
asymptotic momentum defect. It does not integrate the enhanced wall shear
through a short developing section.

### Shah apparent developing friction

The Shah form evaluates the apparent developing Darcy factor from

\[
x^+=\frac{L}{DRe},
\]

\[
(f_{\mathrm{app}}Re)_{\mathrm{Fanning}}
=\frac{3.44}{\sqrt{x^+}}
+\frac{16+0.244}{1+0.000212/(x^+)^2},
\]

with Darcy factor equal to four times the Fanning value. It therefore contains
both developing wall shear and the momentum defect and reverts to the
fully-developed form on non-entry subsegments.

Shah was selected for the new screen because it is the source-backed
developing-pressure form already implemented in Fluid and addresses a clear
limitation of the simpler Hagenbach cell without introducing a fitted
parameter in this campaign.

### F6 leg-class \(\phi(Re)\) correction

F6 applies a CFD-derived leg-class multiplier to the Shah pressure drop:

\[
\Delta p_{\mathrm{F6}}=
\phi(Re,\mathrm{leg})\Delta p_{\mathrm{Shah}}.
\]

The implemented functions are

\[
\phi_{\mathrm{heater}}=2.0505Re^{-0.0272},
\]

\[
\phi_{\mathrm{cooler}}=1.9177Re^{-0.0502},
\]

\[
\phi_{\mathrm{downcomer}}=1.8112.
\]

Only three Salt2–Salt4 calibration points support each admitted ordinary leg,
over approximately \(60\lesssim Re\lesssim135\). The heater trend is weak, the
cooler trend is clearer, and the downcomer is held constant because its
apparent Reynolds trend is confounded with Richardson number. Extrapolation
above \(Re=200\) is not authorized.

The upcomer is deliberately excluded: its multiplier is one, so F6 reduces to
Shah there. CFD evidence shows contradictory segment behavior and
recirculation, making a single-stream upcomer friction fit physically
misleading. F6 is consequently a bounded hydraulic sensitivity, not a final
recirculation closure.

## Thermal-boundary and source ablations

### Heater efficiency

The historical heater form applies

\[
\dot Q_{\mathrm{salt}}=\eta_h\dot Q_{\mathrm{electrical}},
\qquad \eta_h=0.989703290269.
\]

The eta × junction factorial found that this is a small correction relative to
the junction choice. It remains useful provenance but is not the dominant
source of the TP/TW or CFD-mdot tradeoff.

### Junction heat

The PASSIVE-H2 setup can carry an imported setup/operator heat-loss row for the
junction/stub family. The factorial compared otherwise matched F3 states with
and without this family.

On the former five-TP policy, removing junction heat improved TP and TW RMSE
by approximately 15.4 K each, while worsening CFD-mdot MAPE by approximately
26 percentage points. This established causal attribution: the no-junction
state is the main reason the thermal score improved and the main reason the
CFD-mdot score degraded. It did not prove that physical junction heat is zero.

The new closure screen holds eta at one and junction heat absent so that the
friction and boundary-map effects are identifiable against the temperature-
leading C6 state.

### Global compensation versus declared segment map

The temperature-leading F3 state used a global outer-insulation-thickness
multiplier of 0.08. The solver applies this multiplier to the base insulation
thickness before recomputing cylindrical insulation resistance; it does not
multiply the completed resistance by 0.08. This is a strong compensation and
is not the preferred physical endpoint.

The alternative is the pre-existing Fluid segment map:

| Parent segment | Multiplier |
|---|---:|
| heated incline | 0.85 |
| left lower vertical | 0.90 |
| test section | 0.95 |
| left upper vertical | 0.90 |
| right vertical | 1.40 |
| cooler pre-HX | 1.50 |
| cooler post-HX | 1.50 |

Unlisted parents retain one. The quartz test section's own insulation flag
still controls whether the multiplier is active. This map is treated as a
declared setup screen inherited from the practical reduced-order
configuration—not as an as-built measurement and not as a parameter fit in
this campaign.

## Predeclared closure screen

Four new candidates form a friction × boundary-map factorial:

| ID | Friction | Thermal boundary | Junction | Heater eta |
|---|---|---|---|---:|
| P1 | Shah apparent | global 0.08 thickness factor | absent | 1 |
| P2 | F6 \(\phi(Re)\) over Shah | global 0.08 thickness factor | absent | 1 |
| P3 | Shah apparent | declared segment map | absent | 1 |
| P4 | F6 \(\phi(Re)\) over Shah | declared segment map | absent | 1 |

C5 (F3 Hagenbach, eta, junction) and C6 (F3 Hagenbach, eta one, no junction)
are rescored as references using the restored TP2 projection. The older C0–C4
scorecards are retained as historical evidence but are not mixed into the new
leaderboard because their archived runtime package did not preserve segment
states needed for the TP2 projection.

## Training and grading protocol

This is constrained physical model selection, not neural-network training.

1. Freeze the candidate equations, cases, source hashes, geometry refinement,
   sensor policy, and selection metrics.
2. Verify the five TP2 gates.
3. Construct Salt1–Salt4 scenarios from setup-known PASSIVE-H2 operator rows.
4. Run one target-free solver branch per candidate.
5. Require four terminal cases, four accepted roots, four energy-root passes,
   and four finite projected TP2 values.
6. Only after every candidate is terminal, open CFD TP/TW, experimental mdot,
   and CFD mdot targets.
7. Retain all finite per-sensor residuals; apply the aggregate sensor policy.
8. Report TP and TW RMSE separately and their balanced RMS:

\[
E_{T,\mathrm{bal}}=
\sqrt{\frac{E_{TP}^2+E_{TW}^2}{2}}.
\]

9. Report experimental-mdot and CFD-mdot errors separately. CFD mdot is
   available for Salt2–Salt4; experimental mdot covers Salt1–Salt4.
10. For a three-objective view, scale TP RMSE by 10 K, TW RMSE by 10 K, and
    mdot MAPE by 10%, then take the RMS of the three normalized objectives.
11. Mark the nondominated TP/TW/mdot candidates. Do not collapse conflicting
    objectives into an unqualified statement that one candidate is universally
    “best.”

## Results

All 16 new candidate/case solves passed the accepted-root, energy, and
finite-TP2 gates. The policy-R2 Salt1–Salt4 training comparison is:

| Model | TP RMSE K | TW RMSE K | Balanced K | Experimental mdot MAPE % | CFD mdot MAPE % |
|---|---:|---:|---:|---:|---:|
| C5, F3 eta + junction | 24.333 | 26.663 | 25.524 | 7.062 | **10.150** |
| C6, F3 no junction | **7.958** | 10.457 | 9.292 | 11.002 | 37.346 |
| P1, Shah + global 0.08 | 7.987 | **10.414** | **9.280** | 14.555 | 42.411 |
| P2, F6 + global 0.08 | 7.971 | 10.691 | 9.430 | **5.661** | 18.259 |
| P3, Shah + segment map | 169.331 | 168.163 | 168.748 | 80.697 | 119.265 |
| P4, F6 + segment map | 169.744 | 168.255 | 169.001 | 60.100 | 94.967 |

### Temperature selection

C6 has the lowest TP RMSE, P1 has the lowest TW RMSE, and P1 has the lowest
balanced TP/TW RMSE. The differences among C6, P1, and P2 are small:
their balanced errors span only 0.150 K. P1 is therefore frozen as the
predeclared balanced-temperature selection.

Restoring TP2 did not overturn the prior C6 conclusion, but it changed the
reported value honestly: the C6 TP RMSE moves from 7.707 K on the old five-TP
basis to 7.958 K on the six-TP basis. C5 moves from 23.850 K to 24.333 K.

### Joint temperature and mass-flow selection

P2 is the best normalized TP/TW/mdot candidate on both mass-flow bases. Against
P1, enabling F6:

- changes TP RMSE by −0.015 K;
- changes TW RMSE by +0.277 K;
- changes balanced temperature RMSE by +0.150 K;
- improves experimental-mdot MAPE by 8.894 percentage points;
- improves CFD-mdot MAPE by 24.152 percentage points.

This is the most useful positive closure result: F6 recovers a substantial
portion of the mdot degradation without sacrificing the low temperature
error. It does not fully match CFD mdot—the remaining Salt2–Salt4 CFD-mdot
errors for P2 are 18.61%, 17.92%, and 18.24%—but the residual is coherent
rather than case-directionally unstable.

C5 remains the best pure CFD-mdot model at 10.15% MAPE, at the cost of roughly
24–27 K temperature RMSE. The model choice is therefore objective-dependent:
P1 for temperature alone, P2 for the three-QOI compromise, and C5 only if CFD
mdot is treated as dominant.

### Boundary-map falsification

Replacing the global 0.08 compensation with the declared segment map increases
the average balanced temperature RMSE by 159.52 K. It also worsens average
experimental-mdot MAPE by 60.29 points and CFD-mdot MAPE by 76.78 points.
F6 reduces mdot error inside the segment-map branch but cannot repair its
thermal state.

The low-error model is consequently not yet the ideal physical predictive
model. It is an accurate compensated model state. A thesis claim should state
that the compensation identifies a missing thermal-boundary/source term; it
should not interpret 0.08 as a measured insulation property.

### Recommended thesis model labels

Use objective-qualified labels rather than one universal winner:

- **Main compensated predictive model:** P2, F6 + global 0.08. This is the best
  current TP/TW/mdot compromise and the recommended main physical-model
  scorecard for the thesis.
- **Temperature-leading compensated model:** P1, Shah + global 0.08. Use this
  for the best TP/TW trend figure and the frozen retrospective transfer stress.
- **CFD-mdot-leading reference:** C5, F3 + eta + junction. Retain it to show the
  temperature cost of prioritizing mdot.
- **Physical-boundary falsification:** P3/P4. Retain these as negative evidence
  showing that the declared segment map does not replace the global thermal
  compensation.

The word “compensated” is essential. P2 is fully predictive with respect to
runtime target leakage—it does not consume scored TP/TW/mdot values—but its
global boundary multiplier is not yet an independently measured physical
property.

### Distance from the ideal predictive model

Numerically, P2 is close on temperature and moderately close on mdot:
approximately 8.0 K TP RMSE, 10.7 K TW RMSE, and 18.3% CFD-mdot MAPE. The
remaining gap is not primarily a need for a more flexible global fit. The
evidence points to two missing physical structures:

1. a setup-backed, segment-resolved thermal-boundary/source model that can
   reproduce the current temperature level without the global 0.08
   compensation;
2. a throughflow-plus-recirculation hydraulic model for the upcomer, because
   the available F6 single-stream fit is intentionally inactive there.

For thesis closure, freezing P2/P1 with the present caveats, completing the
retrospective transfer row, and policy-conforming documentation is a
hours-scale task. Replacing the compensation with an independently sourced
thermal boundary and validating a recirculation state is a research campaign:
roughly several focused compute days plus evidence review, and should be
planned as one to two weeks rather than represented as a final-hour
coefficient adjustment.

### Retrospective no-refit Salt2 −10%Q transfer

P1 was frozen from the four nominal training cases before the Salt2 −10%Q
target was opened. The transfer script wrote and hashed the runtime
predictions first, then joined the previously exposed CFD target without
selection or refitting:

| Model/case | TP RMSE K | TW RMSE K | Balanced K | Predicted mdot kg/s | CFD mdot error % |
|---|---:|---:|---:|---:|---:|
| Frozen P1 / Salt2 −10%Q | 9.812 | 14.588 | 12.432 | 0.017013 | 42.068 |

The temperature error increases relative to P1's nominal four-case aggregate
(9.280 K balanced) but remains within a few kelvin, so the compensated thermal
trend transfers reasonably to this lower-power stress. The hydraulic
discrepancy does not: its 42.1% CFD-mdot error is essentially the same scale as
P1's 42.4% nominal CFD-mdot MAPE. This independently reinforces the model-form
diagnosis that ordinary-leg developing friction is not enough; the missing
upcomer throughflow/recirculation structure remains the dominant next
hydraulic target.

This is not a pristine holdout. The Salt2 −10%Q target was available in prior
analysis, so the row is reported only as a retrospective, post-freeze,
no-refit stress.

## Models considered but not promoted

MF12, a bulk-to-TP correction form, remains diagnostic because its source
amplitude, property labels, same-QOI projection uncertainty, and runtime
wall/profile basis are not released.

UMX1 and TSWFC2 can execute roots, but the currently tested variants did not
improve the required scorecards and are explicitly blocked from grid
expansion. They are negative evidence, not missing rows to be quietly omitted.

A monotone upcomer \(f(T)\) law was not promoted. Temperature already changes
properties and Reynolds number, while the CFD upcomer segments show opposing
friction behavior under recirculation. A throughflow-plus-recirculation state
is the defensible next form, but it needs source-supported state variables,
exchange flow, energy closure, and an independent calibration/validation
contract.

## Predictive model versus CFD-affine model

The physical screen asks whether setup-known inputs and named closures can
predict loop behavior. Its scores therefore diagnose closure sufficiency.

The CFD-affine track asks whether a two-degree-of-freedom discrepancy layer can
map an existing 1D temperature field to CFD. The previously published
all-four fit,

\[
T_{\mathrm{affine}}=0.7669693428T_{\mathrm{1D}}+29.8909296\ {\rm K},
\]

was fit on 60 rows under the old TP2/TW10 exclusion policy. Its historical
Salt2 ±5%Q combined RMSE was 9.27 K and its partial `val_salt2` external RMSE
was 10.25 K. Those values remain valid descriptions of that frozen historical
model, but they are not presented as policy-R2 scores because TP2 was absent
and TW4–TW6 were included.

For thesis comparison, one of two scientifically honest choices is required:

1. retain the frozen affine model and label its sensor policy explicitly; or
2. refit the same two-parameter form on the new 52-row Salt1–Salt4 policy,
   freeze it, and rerun the retrospective transfer score with finite TP2.

The report does not manufacture comparability by relabeling the old 60-row
score. Regardless of which affine version is used, it remains an empirical
discrepancy ROM, not an admitted physical closure.

## Thesis interpretation

The model-development sequence should be presented as an evidence ladder:

1. fully developed friction supplied a reference but omitted development;
2. the Hagenbach form introduced entry momentum loss;
3. the no-junction ablation exposed a strong thermal/mdot tradeoff;
4. Shah tested a more complete source-backed developing-pressure form;
5. F6 tested whether ordinary-leg CFD friction structure recovers mdot without
   assigning a false single-stream upcomer correlation;
6. the boundary-map ablation tested whether low temperature error survives
   removal of the global 0.08 compensation;
7. blocked recirculation and wall-state forms were retained as negative
   evidence and future work;
8. a separate affine discrepancy track quantified the attainable compact ROM
   accuracy without calling empirical coefficients physics.

The strongest defensible conclusion is not that one scalar coefficient solved
the loop. It is that temperature accuracy, mass-flow accuracy, thermal-boundary
assumptions, and recirculating hydraulic structure are distinguishable. The
factorial studies reveal which assumption moves which observable and prevent a
good aggregate score from hiding compensating errors.
