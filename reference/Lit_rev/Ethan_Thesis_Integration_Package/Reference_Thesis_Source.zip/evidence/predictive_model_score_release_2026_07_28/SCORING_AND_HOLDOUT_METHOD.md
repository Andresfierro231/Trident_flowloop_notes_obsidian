---
provenance:
  - tools/analyze/run_thesis_predictive_closure_campaign.py
  - tools/analyze/run_predictive_pm5_holdout_grade.py
  - config/thesis_scoring_policy.yaml
tags: [thesis, predictive-1d, scoring, holdout, reproducibility]
related:
  - README.md
  - FROZEN_HOLDOUT_CONTRACT.json
task: TODO-CSEM-PREDICTIVE-SCORE-RELEASE-2026-07-28
date: 2026-07-28
role: Writer / Tester
type: method
status: complete
---
# Training and holdout grading method

## Purpose

This document is the step-by-step reference for reproducing the thesis-facing
grades. It separates model fitting and selection from holdout evaluation and
states exactly where prior data exposure limits the validation claim.

## Data partition

The canonical split is:

1. Salt1--Salt4 nominal: training and model-form selection;
2. Salt2 at -5% and +5% heater power: holdout/testing only;
3. `val_salt2`: separate external-test row;
4. additional perturbations: support or future holdout only under their dated
   admission labels.

The two PM5 rows are fit-forbidden and model-selection-forbidden. Their CFD
outcomes had already been examined in earlier repository work, so they remain
the declared holdout partition but are not pristine first-exposure data.

## Nominal training grade

1. Define each model form before runtime, including heater efficiency,
   friction form, global or segment thermal compensation, distributed-loss
   multiplier, and junction state.
2. Solve Salt1--Salt4 with setup/operator inputs only. TP, TW, experimental
   mass flow, and CFD mass flow are not runtime inputs.
3. Require a bracketed pressure root, bracketed temperature-periodicity root,
   accepted terminal status, finite heat terms, and finite TP2 projection.
4. Project TP2 from the bulk temperature at `right_vertical@end`, which is
   topologically the same point as `bottom_horizontal_inlet@start`.
5. Only after all candidate/case runtime receipts exist, join the CFD
   temperature targets and the two mass-flow reference bases.
6. Score TP1--TP6, including TP2. Score TW1--TW11 after excluding TW4, TW5,
   TW6, and TW10. This gives 24 TP and 28 TW observations per model over four
   nominal cases.
7. Report experimental-mdot and CFD-mdot errors separately. They answer
   different questions and are never averaged into one unlabeled target.

For an included sensor error \(e_i=T_{i,\mathrm{1D}}-T_{i,\mathrm{CFD}}\),

\[
\mathrm{RMSE}=\sqrt{\frac{1}{N}\sum_{i=1}^{N}e_i^2}.
\]

The balanced temperature metric gives TP and TW equal group weight:

\[
E_{\mathrm{bal}}=
\sqrt{\frac{\mathrm{RMSE}_{TP}^2+\mathrm{RMSE}_{TW}^2}{2}}.
\]

Mass-flow percentage error is

\[
\epsilon_{\dot m}=100
\frac{\dot m_{\mathrm{1D}}-\dot m_{\mathrm{reference}}}
     {\dot m_{\mathrm{reference}}},
\]

and MAPE is the mean absolute value over the cases for which that reference is
available.

## Holdout freeze and target join

1. Freeze all nine model definitions and their thesis labels from the completed
   nominal comparison in `FROZEN_HOLDOUT_CONTRACT.json`.
2. Verify that both PM5 rows are score-allowed, fit-forbidden, and
   model-selection-forbidden in the canonical split table.
3. Run each frozen form at heater-power ratios 0.95 and 1.05. All other
   candidate settings remain unchanged.
4. Write target-free runtime, sensor-prediction, and segment-ledger files.
5. Require two accepted roots and energy checks for every model form.
6. Hash each runtime and sensor-prediction file in its `RUN_COMPLETE.json`.
7. Verify all hashes and write `FROZEN_HOLDOUT_PREDICTIONS.json`. This receipt
   must exist before the target join.
8. Open the CFD TP/TW landmark tables and terminal-window CFD mass flow only
   during the separate `--score` command.
9. Apply the same R2 policy. Over two holdout cases, every model must have 12 TP
   and 14 TW observations.
10. Write sensorwise, casewise, and aggregate grades. Do not refit, reselect,
    or change the final thesis label after opening the holdout results.

## Reproduction

From the Ethan run workspace:

```bash
python3.11 tools/analyze/run_predictive_pm5_holdout_grade.py --preflight
python3.11 tools/analyze/run_predictive_pm5_holdout_grade.py \
  --run-candidate <candidate_id>
python3.11 tools/analyze/run_predictive_pm5_holdout_grade.py \
  --freeze-predictions
python3.11 tools/analyze/run_predictive_pm5_holdout_grade.py --score
python3.11 tools/publish/build_csem_predictive_score_release.py
```

The nine candidate runs are independent and may be executed concurrently on
separate one-core Slurm steps. The freeze and score commands are serial gates
after every candidate has completed.

## Interpretation contract

- `P1` may be called the nominal balanced-temperature training leader.
- `P2-exp` may be called the nominal experimental-mdot composite leader.
- `P2-CFD` may be called the CFD-mdot-calibrated training model.
- PM5 values may be called split-designated retrospective holdout grades.
- No value in this package may be called pristine blind validation,
  experimental validation, a universal physical correlation, or proof of a
  frozen runtime-legal physical closure.
- The older CFD affine ROM is a separate empirical discrepancy model with a
  different score population. Its reported PM5 grade must not be merged into
  the R2 physical-model table without restoring TP2 and the current TW policy.
