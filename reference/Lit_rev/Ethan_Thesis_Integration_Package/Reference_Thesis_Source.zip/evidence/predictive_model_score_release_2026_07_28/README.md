---
provenance:
  - work_products/2026-07/2026-07-28/2026-07-28_thesis_predictive_closure_campaign/training_candidate_scorecard.csv
  - work_products/2026-07/2026-07-28/2026-07-28_tp2_exact_geometry_p2_friction_audit/training_candidate_scorecard.csv
tags: [thesis, predictive-1d, model-grading, TP2, CSEM]
related:
  - reports/2026-07/2026-07-28/2026-07-28_thesis_predictive_model_closure_narrative/README.md
  - reports/2026-07/2026-07-28/2026-07-28_tp2_exact_geometry_p2_friction_audit/README.md
task: TODO-CSEM-PREDICTIVE-SCORE-RELEASE-2026-07-28
date: 2026-07-28
role: Coordinator / Writer / Tester
type: work_product
status: complete
---
# Predictive-model score release for CSEM

This evidence-only package gives the CSEM dissertation a single, internally
consistent source for the completed July 28 nominal training grades. All nine
rows use the same policy: **TP includes TP2; TW excludes TW4-TW6 and TW10**. Each aggregate has 24 TP rows, 28 TW
rows, and complete accepted roots.

## Objective-specific results

- Lowest TP RMSE: **C6**, 7.958 K.
- Lowest TW RMSE: **P1**, 10.414 K.
- Lowest balanced TP/TW RMSE: **P1**, 9.280 K.
- Best TP/TW/experimental-mdot composite: **P2-exp**, with experimental-mdot
  MAPE 5.661%.
- Best TP/TW/CFD-mdot composite: **P2-CFD**, with CFD-mdot MAPE
  3.505%.

P2-CFD changes TP and TW RMSE by only
+0.068 K and
+0.253 K,
respectively, relative to P2-exp, while reducing the CFD-mdot MAPE from
18.259% to
3.505%.

## What is and is not complete

The common-policy nominal **training** grade is complete for every model form
in this package. The package also retains casewise and sensorwise scores,
the exact TP2 geometry audit, signed P2 mass-flow errors, the resistance
sensitivity, and the retrospective Salt2 -10% heater-power transfer score.

No protected holdout or external validation grade is created here. P2-CFD was
selected after the CFD mass-flow residual was known. It must be described as a
CFD-mdot-calibrated training model, not as independent predictive validation.
The Salt2 -10% transfer is no-refit but retrospective because that target had
been exposed in earlier work.

## Writer assets

- `all_model_training_scorecard.csv`: controlling nine-row aggregate table.
- `all_model_training_case_scores.csv`: 36 casewise rows.
- `all_model_training_sensor_scores.csv`: sensorwise scoring rows.
- `model_selection_summary.csv`: objective-specific leaders.
- `scoring_completeness_audit.csv`: machine-readable release gates.
- `table_predictive_model_training_scores.tex`: LaTeX aggregate table.
- `table_predictive_model_training_leaders.tex`: LaTeX leader table.
- `all_model_training_scores.*`: PNG/PDF/SVG comparison figure.
- `MODEL_CLOSURE_NARRATIVE.md`: full model-form genealogy and assumptions.
- `TP2_AND_RESISTANCE_AUDIT.md`: exact TP2 station and P2 friction result.
- `provenance_manifest.csv`: source and release hashes.

## Claim boundary

CFD is high-fidelity computational reference evidence, not experimental
validation. The global 0.08 base-insulation-thickness factor and P2-CFD
distributed-loss multiplier are compensated/calibrated model parameters, not
measured rig properties. The solver applies the former before recomputing
cylindrical insulation resistance; it is not a direct resistance multiplier.
F6 does not model upcomer recirculation as a physical two-state closure.


## Split-designated holdout grade

All nine forms were frozen from the nominal comparison and evaluated at the
declared Salt2 -5% and +5% heater-power rows without fitting or selecting on
those rows. All 18 roots were accepted. The policy-R2 aggregate contains 12 TP
and 14 TW observations per form.

- P1 holdout: TP 7.702 K, TW
  10.754 K, balanced
  9.354 K, CFD-mdot MAPE
  43.846%.
- P2-exp holdout: TP 7.686 K, TW
  11.056 K, balanced
  9.521 K, CFD-mdot MAPE
  18.468%.
- P2-CFD holdout: TP 7.765 K, TW
  11.325 K, balanced
  9.710 K, CFD-mdot MAPE
  3.409%.

These are real grades on the declared holdout partition, but the CFD outcomes
had been exposed in earlier retrospective work. The precise label is
**split-designated retrospective holdout**, not pristine prospective or blind
validation. No coefficient was changed after this score was opened.
