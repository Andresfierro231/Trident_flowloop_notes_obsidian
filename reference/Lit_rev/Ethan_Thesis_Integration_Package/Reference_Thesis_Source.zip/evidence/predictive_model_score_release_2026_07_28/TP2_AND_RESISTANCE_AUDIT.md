---
provenance:
  - reference/geometry_reference.md
  - jadyn_runs/salt2/2026-06-01_continuation_candidate/tp_tw_probe_locations.csv
  - ../cfd-modeling-tools/tamu_first_order_model/Fluid/tamu_loop_model_v2/geometry.py
  - work_products/2026-07/2026-07-28/2026-07-28_tp2_exact_geometry_p2_friction_audit
tags: [thesis, TP2, geometry, P2, friction, mdot]
related:
  - operational_notes/2026-07-28_tp2_exact_geometry_p2_friction_audit.md
  - operational_notes/maps/geometry-and-mesh-truth.md
task: TODO-TP2-EXACT-GEOMETRY-P2-FRICTION-AUDIT-2026-07-28
date: 2026-07-28
role: Writer / Reviewer
type: report
status: complete
---
# Exact TP2 station and P2 hydraulic-resistance audit

## Exact TP2 geometry

The CFD temperature-probe registry specifies TP2 at

\[
(x,y,z)=(0.887519,-0.245426,0)\ {\rm m}.
\]

That coordinate is exact for CFD sampling, but the repository's authoritative
geometry reference warns that the probe CSV is a schematic whose lower/right
leg names are spatially swapped relative to the mesh. The coordinate must not
be projected directly into the reduced 1D Cartesian frame to infer topology.

The Fluid geometry supplies the exact named 1D station:

```text
right_vertical (downcomer)
  -> TP2
  -> bottom_horizontal_inlet (1 inch)
  -> heated_incline
```

In code, TP2 is simultaneously `right_vertical@end` and
`bottom_horizontal_inlet@start`. The heated incline starts one inch
downstream. This matches the physical description “at the bottom of the
downcomer, before the heater incline.”

The July 28 scoring projection is therefore retained. It was topologically
correct, although its earlier documentation should have cited the exact probe
coordinate and `geometry.py` relation more prominently.

As a falsification check, the preserved P2 segment ledger was sampled at the
other plausible verbal interpretation—the beginning of the heated incline.
That moves the predicted temperature down by only `0.121–0.128 K`. P2 already
underpredicts TP2 by `0.70–13.29 K`, so the alternate station would worsen,
not improve, every TP2 residual.

## Is P2 overpredicting mass flow?

Yes, relative to CFD, and the sign is consistent:

| Case | P2 mdot kg/s | CFD mdot kg/s | Signed error |
|---|---:|---:|---:|
| Salt2 | 0.015633 | 0.013180 | +18.61% |
| Salt3 | 0.017653 | 0.014970 | +17.92% |
| Salt4 | 0.020078 | 0.016980 | +18.24% |

P2 is not uniformly high relative to the experiment:

| Case | Experimental signed error |
|---|---:|
| Salt1 | −14.71% |
| Salt2 | −6.95% |
| Salt3 | +0.87% |
| Salt4 | −0.11% |

Thus “add friction” is correct if CFD mdot is the objective, but it degrades
the experimental-mdot objective, particularly Salt1 and Salt2. Both grades
must remain visible.

If buoyancy were fixed and losses were purely quadratic,

\[
\frac{R_{\rm needed}}{R_{\rm current}}
\simeq\left(\frac{\dot m_{\rm P2}}{\dot m_{\rm CFD}}\right)^2,
\]

which gives `1.391–1.407`. The coupled model will not obey this exactly because
mass flow also changes temperature, density, viscosity, buoyancy, and heat
loss. It is a useful bracket calculation, not a fitted physical closure.

## Resistance candidates now running

Frozen P2 applies only `0.60` of the distributed F6 pressure loss; fixed minor
losses remain separate. Three predeclared branches now apply `0.80`, `1.00`,
and `1.20`. The unity branch is scientifically important because it removes
the empirical distributed-loss discount and restores the Fluid default. The
0.80 and 1.20 branches are explicitly labeled post-residual training
sensitivities.

All three ran in parallel. Final grading reports:

- TP RMSE with exact TP2;
- TW RMSE excluding TW4–TW6 and TW10;
- experimental-mdot MAPE;
- CFD-mdot MAPE;
- root and energy checks;
- the temperature cost, if any, of lowering mdot.

No scalar from this sweep should be described as the final upcomer physics.
F6 deliberately leaves the recirculating upcomer at its Shah baseline. A
throughflow-plus-recirculation state remains the defensible physical endpoint.

## Graded outcome

All 12 new roots were accepted, all energy checks passed, every TP2 projection
was finite, and all stderr logs were empty.

| Distributed-loss multiplier | TP RMSE K | TW RMSE K | Balanced K | Experimental mdot MAPE % | CFD mdot MAPE % |
|---:|---:|---:|---:|---:|---:|
| 0.60, frozen P2 | **7.971** | **10.691** | **9.430** | **5.661** | 18.259 |
| 0.80 | 8.040 | 10.944 | 9.602 | 17.141 | **3.505** |
| 1.00, Fluid default | 8.158 | 11.184 | 9.789 | 25.487 | 6.856 |
| 1.20 | 8.308 | 11.414 | 9.983 | 31.746 | 14.639 |

The 0.80 branch is the CFD-mdot result sought in this audit. Relative to
frozen P2, it:

- improves CFD-mdot MAPE by `14.754` percentage points;
- changes TP RMSE by only `+0.068 K`;
- changes TW RMSE by only `+0.253 K`;
- changes balanced temperature RMSE by only `+0.173 K`;
- worsens experimental-mdot MAPE by `11.480` points.

Its signed CFD-mdot errors remain positive and coherent:

| Case | Predicted mdot kg/s | CFD mdot kg/s | Signed CFD error |
|---|---:|---:|---:|
| Salt2 | 0.013646 | 0.013180 | +3.53% |
| Salt3 | 0.015447 | 0.014970 | +3.19% |
| Salt4 | 0.017624 | 0.016980 | +3.79% |

Unity resistance is not the best CFD match. It crosses the target and
underpredicts CFD mdot by roughly `6.4–7.2%`; 1.20 underpredicts by about
`14.1–14.9%`. The coupled solution therefore needs much less multiplier
increase than the simple fixed-buoyancy quadratic estimate suggested.

## Thesis recommendation

Carry two explicitly qualified P2 variants:

1. `P2-exp`, multiplier `0.60`: experimental-mdot-leading compensated model;
2. `P2-CFD`, multiplier `0.80`: CFD-mdot-calibrated compensated model.

`P2-CFD` has the best normalized TP/TW/CFD-mdot score in this comparison
(`0.810`, versus `1.305` for frozen P2). Frozen P2 remains best on the
experimental TP/TW/mdot composite (`0.836`, versus `1.263` at 0.80).

The 0.80 coefficient was selected after the nominal CFD residual was known, so
it is training calibration, not protected predictive validation. A later
freeze and genuinely unexposed operating point would be needed to establish
transfer. The physical successor remains a segmented
throughflow-plus-recirculation upcomer state rather than a global scalar.
