# Pressure-demand ledger V2 compact evidence

This directory is the compact, reader-auditable support package for the
pressure-accounting separation introduced across Chapters 1--6.  The
canonical upstream package is

`repo://ethan_runs/work_products/2026-08/2026-08-03/2026-08-03_pressure_demand_ledger_v2/`.

From the paper root it resolves to

`../../../ethan_runs/work_products/2026-08/2026-08-03/2026-08-03_pressure_demand_ledger_v2/`.

## Scientific role

The package distinguishes six evidence classes:

1. observed stored-pressure changes;
2. derived density-gradient and inertial terms;
3. identity-inferred mechanical demand;
4. 1D pressure-group sensitivities evaluated without CFD reference outputs as
   model inputs;
5. recovery- or component-sensitive upper bounds; and
6. unresolved signed remainders.

The controlling CFD identity is

```text
L_mech = -(Delta p_rgh + B_rho + I).
```

`L_mech` is a gross mechanical balance term.  It is not direct wall traction
and cannot uniquely partition wall shear, development, bends, junctions,
mixing, or recovery.  Candidate development and local-loss estimates are
compared with this remainder; they are not added on top and called a measured
total.  Likewise, the 1D perturbation secants re-solve mass flow and rank
measurement leverage but do not provide additive component ownership.

## Compact files

- `pressure_demand_ledger_v2.csv`: 24 Salt1--Salt4 case--span balance rows.
- `span_pressure_demand_summary.csv`: six-span mean balance and reverse-flow
  summary used by the principal CFD figure and Chapter 3 table.
- `model_pressure_sensitivity_priority.csv`: seven pressure-group circulation
  responses used by the Chapter 5 figure and table.
- `model_case_pressure_nonadditivity_audit.csv`: explicit demonstration that
  re-solved perturbation secants do not close as an additive model ledger.
- `legacy_double_count_audit.csv`: bounded semantic audit of the earlier
  additive interpretation.
- `assumption_register.csv`, `limitations_and_threats.csv`,
  `pressure_admission_matrix.csv`, and `claim_evidence_ledger.csv`: claim and
  admission boundaries.
- `summary.json`: machine-readable result summary.
- `source_manifest.csv`: SHA-256 bindings for every upstream input consumed by
  the V2 builder.
- `PORTABLE_COPY_MANIFEST.csv`: upstream and compact-copy hashes, including LF
  normalization of compact CSVs and replacement of the machine-local source
  prefix in the compact pressure ledger with `repo://ethan_runs/`.

## Headline bounds

- 24/24 balances close within `7.11e-15 Pa`.
- Identity-inferred mechanical demand spans `1.049--7.609 Pa`.
- Bulk dynamic-head materiality is at most `0.226%`.
- 12/24 rows have at least 5% reverse-flow area.
- The legacy additive diagnostic would add `0--80.4%` above the
  identity-derived term if misread as independent ownership.
- A +10% aggregate minor-loss perturbation changes mean mass flow by `-4.10%`.
- Treating the seven coupled secants as additive leaves `10.4--18.2%` of total
  model pressure demand unclosed.

## Reproduction and boundary

Regenerate upstream with

```bash
python3.11 tools/analyze/build_pressure_demand_ledger_v2.py
python3.11 tools/analyze/test_pressure_demand_ledger_v2.py
```

The paper imports compact tables and the two reviewed PDF figures.  It does
not import native CFD fields.  No component `K`, ordinary-span Darcy factor,
F6 fit, direct wall-traction measurement, experimental pressure validation, or
same-QOI mesh uncertainty is admitted by this package.
