# CSEM Manuscript Agent Instructions

This repository is the papers workspace's default target when a user says
**the paper**, **the thesis**, or **the manuscript** without another qualifier.
Do not search sibling repositories to disambiguate those terms.

## Pull-only requests

For a pull or sync request with no requested content changes:

1. Run `git status --short --branch` here.
2. If the worktree is clean, run `git pull --ff-only`.
3. Verify the final branch, commit, and worktree state.

Stop and report instead of stashing, resetting, or merging when the worktree is
dirty or the branch has diverged. Pull-only work needs no board task, journal,
or evidence scan.

## Content changes

Before editing, read `README.md` and the parent papers-workspace instructions,
then confirm a task ID, role, and exact file scope. Preserve incoming Overleaf
changes, keep manuscript edits small, build with `bash scripts/build_thesis.sh`,
and use `bash scripts/compile_and_qa.sh` for scientific-triage validation when
the change affects claims, figures, tables, citations, or structure.

Before every `git push`, commit the intended local work, confirm the worktree
state, and run `git pull --ff-only` on the same branch.  An earlier pull does
not count.  Reconcile any incoming change without rewriting history, rerun
affected validation, and repeat the pull immediately before pushing.  Never
force-push around this sequence.

Do not invent scientific results or silently strengthen claims beyond the
tracked evidence and limitations in `evidence/` and `reports/`.
