See README.md for the active five-chapter dissertation structure, build commands, retained evidence hierarchy, and final QA records.
