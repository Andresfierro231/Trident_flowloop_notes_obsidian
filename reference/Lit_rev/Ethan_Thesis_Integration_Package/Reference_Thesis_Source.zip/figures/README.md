# Active thesis figures

Figure assets are grouped by file type:

- `pdf/`: reader-facing vector figures and retained PDF references;
- `png/`: raster renderings and preview/export counterparts;
- `svg/`: editable vector sources and generated SVG counterparts;
- `tex/`: TikZ and algorithm figure sources included by LaTeX; and
- `data/`: figure manifests, validation JSON, and figure-local CSV inputs.

The active manuscript uses PDF whenever a vector rendering exists. The
reader-facing mass-flow asset uses ten-point slope fits and enlarged
Localized-CFD triangles, with CFD diamonds drawn above overlapping model
markers. The earlier unannotated one-axis layout is retained as
`pdf/csem_scientific_triage_mdot_trend_one_axis_reference.pdf`, and the
still-earlier two-panel layout remains
`pdf/csem_scientific_triage_mdot_trend_two_panel_reference.pdf`.
