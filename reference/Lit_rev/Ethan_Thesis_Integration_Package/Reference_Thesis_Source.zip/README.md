# CSEM Master's Dissertation — Six-Chapter Source

**Title:** *CFD-to-1D Model Reduction for Molten-Salt Natural-Circulation Loops: Local Closure Identification and Retrospective Model Assessment*

**Author:** Andres Nicolas Fierro Lopez  
**Degree:** Master of Science in Computational Science, Engineering, and Mathematics  
**Graduation:** August 2026  
**Supervisor / co-supervisor:** Dr. Kevin T. Clarno / Dr. Robert D. Moser
**Mentor:** Dr. Cole Gentry

## Active structure

1. Introduction and Research Objectives
2. Thermal-Fluids Formulation and CFD-to-1D Reduction
3. TAMU Loop, CFD Reference, and Modeling Targets
4. Complete One-Dimensional Model Definition
5. Model Assessment, Mechanism Analysis, and Limitations
6. Conclusions, Limitations, and Future Work

Appendices provide the surviving nomenclature and loop-segment definitions. Historical review and evidence records remain repository context unless a dated report explicitly supersedes them.

## Build

From the repository root:

```bash
bash scripts/build_thesis.sh
```

To rebuild and run the focused six-chapter scientific-triage checks:

```bash
bash scripts/compile_and_qa.sh
```

This gate checks the manuscript structure, claim boundaries, exact scored
populations and values, restored-TW4--TW6 sensitivity, required figures,
bibliography, clean build log, compiled PDF, curated evidence digests, and
active review-resolution paths.  It records repository size and unmanifested
historical/support evidence without treating deletion as a scientific-pass
criterion.

The bibliography workflow is Natbib + BibTeX using `unsrtnat`. `bibliography/litrev_references.bib` is the read-only imported theory/citation snapshot; `prepare_bibtex_litrev.py` regenerates its BibTeX-compatible derivative without modifying the source snapshot.

## Evidence

`evidence/README.md` defines the compact in-repository evidence contract.
`evidence/CLAIM_SOURCE_MANIFEST.csv` routes principal claims to controlling
manuscript/report sources, compact local inputs, and the complete sibling
archive. `evidence/FIGURE_SOURCE_MANIFEST.csv` retains the exact source data and
hashes needed by the active manuscript figures. The full 699-file evidence tree
from commit `0423ca4` is preserved outside this Git checkout at
`../csem-Masters-dissertation-evidence-archive-2026-07-31-0423ca4/`.

The paper repository intentionally keeps only compact score, setup, and figure
inputs. Historical evidence packages remain provenance support in the sibling
archive; the thesis is the reader-facing scientific argument.

Figure assets are organized by extension under `figures/pdf/`, `figures/png/`,
`figures/svg/`, `figures/tex/`, and `figures/data/`. Regeneration scripts write
directly to these type folders; active LaTeX figures use the PDF or PNG path.

## Final records

- `reports/FINAL_FIXME_CLOSURE_REGISTER.csv`: all 73 original review comments and their final resolution routes.
- `reports/FINAL_REVISION_SUMMARY.md`: current scientific reconciliation and QA results.
- `reports/SCIENTIFIC_CLAIM_PROVENANCE.md`: decision-level claim, evidence, and limitation routes.
- `reports/SCIENTIFIC_TRIAGE_2026-07-29.md`: current reconciliation record, controlling evidence, edits, and deferred repository-hygiene warnings.
- `reports/scientific_triage_qa.md` and `reports/scientific_triage_qa.json`: current focused source/PDF/scientific checks.
- `reports/build_qa_latest.md` and `.json`: current active-source/build checks.
- `reports/final_qa.md` and `.json`: current 28-check scientific-readiness gate.
