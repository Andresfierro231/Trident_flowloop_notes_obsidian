# Active manuscript files

The reader-facing thesis consists of six chapters:

- `01_introduction.tex`
- `02_thermal_fluids_and_reduction.tex`
- `03_cfd_reference_and_model_targets.tex`
- `04_reduced_model_methodology.tex`
- `05_model_assessment_and_interpretation.tex`
- `06_conclusions.tex`

`abstract.tex`, `appendix_nomenclature.tex`, `appendix_air_properties.tex`, and
`appendix_segment_atlas.tex` complete the active manuscript. Files from the
former nine-chapter organization were deleted after their supported content
was integrated and the complete thesis compiled without unresolved references.
