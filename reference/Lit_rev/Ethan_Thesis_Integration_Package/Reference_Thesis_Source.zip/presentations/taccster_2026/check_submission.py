#!/usr/bin/env python3.11
"""Validate the TACCSTER abstract source and compiled single-page PDF."""

from __future__ import annotations

import re
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "abstract.md"
PDF = ROOT / "taccster_abstract.pdf"
REQUIRED_TEXT = (
    "From 2.17 Million Cells to a Reproducible Loop Model",
    "Andres Nicolas Fierro Lopez",
    "Oden Institute for Computational Engineering and Sciences",
)


def abstract_body(source: str) -> str:
    """Return only the abstract prose, excluding title and affiliation."""
    try:
        return source.split("## Abstract", 1)[1].strip()
    except IndexError as exc:
        raise SystemExit("abstract.md is missing the '## Abstract' heading") from exc


def word_count(text: str) -> int:
    """Count hyphenated compounds as one word, matching common form counters."""
    return len(re.findall(r"\b[\w]+(?:[-'’][\w]+)*\b", text, flags=re.UNICODE))


def command_output(*args: str) -> str:
    """Run one read-only PDF inspection command and return its text."""
    return subprocess.run(args, check=True, capture_output=True, text=True).stdout


def main() -> int:
    source = SOURCE.read_text(encoding="utf-8")
    count = word_count(abstract_body(source))
    if count > 300:
        raise SystemExit(f"abstract is {count} words; TACCSTER maximum is 300")
    if not PDF.is_file():
        raise SystemExit("taccster_abstract.pdf is missing; run build.sh")

    pdf_info = command_output("pdfinfo", str(PDF))
    pages = re.search(r"^Pages:\s+(\d+)$", pdf_info, flags=re.MULTILINE)
    if not pages or pages.group(1) != "1":
        raise SystemExit("submission PDF must contain exactly one page")

    pdf_text = command_output("pdftotext", str(PDF), "-")
    for expected in REQUIRED_TEXT:
        if expected not in pdf_text:
            raise SystemExit(f"required PDF text is missing: {expected}")
    forbidden = ("FIXME", "TODO", "/scratch/", "prospective validation achieved")
    for token in forbidden:
        if token in source or token in pdf_text:
            raise SystemExit(f"forbidden draft or claim token found: {token}")

    print(f"submission check passed: {count} abstract words, 1 PDF page")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
