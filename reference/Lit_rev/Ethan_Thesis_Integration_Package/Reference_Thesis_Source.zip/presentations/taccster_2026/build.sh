#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$script_dir"

if command -v module >/dev/null 2>&1; then
  module load texlive/2023 >/dev/null 2>&1 || true
fi

for command_name in pdflatex pdfinfo pdftotext python3.11; do
  if ! command -v "$command_name" >/dev/null 2>&1; then
    echo "ERROR: required command not found: $command_name" >&2
    exit 127
  fi
done

pdflatex -interaction=nonstopmode -halt-on-error taccster_abstract.tex
python3.11 check_submission.py

rm -f taccster_abstract.aux \
  taccster_abstract.log \
  taccster_abstract.out
