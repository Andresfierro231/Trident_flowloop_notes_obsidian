# TACCSTER 2026 abstract package

This directory contains the submission-ready, single-page abstract PDF and its
reproducible source.

## Submission file

Upload only `taccster_abstract.pdf` to the application form.

- Author: Andres Nicolas Fierro Lopez
- Level: Master's student
- Affiliation: Computational Science, Engineering, and Mathematics Program,
  Oden Institute for Computational Engineering and Sciences, The University of
  Texas at Austin
- Field: Computational thermal-fluid dynamics and reduced-order modeling
- Abstract body: 282 words under the package's conservative checker
- Coauthors: none assumed; confirm this before submission

## Build and check

```bash
bash build.sh
```

The script compiles the PDF, verifies that it is one page, checks that the title,
author, and affiliation survived PDF extraction, enforces the 300-word limit,
and rejects draft markers or machine-local paths. It leaves only the source and
final PDF; intermediate LaTeX files are removed.

## Claim sources

- Approximately 2.17 million finite volumes and 64 MPI ranks:
  `chapters/03_cfd_reference_and_model_targets.tex`, spatial and temporal
  discretization subsection.
- Four development cases and six no-refit test-data cases:
  Chapter 3 and `evidence/salt24_test_grading_2026_08_04/`.
- P1 and P2-CFD six-case grades:
  `evidence/salt24_test_grading_2026_08_04/combined_six_case_scorecard.csv`.
- Accepted 256-run heat-path counterfactual and practical identifiability:
  `chapters/05_model_assessment_and_interpretation.tex`.
- Localized conjugate candidate and its empirical/prospective-validation
  limits: Chapters 4--6 and `evidence/localized_conjugate_model_2026_08_03/`.
- Reader-runnable reduced model:
  the standalone `csem-loop-model` repository and its solver appendix.

The 2026 symposium is scheduled for September 21--22 at TACC's Pickle Research
Campus. The application details supplied for this task specify an August 7
deadline and August 26 notifications. Confirm the live form immediately before
submission.
