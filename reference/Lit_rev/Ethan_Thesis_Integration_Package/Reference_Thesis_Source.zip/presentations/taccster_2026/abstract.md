# From 2.17 Million Cells to a Reproducible Loop Model: TACC-Enabled CFD-to-1D Reduction for Molten-Salt Natural Circulation

**Andres Nicolas Fierro Lopez**<br>
Computational Science, Engineering, and Mathematics Program<br>
Oden Institute for Computational Engineering and Sciences<br>
The University of Texas at Austin

## Abstract

Passive molten-salt systems couple heat transfer, density, buoyancy, and
hydraulic resistance, making high-fidelity simulation valuable but too
expensive for repeated systems studies. Using TACC's Lonestar6, we ran transient
OpenFOAM 13 simulations of the Texas A&M University HITEC natural-circulation
loop. Each production case resolves approximately 2.17 million finite volumes
across 64 MPI ranks. The challenge was converting long field histories into an
auditable reduced model without leaking reference outputs into runtime.

We developed an end-to-end HPC-to-reduced-order-model workflow: Slurm-managed
continuation runs; terminal-window stationarity checks; conservative reduction
of signed mass flow, sensor-equivalent temperatures, wall heat, pressure, and
recirculation; and a modular one-dimensional finite-volume solver with nested
temperature-periodicity and buoyancy-loss root solves. Runtime inputs and CFD
scoring targets remain separated by construction. Three interchangeable model
forms were frozen on four development cases and graded without refitting on six
heater-power perturbations.

Accuracy is objective dependent. The temperature-oriented P1 model achieves
12.853 K balanced fluid/wall-temperature
RMSE on the test data but 42.003% CFD mass-flow MAPE. P2-CFD reduces mass-flow
MAPE to 2.835% with 13.019 K temperature error, although its hydraulic scale is
target-informed. A 256-run heat-path counterfactual reveals nonlinear error
compensation and practical non-identifiability hidden by aggregate temperature
agreement. Those diagnostics motivated a localized conjugate model that
restores the physical insulation description and lowers development
temperature RMSE from 9.280 K to 4.957 K, while remaining explicitly labeled
empirical and not prospectively validated.

The resulting reproducible, reader-runnable package turns TACC-scale CFD
evidence into a lower-cost systems model while preserving provenance and
scientific limitations. More broadly, the workflow demonstrates how HPC can be
used not only to simulate a complex system, but to determine what a reduced
model can---and cannot---claim.
