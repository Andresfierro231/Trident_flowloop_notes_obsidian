#!/usr/bin/env python3
"""Check the current introduction, results, assessment, conclusions, and abstract for alignment."""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

COMMENT_RE = re.compile(r"(?m)(?<!\\)%.*$")


def clean(text: str) -> str:
    return COMMENT_RE.sub("", text)


def block(text: str, start: str, end: str | None = None) -> str:
    i = text.find(start)
    if i < 0:
        return ""
    j = text.find(end, i + len(start)) if end else len(text)
    return text[i:j if j >= 0 else len(text)]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo-root", type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument("--write-report", action="store_true")
    args = ap.parse_args()
    root = args.repo_root.resolve()

    paths = {
        "intro": root / "chapters/01_introduction.tex",
        "ch7": root / "chapters/07_reduced_cfd_evidence.tex",
        "ch8": root / "chapters/08_predictive_model_assessment.tex",
        "ch9": root / "chapters/09_implications_conclusions_future_work.tex",
        "abstract": root / "chapters/abstract.tex",
        "nomenclature": root / "chapters/appendix_nomenclature.tex",
    }
    texts = {key: clean(path.read_text(encoding="utf-8")) for key, path in paths.items()}
    checks: list[dict[str, str]] = []
    issues: list[str] = []

    def check(name: str, condition: bool, detail: str) -> None:
        checks.append({"check": name, "status": "pass" if condition else "fail", "detail": detail})
        if not condition:
            issues.append(f"{name}: {detail}")

    questions = block(texts["intro"], r"The thesis addresses three questions:", r"The corresponding objectives")
    objectives = block(texts["intro"], r"The corresponding objectives are to:", r"\section{Thesis contributions}")
    intro_contrib = block(texts["intro"], r"\section{Thesis contributions}", r"\section{Scope")
    final_contrib = block(texts["ch9"], r"\section{Scientific and methodological contributions}", r"\section{CSEM relevance}")

    check("three research questions", questions.count(r"\item") == 3, f"found {questions.count(r'\item')}")
    check("four research objectives", objectives.count(r"\item") == 4, f"found {objectives.count(r'\item')}")
    check("five introductory contributions", intro_contrib.count(r"\item") == 5, f"found {intro_contrib.count(r'\item')}")
    check("five concluding contributions", final_contrib.count(r"\item") == 5, f"found {final_contrib.count(r'\item')}")

    for prefix in ["1. How should", "2. Where is", "3. How well"]:
        check(f"Chapter 9 answer heading: {prefix}", prefix in texts["ch9"], "one answer subsection per research question")

    for heading in ["Hydraulic findings", "Thermal findings", "Recirculation findings", "Quantity-specific numerical findings", "Physical synthesis"]:
        check(f"Chapter 7 section: {heading}", rf"\section{{{heading}}}" in texts["ch7"], "required results section")
    for heading in ["Evaluation quantities", "Operational physics-based path", "Accuracy-oriented affine temperature path", "Side-by-side assessment", "What the negative results establish"]:
        check(f"Chapter 8 section: {heading}", rf"\section{{{heading}}}" in texts["ch8"], "required assessment section")
    for heading in ["Supported scientific conclusions", "Scientific and methodological contributions", "CSEM relevance", "Relevance to SAM", "Current limitations", "Specific future studies"]:
        check(f"Chapter 9 section: {heading}", rf"\section{{{heading}}}" in texts["ch9"], "required conclusion section")

    combined = "\n".join(texts.values()).lower()
    check("P1 nominal score consistent", "9.280" in texts["ch8"] and "9.280" in texts["ch9"], "balanced TP/TW RMSE")
    check("P2-CFD mass-flow score consistent", "3.505" in texts["ch8"] and "3.505" in texts["ch9"], "nominal CFD mass-flow MAPE")
    check("affine holdout score consistent", "7.04" in texts["ch8"] and "7.04" in texts["ch9"], "Salt2 perturbation MAE")
    check("two prediction paths retained", "physics-based" in combined and "affine" in combined, "physical and affine paths")
    check("fixed properties and insulation", "properties and insulation" in combined and "fixed" in combined, "fixed to CFD basis")
    check("no positive SAM validation claim", "sam model is validated" not in combined and "constitutes sam validation" not in combined, "no direct SAM validation evidence")
    check("abstract has no citation command", r"\cite" not in texts["abstract"], "self-contained abstract")
    for concept in ["natural-circulation", "computational fluid dynamics", "one-dimensional", "physics-based", "affine", "recirculation", "predictive"]:
        check(f"abstract concept: {concept}", concept in texts["abstract"].lower(), "required abstract content")
    check("nomenclature contains mass flow", r"$\dot m$" in texts["nomenclature"], "surviving global symbol")
    check("nomenclature contains Darcy factor", r"$f_D$" in texts["nomenclature"], "surviving global symbol")

    status = "pass" if not issues else "fail"
    payload = {"status": status, "checks": checks, "issues": issues}
    if args.write_report:
        reports = root / "reports"
        reports.mkdir(exist_ok=True)
        (reports / "2026-07-29_cross_chapter_consistency.json").write_text(json.dumps(payload, indent=2) + "\n")
        lines = ["# Cross-Chapter Consistency Check", "", f"Status: **{status}**", "", "| Check | Status | Detail |", "|---|---|---|"]
        for row in checks:
            lines.append(f"| {row['check']} | {row['status']} | {row['detail'].replace('|', '/')} |")
        lines += ["", "## Issues"] + ([f"- {item}" for item in issues] or ["- None."])
        (reports / "2026-07-29_cross_chapter_consistency.md").write_text("\n".join(lines) + "\n")
    print(json.dumps(payload, indent=2))
    return 0 if status == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
