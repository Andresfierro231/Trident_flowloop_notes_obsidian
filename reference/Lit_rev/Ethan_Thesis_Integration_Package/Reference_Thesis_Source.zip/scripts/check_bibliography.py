#!/usr/bin/env python3
"""Check active BibTeX resources, duplicate works, and cited keys."""
from __future__ import annotations

import argparse
import json
import re
from collections import defaultdict
from pathlib import Path

from prepare_bibtex_litrev import find_entries, parse_fields, unwrap

CITE_RE = re.compile(r"\\cite\w*\s*(?:\[[^]]*\]\s*){0,2}\{([^}]*)\}")
ALLOWED_TYPES = {"article", "book", "booklet", "conference", "inbook", "incollection", "inproceedings", "manual", "mastersthesis", "misc", "phdthesis", "proceedings", "techreport", "unpublished"}
BIBLATEX_ONLY_FIELDS = {"journaltitle", "date", "ids", "location", "eid", "eventdate", "eventtitle", "urldate"}


def normalize(value: str) -> str:
    value = unwrap(value)
    return re.sub(r"[^a-z0-9]+", "", value.lower().replace("{", "").replace("}", ""))


def parse_bib(path: Path):
    text = path.read_text(encoding="utf-8", errors="replace")
    entries = []
    for entry_type, key, content in find_entries(text):
        fields = parse_fields(content)
        entries.append({
            "key": key,
            "type": entry_type.lower(),
            "fields": fields,
            "file": str(path),
        })
    return entries


def active_tex_files(repo: Path):
    include_re = re.compile(r"\\(?:input|include)\{([^}]+)\}")
    comment_re = re.compile(r"(?m)(?<!\\)%.*$")
    seen = set()
    ordered = []

    def walk(path: Path):
        path = path.resolve()
        if path in seen or not path.is_file():
            return
        seen.add(path)
        ordered.append(path)
        text = comment_re.sub("", path.read_text(encoding="utf-8", errors="replace"))
        for token in include_re.findall(text):
            child = repo / token
            if not child.suffix:
                child = child.with_suffix(".tex")
            walk(child)

    walk(repo / "masterthesis.tex")
    return [p for p in ordered if p.suffix == ".tex"]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    repo = args.repo_root.resolve()

    active_bibs = [repo / "references.bib", repo / "bibliography" / "litrev_references_bibtex.bib"]
    missing_resources = [str(p.relative_to(repo)) for p in active_bibs if not p.is_file()]
    entries = [entry for bib in active_bibs if bib.exists() for entry in parse_bib(bib)]

    by_key = defaultdict(list)
    by_doi = defaultdict(list)
    by_title = defaultdict(list)
    unsupported_types = []
    biblatex_only_fields = []
    for entry in entries:
        by_key[entry["key"]].append(entry)
        doi = normalize(entry["fields"].get("doi", ""))
        title = normalize(entry["fields"].get("title", ""))
        if doi:
            by_doi[doi].append(entry)
        if title:
            by_title[title].append(entry)
        if entry["type"] not in ALLOWED_TYPES:
            unsupported_types.append({"key": entry["key"], "type": entry["type"], "file": entry["file"]})
        for field in sorted(set(entry["fields"]) & BIBLATEX_ONLY_FIELDS):
            biblatex_only_fields.append({"key": entry["key"], "field": field, "file": entry["file"]})

    duplicate_keys = {key: rows for key, rows in by_key.items() if len(rows) > 1}
    duplicate_dois = {key: rows for key, rows in by_doi.items() if len(rows) > 1}
    duplicate_titles = {key: rows for key, rows in by_title.items() if len(rows) > 1}

    cited = set()
    for path in active_tex_files(repo):
        text = re.sub(r"(?m)(?<!\\)%.*$", "", path.read_text(encoding="utf-8", errors="replace"))
        for group in CITE_RE.findall(text):
            cited.update(key.strip() for key in group.split(",") if key.strip())
    missing = sorted(cited - set(by_key))

    raw_snapshot = repo / "bibliography" / "litrev_references.bib"
    raw_count = len(parse_bib(raw_snapshot)) if raw_snapshot.is_file() else 0

    result = {
        "active_resources": [str(p.relative_to(repo)) for p in active_bibs],
        "missing_resources": missing_resources,
        "entry_count": len(entries),
        "raw_litrev_snapshot_entry_count": raw_count,
        "cited_key_count": len(cited),
        "duplicate_keys": {k: [r["file"] for r in v] for k, v in duplicate_keys.items()},
        "duplicate_dois": {k: [r["key"] for r in v] for k, v in duplicate_dois.items()},
        "duplicate_titles": {k: [r["key"] for r in v] for k, v in duplicate_titles.items()},
        "missing_cited_keys": missing,
        "unsupported_entry_types": unsupported_types,
        "biblatex_only_fields_in_active_resources": biblatex_only_fields,
    }

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(f"Active bibliography entries: {len(entries)}")
        print(f"Raw LitRev snapshot entries: {raw_count}")
        print(f"Cited keys scanned: {len(cited)}")
        print(f"Duplicate keys/DOIs/titles: {len(duplicate_keys)}/{len(duplicate_dois)}/{len(duplicate_titles)}")
        print(f"Missing cited keys: {len(missing)}")
        print(f"Unsupported types: {len(unsupported_types)}")
        print(f"BibLaTeX-only fields in active resources: {len(biblatex_only_fields)}")

    fail = any([
        missing_resources,
        duplicate_keys,
        duplicate_dois,
        duplicate_titles,
        missing,
        unsupported_types,
        biblatex_only_fields,
    ])
    return 1 if fail else 0


if __name__ == "__main__":
    raise SystemExit(main())
