#!/usr/bin/env python3
"""Validate current author-controlled title, framing, and unresolved metadata comments."""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

TITLE = "CFD-to-1D Model Reduction for Molten-Salt Natural-Circulation Loops: Local Closure Identification and Predictive Model Assessment"
COMMENT_RE = re.compile(r"(?m)(?<!\\)%.*$")


def strip_comments(text: str) -> str:
    return COMMENT_RE.sub("", text)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo-root", type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument("--write-report", action="store_true")
    args = ap.parse_args()
    root = args.repo_root.resolve()

    paths = {
        "metadata": root / "structural/metadata.tex",
        "preamble": root / "structural/preamble.tex",
        "abstract": root / "chapters/abstract.tex",
        "intro": root / "chapters/01_introduction.tex",
        "ch5": root / "chapters/05_coupled_fluid_walls_model.tex",
        "ch6": root / "chapters/06_closure_admission_uncertainty.tex",
        "ch8": root / "chapters/08_predictive_model_assessment.tex",
        "ch9": root / "chapters/09_implications_conclusions_future_work.tex",
    }
    raw = {key: path.read_text(encoding="utf-8") for key, path in paths.items()}
    active = {key: strip_comments(text) for key, text in raw.items()}
    checks: list[dict[str, str]] = []
    issues: list[str] = []

    def check(name: str, condition: bool, detail: str) -> None:
        checks.append({"check": name, "status": "pass" if condition else "fail", "detail": detail})
        if not condition:
            issues.append(f"{name}: {detail}")

    check("exact LaTeX title", rf"\title{{{TITLE}}}" in active["metadata"], TITLE)
    check("exact PDF metadata title", f"pdftitle={{{TITLE}}}" in active["preamble"], TITLE)
    check(
        "numeric hyperlinked citation mode",
        bool(re.search(r"\\usepackage\[(?=[^]]*numbers)(?=[^]]*sort&compress)(?=[^]]*square)[^]]*\]\{natbib\}", active["preamble"]))
        and r"\usepackage{hyperref}" in active["preamble"],
        "Natbib numbers/sort&compress/square plus hyperref",
    )

    active_all = "\n".join(active.values())
    check("no visible FIXME", "FIXME" not in active_all, "FIXME may occur only in comments")
    fixmes: list[str] = []
    for path in [root / "structural/metadata.tex", *sorted((root / "chapters").glob("*.tex"))]:
        for line_no, line in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            if re.search(r"(?<!\\)%.*\bFIXME\b", line, flags=re.I):
                fixmes.append(f"{path.relative_to(root)}:{line_no}")
    check(
        "source FIXME inventory",
        fixmes == ["structural/metadata.tex:9", "structural/metadata.tex:13"],
        f"found {len(fixmes)}: {', '.join(fixmes)}",
    )

    for key in ["abstract", "intro", "ch8", "ch9"]:
        text = active[key].lower()
        check(
            f"two prediction paths in {key}",
            "physics-based" in text and ("affine" in text or "accuracy-oriented" in text),
            "physics-based and affine/accuracy-oriented paths",
        )

    scope = "\n".join(active[key].lower() for key in ["intro", "ch5", "ch6", "ch8", "ch9"])
    check("fixed CFD property basis", "properties" in scope and "fixed" in scope and "cfd" in scope, "properties are not uncertainty variables")
    check("fixed CFD insulation basis", "insulation" in scope and "fixed" in scope and "cfd" in scope, "insulation is not an uncertainty variable")
    check("Chapter 8 title", r"\chapter{Predictive Model Assessment}" in active["ch8"], "current Chapter 8 framing")
    check("no positive SAM validation claim", "sam model is validated" not in active_all.lower(), "no direct SAM validation evidence")

    status = "pass" if not issues else "fail"
    payload = {"status": status, "title": TITLE, "fixme_comments": fixmes, "checks": checks, "issues": issues}
    if args.write_report:
        reports = root / "reports"
        reports.mkdir(exist_ok=True)
        (reports / "2026-07-29_author_corrections_audit.json").write_text(json.dumps(payload, indent=2) + "\n")
        lines = [
            "# Author-Controlled Corrections Audit",
            "",
            f"Status: **{status}**",
            "",
            "| Check | Status | Detail |",
            "|---|---|---|",
        ]
        for row in checks:
            lines.append(f"| {row['check']} | {row['status']} | {row['detail'].replace('|', '/')} |")
        lines += ["", "## Source-only comments awaiting author confirmation"]
        lines += [f"- `{item}`" for item in fixmes] or ["- None."]
        lines += ["", "## Issues"] + ([f"- {item}" for item in issues] or ["- None."])
        (reports / "2026-07-29_author_corrections_audit.md").write_text("\n".join(lines) + "\n")
    print(json.dumps(payload, indent=2))
    return 0 if status == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
