#!/usr/bin/env python3
"""Render draft_coordination/active_file_manifest.csv as concise Markdown."""
from pathlib import Path
import csv
ROOT=Path(__file__).resolve().parents[1]
cp=ROOT/"draft_coordination/active_file_manifest.csv"
mp=ROOT/"draft_coordination/active_file_manifest.md"
with cp.open(newline="",encoding="utf-8-sig") as h: rows=list(csv.DictReader(h))
lines=["# Active File Manifest","","Generated from `active_file_manifest.csv`. Edit the CSV, then rerun","`python3 scripts/update_active_manifest.py`.","","Allowed status values: `controlling`, `active-support`, `unresolved`,","`historical`, `superseded`, and `generated`.",""]
for priority in sorted({r["read_priority"] for r in rows},key=int):
    lines += [f"## Read priority {priority}","","| Path | Status | Controls / supports | Chapter |","|---|---|---|---|"]
    for r in [x for x in rows if x["read_priority"]==priority]: lines.append(f'| `{r["relative_path"]}` | {r["status"]} | {r["controlling_for"]} | {r["chapter_use"] or "-"} |')
    lines.append("")
mp.write_text("\n".join(lines),encoding="utf-8")
print(f"Wrote {mp.relative_to(ROOT)} with {len(rows)} rows.")
