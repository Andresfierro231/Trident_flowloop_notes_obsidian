#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
repo_root="$(cd "${script_dir}/.." && pwd)"
cd "${repo_root}"

if command -v module >/dev/null 2>&1; then
  module load texlive/2023 >/dev/null 2>&1 || true
fi

for command_name in python3 latexmk pdflatex; do
  if ! command -v "${command_name}" >/dev/null 2>&1; then
    echo "ERROR: required command not found: ${command_name}" >&2
    exit 127
  fi
done

# Some container images expose a broken /usr/bin/bibtex alternative while
# retaining the working executable as bibtex.original. Supply a temporary
# wrapper for latexmk in that environment; ordinary TeX installations use the
# standard bibtex command directly.
if ! command -v bibtex >/dev/null 2>&1; then
  if command -v bibtex.original >/dev/null 2>&1; then
    bibtex_wrapper_dir="$(mktemp -d)"
    trap 'rm -rf "${bibtex_wrapper_dir}"' EXIT
    ln -s "$(command -v bibtex.original)" "${bibtex_wrapper_dir}/bibtex"
    export PATH="${bibtex_wrapper_dir}:${PATH}"
  else
    echo "ERROR: required command not found: bibtex" >&2
    exit 127
  fi
fi

# Rebuild the local BibTeX-compatible LitRev resource from the read-only
# snapshot. This conversion does not modify the LitRev project or its snapshot.
python3 "${script_dir}/prepare_bibtex_litrev.py" \
  --source "${repo_root}/bibliography/litrev_references.bib" \
  --output "${repo_root}/bibliography/litrev_references_bibtex.bib" \
  --exclude-bib "${repo_root}/references.bib"
python3 "${script_dir}/update_bibliography_register.py"

if [[ "${CLEAN_FIRST:-0}" == "1" ]]; then
  latexmk -C masterthesis.tex
fi

# Remove stale files specific to a previous biblatex/Biber build so latexmk
# cannot infer the wrong backend.
rm -f masterthesis.bbl masterthesis.blg masterthesis.bcf masterthesis.run.xml

latexmk -pdf -bibtex -interaction=nonstopmode -halt-on-error \
  -file-line-error masterthesis.tex
