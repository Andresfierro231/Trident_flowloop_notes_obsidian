#!/usr/bin/env python3
"""Blocking scientific/build gate for the active six-chapter dissertation.

This audit is intentionally narrow.  It verifies the July 29 scientific
triage and reports the known repository-evidence and FIXME-ledger cleanup as
DEFERRED warnings; it must never convert those deferred defects into passes.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


EXPECTED_CHAPTER_TOKENS = [
    "chapters/01_introduction",
    "chapters/02_thermal_fluids_and_reduction",
    "chapters/03_cfd_reference_and_model_targets",
    "chapters/04_reduced_model_methodology",
    "chapters/05_model_assessment_and_interpretation",
    "chapters/06_conclusions",
]
EXPECTED_SCORE_POLICY = "TP includes TP2; TW excludes TW4-TW6 and TW10"
FIGURE_VALIDATION = Path(
    "figures/data/csem_scientific_triage_validation.json"
)

TRAINING_EXPECTED = {
    "P1": {
        "tp_rows": 24,
        "tw_rows": 28,
        "tp_rmse_K": 7.9865374726582905,
        "tw_rmse_K": 10.41421778575935,
        "balanced_tp_tw_rmse_K": 9.2801054113464,
        "cfd_mdot_mape_pct_salt1_4": 43.26556092677868,
    },
    "P2-CFD": {
        "tp_rows": 24,
        "tw_rows": 28,
        "tp_rmse_K": 8.039669101535711,
        "tw_rmse_K": 10.943910994743508,
        "balanced_tp_tw_rmse_K": 9.602225448380596,
        "cfd_mdot_mape_pct_salt1_4": 3.53792904811022,
    },
}
HOLDOUT_EXPECTED = {
    "P1": {
        "tp_rows": 12,
        "tw_rows": 14,
        "tp_rmse_K": 7.702119129850825,
        "tw_rmse_K": 10.754488275884896,
        "balanced_tp_tw_rmse_K": 9.353653221243551,
        "cfd_mdot_mape_pct": 43.84573308487966,
    },
    "P2-CFD": {
        "tp_rows": 12,
        "tw_rows": 14,
        "tp_rmse_K": 7.7652176030166835,
        "tw_rmse_K": 11.32511478742005,
        "balanced_tp_tw_rmse_K": 9.709707239933666,
        "cfd_mdot_mape_pct": 3.408711783146743,
    },
}
LOCALIZED_EXPECTED = {
    "RW_outer_bridge2p500_r0p600__rad__coupled": {
        "tp_rmse_K": 4.627642711145392,
        "policy_tw_rmse_K": 5.265832126787544,
        "balanced_tp_tw_rmse_K": 4.957018511642099,
        "cfd_mdot_mape_pct_salt1_4": 30.238954815024975,
    },
    "RW_outer_bridge2p500_r1p100__rad__coupled": {
        "tp_rmse_K": 6.793081336892322,
        "policy_tw_rmse_K": 7.3746900097852,
        "balanced_tp_tw_rmse_K": 7.08985214197237,
        "cfd_mdot_mape_pct_salt1_4": 0.9674170291548436,
    },
}

INCLUDE_RE = re.compile(r"\\(?:input|include)\{([^}]+)\}")
GRAPHICS_RE = re.compile(r"\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}")
COMMENT_RE = re.compile(r"(?m)(?<!\\)%.*$")


def strip_comments(text: str) -> str:
    return COMMENT_RE.sub("", text)


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace")


def add_check(
    checks: list[dict[str, Any]], name: str, passed: bool, detail: str
) -> None:
    checks.append(
        {
            "name": name,
            "status": "PASS" if passed else "FAIL",
            "blocking": True,
            "detail": detail,
        }
    )


def resolve_tex(repo: Path, token: str) -> Path:
    path = repo / token
    return path if path.suffix else path.with_suffix(".tex")


def collect_active_tex(repo: Path) -> tuple[list[Path], list[str]]:
    seen: set[Path] = set()
    ordered: list[Path] = []
    missing: list[str] = []

    def visit(path: Path) -> None:
        path = path.resolve()
        if path in seen:
            return
        seen.add(path)
        if not path.is_file():
            try:
                missing.append(path.relative_to(repo).as_posix())
            except ValueError:
                missing.append(str(path))
            return
        ordered.append(path)
        for token in INCLUDE_RE.findall(strip_comments(read_text(path))):
            visit(resolve_tex(repo, token))

    visit(repo / "masterthesis.tex")
    return ordered, missing


def graphics_status(repo: Path, tex_files: Iterable[Path]) -> tuple[list[str], list[str]]:
    referenced: list[str] = []
    missing: list[str] = []
    extensions = ("", ".pdf", ".png", ".jpg", ".jpeg", ".eps", ".svg")
    for tex_path in tex_files:
        for token in GRAPHICS_RE.findall(strip_comments(read_text(tex_path))):
            referenced.append(token)
            base = repo / token
            candidates = [base] if base.suffix else [
                Path(f"{base}{extension}") for extension in extensions
            ]
            if not any(path.is_file() for path in candidates):
                missing.append(f"{tex_path.relative_to(repo)} -> {token}")
    return sorted(set(referenced)), sorted(set(missing))


def read_csv_index(path: Path, key: str) -> dict[str, dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return {row[key]: row for row in csv.DictReader(handle)}


def nearly_equal(observed: str, expected: float, tolerance: float = 1e-12) -> bool:
    try:
        return abs(float(observed) - expected) <= tolerance
    except (TypeError, ValueError):
        return False


def validate_score_row(
    row: dict[str, str] | None, expected: dict[str, float | int]
) -> tuple[bool, list[str]]:
    problems: list[str] = []
    if row is None:
        return False, ["row missing"]
    for field, value in expected.items():
        if isinstance(value, int):
            try:
                observed = int(row[field])
            except (KeyError, TypeError, ValueError):
                observed = None
            if observed != value:
                problems.append(f"{field}: expected {value}, observed {observed!r}")
        elif not nearly_equal(row.get(field, ""), value):
            problems.append(
                f"{field}: expected {value:.15g}, observed {row.get(field)!r}"
            )
    if row.get("score_policy") != EXPECTED_SCORE_POLICY:
        problems.append(
            f"score_policy: expected {EXPECTED_SCORE_POLICY!r}, "
            f"observed {row.get('score_policy')!r}"
        )
    if row.get("root_acceptance_fraction") != "1.0":
        problems.append(
            "root_acceptance_fraction: expected '1.0', "
            f"observed {row.get('root_acceptance_fraction')!r}"
        )
    return not problems, problems


def nested_values(payload: Any, key: str) -> list[Any]:
    values: list[Any] = []
    if isinstance(payload, dict):
        for current_key, value in payload.items():
            if current_key == key:
                values.append(value)
            values.extend(nested_values(value, key))
    elif isinstance(payload, list):
        for value in payload:
            values.extend(nested_values(value, key))
    return values


def validate_figure_payload(repo: Path) -> tuple[bool, str]:
    path = repo / FIGURE_VALIDATION
    if not path.is_file():
        return False, f"missing required validation artifact: {FIGURE_VALIDATION}"
    try:
        payload = json.loads(read_text(path))
    except json.JSONDecodeError as exc:
        return False, f"invalid JSON in {FIGURE_VALIDATION}: {exc}"

    problems: list[str] = []
    if payload.get("all_checks_pass") is not True:
        problems.append("all_checks_pass is not true")
    checks = payload.get("checks")
    if not isinstance(checks, list) or not checks:
        problems.append("validation check list missing")
    elif any(check.get("pass") is not True for check in checks):
        problems.append("one or more figure checks failed")

    serialized = json.dumps(payload, sort_keys=True)
    for required in ("P1", "P2-CFD", EXPECTED_SCORE_POLICY):
        if required not in serialized:
            problems.append(f"missing contract token {required!r}")
    displayed_models = payload.get("displayed_models", {})
    if displayed_models.get("temperature_parity") != [
        "P1",
        "P2-CFD",
        "Localized-CFD",
    ]:
        problems.append(
            "temperature parity must display P1, P2-CFD, and Localized-CFD"
        )
    if displayed_models.get("mass_flow_trend") != [
        "P1",
        "P2-exp",
        "P2-CFD",
        "Localized-0.60",
        "Localized-CFD",
    ]:
        problems.append(
            "mass-flow trend must display the three P-series and two localized forms"
        )

    mdot = payload.get("mass_flow_trend", {})
    for publication_id in displayed_models.get("mass_flow_trend", []):
        nominal_count = mdot.get("nominal_models", {}).get(publication_id, {}).get("row_count")
        test_count = mdot.get("test_models", {}).get(publication_id, {}).get("row_count")
        if nominal_count != 4 or test_count != 6:
            problems.append(
                f"{publication_id} mass-flow counts: expected 4 nominal/6 test, "
                f"observed {nominal_count!r}/{test_count!r}"
            )

    expected_counts = {
        "training_TP_P1": 24,
        "training_TP_P2-CFD": 24,
        "training_TP_Localized-CFD": 24,
        "training_TW_P1": 28,
        "training_TW_P2-CFD": 28,
        "training_TW_Localized-CFD": 28,
        "test_TP_P1": 36,
        "test_TP_P2-CFD": 36,
        "test_TP_Localized-CFD": 36,
        "test_TW_P1": 42,
        "test_TW_P2-CFD": 42,
        "test_TW_Localized-CFD": 42,
    }
    parity = payload.get("temperature_parity", {})
    for key, expected in expected_counts.items():
        observed = parity.get(key, {}).get("row_count")
        if observed != expected:
            problems.append(f"{key} row_count: expected {expected}, observed {observed!r}")

    outputs = payload.get("outputs", {})
    output_paths = list(outputs) if isinstance(outputs, dict) else []
    if not output_paths:
        problems.append("no figure output paths recorded")
    else:
        missing = [value for value in output_paths if not (repo / value).is_file()]
        if missing:
            problems.append(f"recorded figure outputs missing: {missing}")
        for value in output_paths:
            path = repo / value
            recorded = outputs.get(value, {}).get("sha256")
            if path.is_file():
                observed = hashlib.sha256(path.read_bytes()).hexdigest()
                if observed != recorded:
                    problems.append(f"output checksum mismatch: {value}")

    sources = payload.get("source_files", {})
    if not isinstance(sources, dict) or not sources:
        problems.append("source-file provenance missing")
    else:
        for name, record in sources.items():
            source_path = repo / str(record.get("path", ""))
            if not source_path.is_file():
                problems.append(f"source missing: {name} -> {source_path}")
                continue
            observed = hashlib.sha256(source_path.read_bytes()).hexdigest()
            if observed != record.get("sha256"):
                problems.append(f"source checksum mismatch: {name}")
    return not problems, "; ".join(problems) if problems else (
        f"validated {FIGURE_VALIDATION} and {len(output_paths)} output path(s)"
    )


def scan_build_log(repo: Path) -> tuple[bool, str]:
    log_path = repo / "masterthesis.log"
    blg_path = repo / "masterthesis.blg"
    if not log_path.is_file():
        return False, "masterthesis.log missing"
    log = read_text(log_path)
    lower = log.lower()
    problems: list[str] = []
    patterns = {
        "LaTeX errors": r"(?m)^!|emergency stop|fatal error occurred",
        "LaTeX warnings": r"(?m)^latex warning:",
        "package warnings": r"(?m)^package .+ warning:",
        "undefined citations": r"citation [`'][^\\n]+ undefined|undefined citations",
        "undefined references": r"reference [`'][^\\n]+ undefined|undefined references",
        "multiply-defined labels": r"multiply defined",
        "rerun-required warnings": (
            r"label\\(s\\) may have changed|rerun to get cross-references right"
        ),
        "overfull boxes": r"overfull \\[hv]box",
        "float failures": r"too many unprocessed floats|float too large",
        "PDF inclusion compatibility warnings": (
            r"pdftex warning:[\s\S]{0,240}?pdf incl\s*usion"
        ),
    }
    for label, pattern in patterns.items():
        count = len(re.findall(pattern, lower))
        if count:
            problems.append(f"{label}: {count}")
    if not blg_path.is_file():
        problems.append("masterthesis.blg missing")
    else:
        blg = read_text(blg_path)
        bib_warnings = len(re.findall(r"(?m)^Warning--", blg))
        if bib_warnings:
            problems.append(f"BibTeX warnings: {bib_warnings}")
        if re.search(
            r"i couldn't open|i found no|i was expecting|error message", blg.lower()
        ):
            problems.append("BibTeX errors present")
    return not problems, "; ".join(problems) if problems else (
        "no LaTeX/BibTeX errors or warnings, unresolved citations/references, "
        "rerun warnings, overfull boxes, PDF inclusion warnings, or float failures"
    )


def git_sha(repo: Path) -> str:
    process = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=repo,
        text=True,
        capture_output=True,
        check=False,
    )
    return process.stdout.strip() if process.returncode == 0 else "unknown"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--repo-root", type=Path, default=Path(__file__).resolve().parents[1]
    )
    parser.add_argument("--build-exit-code", type=int, default=0)
    parser.add_argument(
        "--json-report", type=Path, default=Path("reports/scientific_triage_qa.json")
    )
    parser.add_argument(
        "--markdown-report",
        type=Path,
        default=Path("reports/scientific_triage_qa.md"),
    )
    args = parser.parse_args()
    repo = args.repo_root.resolve()
    checks: list[dict[str, Any]] = []

    add_check(
        checks,
        "thesis build command",
        args.build_exit_code == 0,
        f"build_thesis.sh exit code {args.build_exit_code}",
    )

    body_path = repo / "structural/body.tex"
    body = strip_comments(read_text(body_path)) if body_path.is_file() else ""
    pre_appendix_body = body.split(r"\appendices", 1)[0]
    observed_chapters = [
        token
        for token in INCLUDE_RE.findall(pre_appendix_body)
        if token.startswith("chapters/")
    ]
    add_check(
        checks,
        "active six-chapter order",
        observed_chapters == EXPECTED_CHAPTER_TOKENS,
        f"observed {observed_chapters!r}",
    )

    tex_files, missing_includes = collect_active_tex(repo)
    add_check(
        checks,
        "active TeX include closure",
        not missing_includes,
        "all active includes resolve" if not missing_includes
        else f"missing {missing_includes}",
    )
    active_text_by_path = {
        path.relative_to(repo).as_posix(): strip_comments(read_text(path))
        for path in tex_files
    }
    active_text = "\n".join(active_text_by_path.values())
    placeholders = sorted(
        set(re.findall(r"\b(?:FIXME|TODO)\b", active_text, flags=re.IGNORECASE))
    )
    add_check(
        checks,
        "no active FIXME/TODO placeholders",
        not placeholders,
        "none found" if not placeholders else f"found {placeholders}",
    )

    referenced_graphics, missing_graphics = graphics_status(repo, tex_files)
    add_check(
        checks,
        "all active figures present",
        bool(referenced_graphics) and not missing_graphics,
        f"{len(referenced_graphics)} referenced figure(s); "
        + ("all resolve" if not missing_graphics else f"missing {missing_graphics}"),
    )

    training_path = (
        repo
        / "evidence/cfd_mdot_salt1_4_refresh_2026_08_03"
        / "predictive_model_scorecard_salt1_4.csv"
    )
    holdout_path = (
        repo
        / "evidence/predictive_model_score_release_2026_07_28"
        / "holdout_candidate_scorecard.csv"
    )
    try:
        training = read_csv_index(training_path, "publication_id")
        holdout = read_csv_index(holdout_path, "publication_id")
        score_source_error = ""
    except (OSError, KeyError) as exc:
        training, holdout = {}, {}
        score_source_error = str(exc)
    for model, expected in TRAINING_EXPECTED.items():
        passed, problems = validate_score_row(training.get(model), expected)
        add_check(
            checks,
            f"{model} nominal frozen prediction with Salt1--Salt4 target refresh",
            passed,
            "; ".join(problems) if problems else (
                f"exact source values, {expected['tp_rows']} TP and "
                f"{expected['tw_rows']} TW rows, audited policy"
            ),
        )
    for model, expected in HOLDOUT_EXPECTED.items():
        passed, problems = validate_score_row(holdout.get(model), expected)
        row = holdout.get(model, {})
        for field, expected_value in {
            "split": "holdout_testing",
            "exposure_class": "split_designated_repeated_exposure_retrospective",
            "fit_on_holdout": "False",
            "selected_on_holdout": "False",
            "pristine_first_exposure": "False",
        }.items():
            if row.get(field) != expected_value:
                problems.append(
                    f"{field}: expected {expected_value!r}, observed {row.get(field)!r}"
                )
                passed = False
        add_check(
            checks,
            f"{model} retrospective-holdout frozen score",
            passed,
            "; ".join(problems) if problems else (
                f"exact source values, {expected['tp_rows']} TP and "
                f"{expected['tw_rows']} TW rows, repeated-exposure policy"
            ),
        )
    if score_source_error:
        add_check(checks, "frozen score sources readable", False, score_source_error)

    localized_root = repo / "evidence/localized_conjugate_model_2026_08_03"
    localized_refresh_root = repo / "evidence/cfd_mdot_salt1_4_refresh_2026_08_03"
    localized_problems: list[str] = []
    try:
        localized_thermal = read_csv_index(
            localized_root / "hydraulic_resistance_scores.csv", "candidate_id"
        )
        localized_flow = read_csv_index(
            localized_refresh_root / "localized_model_scorecard_salt1_4.csv",
            "candidate_id",
        )
        for candidate_id, expected in LOCALIZED_EXPECTED.items():
            thermal_row = localized_thermal.get(candidate_id, {})
            flow_row = localized_flow.get(candidate_id, {})
            for field in (
                "tp_rmse_K",
                "policy_tw_rmse_K",
                "balanced_tp_tw_rmse_K",
            ):
                if not nearly_equal(thermal_row.get(field, ""), expected[field]):
                    localized_problems.append(
                        f"{candidate_id}:{field}={thermal_row.get(field)!r}"
                    )
            if not nearly_equal(
                flow_row.get("cfd_mdot_mape_pct_salt1_4", ""),
                expected["cfd_mdot_mape_pct_salt1_4"],
            ):
                localized_problems.append(
                    f"{candidate_id}:cfd_mdot_mape_pct_salt1_4="
                    f"{flow_row.get('cfd_mdot_mape_pct_salt1_4')!r}"
                )
            if not nearly_equal(
                flow_row.get("balanced_tp_tw_rmse_K", ""),
                expected["balanced_tp_tw_rmse_K"],
            ):
                localized_problems.append(
                    f"{candidate_id}:refreshed balanced score mismatch"
                )
    except (OSError, KeyError) as exc:
        localized_problems.append(str(exc))
    add_check(
        checks,
        "localized nominal scores and Salt1--Salt4 flow refresh",
        not localized_problems,
        "two localized rows reproduce exact TP, TW, balanced, and refreshed flow scores"
        if not localized_problems else "; ".join(localized_problems),
    )

    heat_path_problems: list[str] = []
    try:
        with (
            repo / "evidence/localized_heat_path_audit_2026_08_10/heat_path_summary_metrics.csv"
        ).open(newline="", encoding="utf-8-sig") as handle:
            heat_path_rows = {
                row["comparison"]: row
                for row in csv.DictReader(handle)
                if row["objective_label"] == "experimental_mdot"
            }
        expected_ratios = {
            "cooler": 0.152328,
            "ordinary_attribution": 1.796608,
            "junction_region_total": 4.405567,
        }
        for comparison, expected_ratio in expected_ratios.items():
            row = heat_path_rows.get(comparison, {})
            if row.get("objective_label") != "experimental_mdot" or not nearly_equal(
                row.get("mean_model_to_cfd_ratio", ""), expected_ratio, tolerance=1e-6
            ):
                heat_path_problems.append(
                    f"{comparison}: ratio={row.get('mean_model_to_cfd_ratio')!r}"
                )
        with (
            repo / "evidence/localized_heat_path_audit_2026_08_10/junction_distribution_summary.csv"
        ).open(newline="", encoding="utf-8-sig") as handle:
            junction_rows = {
                row["physical_junction_bucket"]: row
                for row in csv.DictReader(handle)
                if row["objective_label"] == "experimental_mdot"
            }
        all_junctions = junction_rows.get("all_junctions", {})
        upper_right = junction_rows.get("upper_right", {})
        if not nearly_equal(
            all_junctions.get("mean_total_variation_distance", ""),
            0.111350589,
            tolerance=1e-9,
        ):
            heat_path_problems.append("four-junction total-variation distance mismatch")
        if not nearly_equal(
            upper_right.get("mean_cfd_fraction", ""), 0.360888850, tolerance=1e-9
        ):
            heat_path_problems.append("upper-right CFD junction share mismatch")
    except (OSError, KeyError) as exc:
        heat_path_problems.append(str(exc))
    add_check(
        checks,
        "localized heat-path magnitude and spatial audit",
        not heat_path_problems,
        "cooler, ordinary, junction-region, and four-junction results match the compact audit"
        if not heat_path_problems else "; ".join(heat_path_problems),
    )

    chapter5 = active_text_by_path.get(
        "chapters/05_model_assessment_and_interpretation.tex", ""
    )
    displayed_scores = (
        "9.280" in chapter5
        and "12.853" in chapter5
        and "9.602" in chapter5
        and "13.019" in chapter5
        and "3.538" in chapter5
        and "2.835" in chapter5
    )
    add_check(
        checks,
        "reader-facing rounded P1/P2-CFD scores",
        displayed_scores,
        "Chapter 5 contains 9.280, 12.853, 9.602, 13.019 K and 3.538, 2.835%",
    )
    localized_display = (
        "4.957" in chapter5
        and "7.090" in chapter5
        and "0.967" in chapter5
        and "5.989" in chapter5
        and "5.970" in chapter5
        and "use neither $G_J$ nor $G_B$" in chapter5
    )
    add_check(
        checks,
        "reader-facing localized progression and P-model junction semantics",
        localized_display,
        "Chapter 5 reports nominal/test localized scores and states that P1--P4 use neither G_J nor G_B",
    )
    heat_path_display = (
        "Where the localized model removes heat" in chapter5
        and "151.5--214.1-W" in chapter5
        and "36.1\\%" in chapter5
        and "figures/pdf/localized_heat_path_comparison.pdf" in chapter5
        and "Each CFD and localized stack is normalized independently" in chapter5
        and "tables/generated/localized_heat_path_summary.tex" in chapter5
    )
    add_check(
        checks,
        "reader-facing localized heat-path audit",
        heat_path_display,
        "Chapter 5 reports normalized sink shares with explicit independent denominators and the four-junction mismatch",
    )

    caveat_paths = [
        "chapters/abstract.tex",
        "chapters/04_reduced_model_methodology.tex",
        "chapters/05_model_assessment_and_interpretation.tex",
        "chapters/06_conclusions.tex",
    ]
    caveat_problems: list[str] = []
    for path in caveat_paths:
        text = active_text_by_path.get(path, "").lower()
        for label, pattern in {
            "prior-exposure boundary": r"previously\s+exposed|previous\s+availability|available during development|outcomes had been encountered",
            "P2-CFD target-informed": r"target-informed",
            "global 0.08 compensation": r"global\s+0\.08",
        }.items():
            if not re.search(pattern, text):
                caveat_problems.append(f"{path}: missing {label}")
    introduction = active_text_by_path.get("chapters/01_introduction.tex", "").lower()
    if not re.search(r"excluded from the solver inputs", introduction):
        caveat_problems.append("chapters/01_introduction.tex: missing forward-input boundary")
    add_check(
        checks,
        "model-status caveats at decision points",
        not caveat_problems,
        "the introduction defines forward inputs, and the abstract, methods, assessment, and conclusions retain the model-status caveats"
        if not caveat_problems else "; ".join(caveat_problems),
    )

    ch3 = active_text_by_path.get(
        "chapters/03_cfd_reference_and_model_targets.tex", ""
    )
    tp2_requirements = {
        "x coordinate": r"0\.887519",
        "y coordinate": r"-0\.245426",
        "z coordinate": r"(?:0(?:\.0+)?)",
        "right-vertical endpoint": r"right[_\\ ]+vertical.*end",
        "bottom-horizontal inlet": r"bottom[_\\ ]+horizontal[_\\ ]+inlet.*start",
        "one inch before heater incline": r"one[- ]inch|1(?:\.0+)?\s*(?:in|inch)",
    }
    tp2_missing = [
        label for label, pattern in tp2_requirements.items()
        if not re.search(pattern, ch3, flags=re.IGNORECASE | re.DOTALL)
    ]
    add_check(
        checks,
        "TP2 exact coordinate and 1D station",
        not tp2_missing,
        "TP2 coordinate, shared segment marker, and one-inch placement are present"
        if not tp2_missing else f"missing {tp2_missing}",
    )

    pressure_text = "\n".join(
        active_text_by_path.get(path, "")
        for path in (
            "chapters/02_thermal_fluids_and_reduction.tex",
            "chapters/03_cfd_reference_and_model_targets.tex",
        )
    ).lower()
    pressure_requirements = {
        "stored p_rgh basis": r"stored.{0,60}p_\{?\\mathrm\{rgh\}\}?",
        "delta p_rgh": r"\\delta\s*p_\{?\\mathrm\{rgh\}\}?",
        "dynamic head": r"dynamic head",
        "reduced-total-pressure proxy": r"reduced[- ]total[- ]pressure proxy",
        "density-gradient buoyancy": r"density[- ]gradient buoyancy",
        "inertial term": r"inertial term",
        "mechanical residual": r"mechanical\s+(?:loss\s+)?residual",
        "not absolute stagnation pressure": (
            r"(?:not|neither)\s+(?:an?\s+)?absolute\s+stagnation\s+pressure"
        ),
        "not direct wall-shear evidence": (
            r"(?:not|neither)\s+(?:a\s+)?direct\s+wall[- ]shear\s+"
            r"(?:measure(?:ment)?|evidence)"
        ),
    }
    pressure_missing = [
        label for label, pattern in pressure_requirements.items()
        if not re.search(pattern, pressure_text, flags=re.IGNORECASE | re.DOTALL)
    ]
    add_check(
        checks,
        "independent stored-p_rgh ledger claim boundaries",
        not pressure_missing,
        "ledger terms and all interpretation qualifiers are reader-facing"
        if not pressure_missing else f"missing {pressure_missing}",
    )

    figure_ok, figure_detail = validate_figure_payload(repo)
    add_check(
        checks,
        "scientific-triage figure validation",
        figure_ok,
        figure_detail,
    )

    log_ok, log_detail = scan_build_log(repo)
    add_check(checks, "clean LaTeX/BibTeX logs", log_ok, log_detail)

    pdf_path = repo / "masterthesis.pdf"
    pdf_ok = False
    pdf_detail = "masterthesis.pdf missing"
    if pdf_path.is_file():
        process = subprocess.run(
            ["pdfinfo", str(pdf_path)],
            text=True,
            capture_output=True,
            check=False,
        )
        page_match = re.search(r"(?m)^Pages:\s+(\d+)", process.stdout)
        pages = int(page_match.group(1)) if page_match else 0
        size = pdf_path.stat().st_size
        # The implementation-ready two-state methods/results integration grows
        # the six-chapter dissertation beyond the former 110-page scaffold
        # ceiling while retaining a bounded plausibility check.
        pdf_ok = process.returncode == 0 and 60 <= pages <= 145 and size >= 100_000
        pdf_detail = f"pages={pages}, bytes={size}, pdfinfo_exit={process.returncode}"
    add_check(checks, "PDF existence and page plausibility", pdf_ok, pdf_detail)

    stale_routes = 0
    closure_path = repo / "reports/FINAL_FIXME_CLOSURE_REGISTER.csv"
    if closure_path.is_file():
        with closure_path.open(newline="", encoding="utf-8-sig") as handle:
            for row in csv.DictReader(handle):
                joined = " ".join(row.values())
                if re.search(r"chapters/0[6-9]_", joined):
                    stale_routes += 1
    deferred = [
        {
            "name": "repository evidence size/retention-manifest reconciliation",
            "status": "DEFERRED",
            "blocking": False,
            "detail": (
                "This focused gate does not certify evidence-tree size, retained-package "
                "inventory, or cleanup-summary consistency; those known defects remain open."
            ),
        },
        {
            "name": "legacy FIXME closure-register reconciliation",
            "status": "DEFERRED",
            "blocking": False,
            "detail": (
                f"{stale_routes} row(s) still reference retired Chapters 6--9; "
                "the 73-row historical closure claim is not certified by this gate."
            ),
        },
    ]

    failed = [check for check in checks if check["status"] == "FAIL"]
    report = {
        "schema_version": 1,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "git_base_sha": git_sha(repo),
        "status": "FAIL" if failed else "PASS",
        "summary": {
            "blocking_checks": len(checks),
            "blocking_passed": len(checks) - len(failed),
            "blocking_failed": len(failed),
            "deferred_warnings": len(deferred),
        },
        "checks": checks,
        "deferred": deferred,
        "active_tex_files": [
            path.relative_to(repo).as_posix() for path in tex_files
        ],
        "active_figures": referenced_graphics,
    }

    json_path = args.json_report
    markdown_path = args.markdown_report
    if not json_path.is_absolute():
        json_path = repo / json_path
    if not markdown_path.is_absolute():
        markdown_path = repo / markdown_path
    json_path.parent.mkdir(parents=True, exist_ok=True)
    markdown_path.parent.mkdir(parents=True, exist_ok=True)
    json_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")

    lines = [
        "# Scientific Triage QA",
        "",
        f"Status: **{report['status']}**",
        "",
        f"Generated: `{report['generated_at_utc']}`",
        "",
        f"Working-tree base SHA: `{report['git_base_sha']}`",
        "",
        "## Blocking checks",
        "",
    ]
    lines.extend(
        f"- {check['status']} — **{check['name']}**: {check['detail']}"
        for check in checks
    )
    lines.extend(["", "## Deferred warnings", ""])
    lines.extend(
        f"- DEFERRED — **{warning['name']}**: {warning['detail']}"
        for warning in deferred
    )
    lines.extend(
        [
            "",
            "A PASS applies only to the focused six-chapter scientific/build gate. "
            "It does not close either deferred repository-hygiene defect.",
            "",
        ]
    )
    markdown_path.write_text("\n".join(lines), encoding="utf-8")

    print(
        f"{report['status']}: {len(checks) - len(failed)}/{len(checks)} "
        f"blocking checks passed; {len(deferred)} deferred warning(s)"
    )
    for check in failed:
        print(f"FAIL: {check['name']}: {check['detail']}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
