#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
repo_root="$(cd "${script_dir}/.." && pwd)"
papers_root="$(cd "${repo_root}/../.." && pwd)"
litrev_root="${papers_root}/UTexas_Research/LitRev-start---Closure-and-Modeling-Decisions-for-Developing-HITEC-Flow-TAMU-MSFL"

fail=0

echo "== CSEM guardrail check =="
echo "repo: ${repo_root}"

echo
echo "== TODO.md policy =="
todo_files="$(find "${repo_root}" -name TODO.md -print)"
if [ -d "${litrev_root}" ]; then
  todo_files="${todo_files}"$'\n'"$(find "${litrev_root}" -name TODO.md -print)"
fi
todo_files="$(printf '%s\n' "${todo_files}" | sed '/^$/d')"
if [ -n "${todo_files}" ]; then
  echo "FAIL: TODO.md files belong on ../../.agent/BOARD.md, not in thesis or LitRev trees:"
  printf '%s\n' "${todo_files}"
  fail=1
else
  echo "PASS: no TODO.md files found in CSEM thesis or LitRev tree."
fi

echo
echo "== List compatibility =="
if rg -n --pcre2 '^[^%]*\\usepackage(?:\[[^]]*\])?\{enumitem\}' "${repo_root}/structural/preamble.tex"; then
  echo "FAIL: live enumitem package use found."
  fail=1
else
  echo "PASS: no live enumitem package use."
fi

if rg -n --pcre2 '^[^%]*\\begin\{(itemize|enumerate)\}\[' "${repo_root}/intro_adjacent" "${repo_root}/chapters"; then
  echo "FAIL: live optional list starts require enumitem."
  fail=1
else
  echo "PASS: no live optional itemize/enumerate starts."
fi

echo
echo "== Evidence placeholders =="
if rg -n 'TODO\[source\]' "${repo_root}/chapters" "${repo_root}/intro_adjacent"; then
  echo "NOTE: TODO[source] markers remain. Keep them tied to board-scoped evidence-import rows."
else
  echo "PASS: no TODO[source] markers found."
fi

echo
echo "== LaTeX log warnings =="
if [ -f "${repo_root}/masterthesis.log" ]; then
  if rg -n 'undefined references|undefined citations|Package natbib Warning' "${repo_root}/masterthesis.log"; then
    echo "FAIL: unresolved citation/reference warnings remain in masterthesis.log."
    fail=1
  else
    echo "PASS: no unresolved citation/reference warnings in masterthesis.log."
  fi
else
  echo "NOTE: masterthesis.log not present; run scripts/build_thesis.sh for build validation."
fi

echo
echo "== Claim-boundary phrases =="
if rg -n 'SAM validation|experimental validation|wallHeatFlux|CFD mass flow|component \$?K|final predictive' "${repo_root}/chapters" "${repo_root}/intro_adjacent"; then
  echo "NOTE: review the hits above for caveats. These phrases are allowed only with non-validation/runtime-leakage guardrails."
else
  echo "PASS: no high-risk claim-boundary phrases found."
fi

exit "${fail}"
