#!/usr/bin/env python3
"""Check repository navigation, active-manifest consistency, and source cleanliness."""
from pathlib import Path
import argparse,csv,json,re
ROOT=Path(__file__).resolve().parents[1]
ALLOWED={"controlling","active-support","unresolved","historical","superseded","generated"}
BUILD_EXTS={".aux",".log",".out",".toc",".lof",".lot",".blg",".bbl",".fls",".fdb_latexmk"}
REQUIRED_READMES=["chapters/README.md","draft_coordination/README.md","draft_coordination/requests_to_repo_agent/README.md","evidence/README.md","reports/README.md","scripts/README.md"]
REQUIRED_CONTROLS=["README.md","draft_coordination/00_start_here.md","draft_coordination/00_repository_map.md","draft_coordination/01_current_state.md","draft_coordination/model_status/current_model_status.md","draft_coordination/evidence_maps/latest_evidence_map.md","draft_coordination/active_file_manifest.csv"]
def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--allow-build-artifacts",action="store_true"); ap.add_argument("--json",default="reports/navigation_integrity_latest.json"); ap.add_argument("--markdown",default="reports/navigation_integrity_latest.md"); a=ap.parse_args()
    issues=[]; warnings=[]
    with (ROOT/"draft_coordination/active_file_manifest.csv").open(newline="",encoding="utf-8-sig") as h: rows=list(csv.DictReader(h))
    seen={}
    for r in rows:
        path=r["relative_path"]; seen[path]=seen.get(path,0)+1
        if r["status"] not in ALLOWED: issues.append(f"invalid status {r['status']!r} for {path}")
        if not (ROOT/path).exists(): issues.append(f"manifest path missing: {path}")
        if r["status"]=="controlling" and r.get("superseded_by"): issues.append(f"controlling file marked superseded: {path}")
        if r["status"]=="superseded" and r.get("controlling_for"): issues.append(f"superseded file still claims controlling role: {path}")
    issues += [f"duplicate manifest path: {p}" for p,c in seen.items() if c>1]
    for p in REQUIRED_CONTROLS:
        if not (ROOT/p).exists(): issues.append(f"missing controlling file: {p}")
    for p in REQUIRED_READMES:
        if not (ROOT/p).exists(): issues.append(f"missing required README: {p}")
    maptext=(ROOT/"draft_coordination/00_repository_map.md").read_text(encoding="utf-8")
    for token in re.findall(r"`([^`]+)`",maptext):
        if any(ch in token for ch in "*[]") or token.startswith("0."): continue
        target=ROOT/token.rstrip("/")
        if "/" in token and not target.exists(): issues.append(f"repository-map path missing: {token}")
    allowed_latest={"draft_coordination/evidence_maps/latest_evidence_map.md","reports/build_qa_latest.md","reports/build_qa_latest.json","reports/navigation_integrity_latest.md","reports/navigation_integrity_latest.json","evidence/latest_model_updates_2026_07_22/s13_clean_sampler_gci_readiness/latest_sampler_success_gate.csv"}
    latest=[p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_file() and "latest" in p.name.lower() and "archive" not in p.parts]
    warnings += [f"unregistered file claims latest status: {p}" for p in latest if p not in allowed_latest]
    clutter=[p.relative_to(ROOT).as_posix() for p in ROOT.rglob("*") if p.is_file() and p.suffix in BUILD_EXTS]
    if clutter and not a.allow_build_artifacts: issues.append(f"generated LaTeX clutter present ({len(clutter)} files)")
    elif clutter: warnings.append(f"transient build artifacts present during build ({len(clutter)} files)")
    report={"status":"pass" if not issues else "fail","manifest_rows":len(rows),"issues":issues,"warnings":warnings,"build_artifacts":clutter,"registered_latest_files":sorted(latest)}
    jp=ROOT/a.json; mp=ROOT/a.markdown; jp.parent.mkdir(parents=True,exist_ok=True); mp.parent.mkdir(parents=True,exist_ok=True)
    jp.write_text(json.dumps(report,indent=2)+"\n",encoding="utf-8")
    md=["# Navigation Integrity Audit","",f"Status: **{report['status']}**","",f"Manifest rows: {len(rows)}","","## Issues"]+( [f"- {x}" for x in issues] or ["- None."] )+["","## Warnings"]+( [f"- {x}" for x in warnings] or ["- None."] )+["","## Generated build artifacts"]+( [f"- `{x}`" for x in clutter] or ["- None."] )
    mp.write_text("\n".join(md)+"\n",encoding="utf-8")
    print(json.dumps(report,indent=2)); return 1 if issues else 0
if __name__=="__main__": raise SystemExit(main())
