#!/usr/bin/env python3
"""Source and build QA for the active dissertation tree."""
from __future__ import annotations

import argparse
import json
import re
import subprocess
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

INCLUDE_RE = re.compile(r"\\(?:input|include)\{([^}]+)\}")
GRAPHICS_RE = re.compile(r"\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}")
LABEL_RE = re.compile(r"\\label\{([^}]+)\}")
CHAPTER_RE = re.compile(r"\\chapter(?:\[[^]]*\])?\{([^}]+)\}")
COMMENT_RE = re.compile(r"(?m)(?<!\\)%.*$")

EXPECTED_CHAPTERS = [
    "Introduction and Research Objectives",
    "Thermal-Fluids Formulation and CFD-to-1D Reduction",
    "TAMU Loop, CFD Reference, and Modeling Targets",
    "Complete One-Dimensional Model Definition",
    "Model Assessment, Mechanism Analysis, and Limitations",
    "Conclusions, Limitations, and Future Work",
]


def strip_comments(text: str) -> str:
    return COMMENT_RE.sub("", text)


def resolve_tex(repo: Path, token: str) -> Path:
    path = repo / token
    if not path.suffix:
        path = path.with_suffix(".tex")
    return path


def collect_active_tex(repo: Path):
    root = repo / "masterthesis.tex"
    seen, missing, order = set(), [], []

    def walk(path: Path):
        path = path.resolve()
        if path in seen:
            return
        seen.add(path)
        if not path.is_file():
            missing.append(str(path.relative_to(repo.resolve())) if path.is_relative_to(repo.resolve()) else str(path))
            return
        order.append(path)
        text = strip_comments(path.read_text(encoding="utf-8", errors="replace"))
        for token in INCLUDE_RE.findall(text):
            walk(resolve_tex(repo, token))

    walk(root)
    return order, missing


def check_graphics(repo: Path, files):
    missing, searched = [], []
    extensions = ["", ".pdf", ".png", ".jpg", ".jpeg", ".eps"]
    for path in files:
        text = strip_comments(path.read_text(encoding="utf-8", errors="replace"))
        for token in GRAPHICS_RE.findall(text):
            base = repo / token
            candidates = [base] if base.suffix else [Path(str(base) + ext) for ext in extensions]
            searched.append(token)
            if not any(candidate.is_file() for candidate in candidates):
                missing.append({"source": str(path.relative_to(repo)), "graphic": token})
    return missing, searched


def check_backend(repo: Path):
    preamble = strip_comments((repo / "structural" / "preamble.tex").read_text(encoding="utf-8", errors="replace"))
    body = strip_comments((repo / "structural" / "body.tex").read_text(encoding="utf-8", errors="replace"))
    checks = {
        "natbib_loaded": bool(re.search(r"\\usepackage(?:\[[^]]*\])?\{natbib\}", preamble)),
        "unsrtnat_selected": "\\bibliographystyle{unsrtnat}" in body,
        "bibtex_resources_selected": "\\bibliography{references,bibliography/litrev_references_bibtex}" in body,
        "no_biblatex_package": "{biblatex}" not in preamble,
        "no_addbibresource": "\\addbibresource" not in preamble,
        "no_printbibliography": "\\printbibliography" not in body,
    }
    return {"checks": checks, "ok": all(checks.values())}


def scan_log(repo: Path):
    log = repo / "masterthesis.log"
    blg = repo / "masterthesis.blg"
    result = {
        "log_present": log.exists(),
        "bibtex_log_present": blg.exists(),
        "latex_errors": [],
        "undefined_citations": [],
        "undefined_references": [],
        "float_warnings": [],
        "overfull_hbox": [],
        "overfull_vbox": [],
        "underfull_hbox_count": 0,
        "underfull_vbox_count": 0,
        "bibtex_errors": [],
        "bibtex_warnings": [],
    }
    if log.exists():
        lines = log.read_text(encoding="utf-8", errors="replace").splitlines()
        for line in lines:
            low = line.lower()
            if line.startswith("!") or "emergency stop" in low or "fatal error" in low:
                result["latex_errors"].append(line)
            if "citation" in low and "undefined" in low:
                result["undefined_citations"].append(line)
            if "reference" in low and "undefined" in low:
                result["undefined_references"].append(line)
            if "too many unprocessed floats" in low or "float too large" in low or "float specifier changed" in low:
                result["float_warnings"].append(line)
            if "overfull \\hbox" in low:
                result["overfull_hbox"].append(line)
            if "overfull \\vbox" in low:
                result["overfull_vbox"].append(line)
            if "underfull \\hbox" in low:
                result["underfull_hbox_count"] += 1
            if "underfull \\vbox" in low:
                result["underfull_vbox_count"] += 1
    if blg.exists():
        for line in blg.read_text(encoding="utf-8", errors="replace").splitlines():
            low = line.lower()
            if line.startswith("Warning--"):
                result["bibtex_warnings"].append(line)
            if any(token in low for token in ["i couldn't open", "i found no", "i was expecting", "illegal,", "error message"]):
                result["bibtex_errors"].append(line)
    return result


def bibliography_check(repo: Path):
    proc = subprocess.run(
        ["python3", str(repo / "scripts" / "check_bibliography.py"), "--repo-root", str(repo), "--json"],
        text=True, capture_output=True,
    )
    try:
        payload = json.loads(proc.stdout)
    except json.JSONDecodeError:
        payload = {"tool_error": proc.stderr or proc.stdout}
    payload["exit_code"] = proc.returncode
    return payload


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--source-only", action="store_true")
    parser.add_argument("--write-report", action="store_true")
    args = parser.parse_args()
    repo = args.repo_root.resolve()

    files, missing_includes = collect_active_tex(repo)
    rel_files = [str(path.relative_to(repo)) for path in files]
    all_text = "\n".join(strip_comments(path.read_text(encoding="utf-8", errors="replace")) for path in files)

    labels = LABEL_RE.findall(all_text)
    duplicate_labels = sorted(label for label, count in Counter(labels).items() if count > 1)
    missing_graphics, graphics = check_graphics(repo, files)

    manuscript_files = [p for p in files if p.parts[-2] in {"chapters", "intro_adjacent"}]
    terminology_proc = subprocess.run(
        ["python3", str(repo / "scripts" / "check_terminology.py"), "--repo-root", str(repo), "--json"],
        text=True, capture_output=True,
    )
    try:
        terminology = json.loads(terminology_proc.stdout)
    except json.JSONDecodeError:
        terminology = {"tool_error": terminology_proc.stderr or terminology_proc.stdout, "ok": False}
    terminology["exit_code"] = terminology_proc.returncode

    placeholders = []
    fixme_comments = []
    placeholder_patterns = [r"TODO\[source\]", r"\bFIXME\b", r"\bTBD\b", r"\bTO BE CONFIRMED\b", r"\\graduationmonth\{Month\}", r"\\graduationyear\{Year\}"]
    for path in files:
        raw_text = path.read_text(encoding="utf-8", errors="replace")
        active_text = strip_comments(raw_text)
        for idx, line in enumerate(active_text.splitlines(), 1):
            if any(re.search(pattern, line, flags=re.I) for pattern in placeholder_patterns):
                placeholders.append({"file": str(path.relative_to(repo)), "line": idx, "text": line.strip()})
        for idx, line in enumerate(raw_text.splitlines(), 1):
            if re.search(r"(?<!\\)%.*\bFIXME\b", line, flags=re.I):
                fixme_comments.append({"file": str(path.relative_to(repo)), "line": idx, "text": line.strip()})

    body = (repo / "structural" / "body.tex").read_text(encoding="utf-8", errors="replace")
    include_tokens = INCLUDE_RE.findall(strip_comments(body))
    chapter_titles = []
    for token in include_tokens:
        path = resolve_tex(repo, token)
        if path.is_file():
            match = CHAPTER_RE.search(strip_comments(path.read_text(encoding="utf-8", errors="replace")))
            if match and not token.startswith("chapters/appendix"):
                chapter_titles.append(match.group(1))
    chapter_order_ok = chapter_titles == EXPECTED_CHAPTERS

    backend = check_backend(repo)
    log_result = {} if args.source_only else scan_log(repo)
    bib_result = bibliography_check(repo)

    hard_failures = []
    if missing_includes:
        hard_failures.append("missing included TeX files")
    if missing_graphics:
        hard_failures.append("missing graphics")
    if duplicate_labels:
        hard_failures.append("duplicate LaTeX labels")
    if terminology.get("exit_code") or terminology.get("tool_error") or not terminology.get("ok", False):
        hard_failures.append("terminology or notation conflict")
    if not chapter_order_ok:
        hard_failures.append("active chapter order/title mismatch")
    if not backend["ok"]:
        hard_failures.append("bibliography backend configuration mismatch")
    if bib_result.get("exit_code") or bib_result.get("tool_error"):
        hard_failures.append("bibliography resource, duplicate, or citation errors")
    if not args.source_only:
        if log_result.get("latex_errors") or log_result.get("bibtex_errors"):
            hard_failures.append("LaTeX or BibTeX hard errors")
        if log_result.get("undefined_citations") or log_result.get("undefined_references"):
            hard_failures.append("undefined citations or references")

    residuals = bool(placeholders or log_result.get("float_warnings") or log_result.get("overfull_hbox") or log_result.get("overfull_vbox") or log_result.get("bibtex_warnings"))
    result = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "repo_root": str(repo),
        "active_tex_files": rel_files,
        "missing_includes": missing_includes,
        "graphics_references": graphics,
        "missing_graphics": missing_graphics,
        "duplicate_labels": duplicate_labels,
        "terminology_and_notation": terminology,
        "placeholders": placeholders,
        "fixme_comments": fixme_comments,
        "chapter_titles": chapter_titles,
        "expected_chapter_titles": EXPECTED_CHAPTERS,
        "chapter_order_ok": chapter_order_ok,
        "bibliography_backend": backend,
        "bibliography": bib_result,
        "build_log": log_result,
        "hard_failures": hard_failures,
        "status": "fail" if hard_failures else "pass_with_residuals" if residuals else "pass",
    }

    print(json.dumps(result, indent=2))

    if args.write_report:
        reports = repo / "reports"
        reports.mkdir(exist_ok=True)
        (reports / "build_qa_latest.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
        md = [
            "# Build and QA Report", "", f"Generated: {result['generated_utc']}",
            f"Status: **{result['status']}**", "", "## Hard failures",
        ]
        md += [f"- {item}" for item in hard_failures] or ["- None."]
        md += [
            "", "## Bibliography backend",
            "- Active backend: Natbib + BibTeX",
            "- Style: `unsrtnat`",
            f"- Backend configuration correct: {backend['ok']}",
            f"- BibTeX errors: {len(log_result.get('bibtex_errors', []))}",
            f"- BibTeX warnings: {len(log_result.get('bibtex_warnings', []))}",
            "", "## Build warnings",
            f"- Float warnings: {len(log_result.get('float_warnings', []))}",
            f"- Overfull hboxes: {len(log_result.get('overfull_hbox', []))}",
            f"- Overfull vboxes: {len(log_result.get('overfull_vbox', []))}",
            f"- Underfull hboxes: {log_result.get('underfull_hbox_count', 0)}",
            f"- Underfull vboxes: {log_result.get('underfull_vbox_count', 0)}",
            "", "## References and structure",
            f"- Undefined citations: {len(log_result.get('undefined_citations', []))}",
            f"- Undefined references: {len(log_result.get('undefined_references', []))}",
            f"- Duplicate labels: {len(duplicate_labels)}",
            f"- Missing graphics: {len(missing_graphics)}",
            f"- Chapter order correct: {chapter_order_ok}",
            "", "## Terminology and placeholders",
            f"- User-facing terminology hits: {len(terminology.get('term_hits', []))}",
            f"- Notation-conflict hits: {len(terminology.get('notation_hits', []))}",
            f"- Missing required status definitions: {len(terminology.get('missing_required_definitions', []))}",
            f"- Nomenclature appendix included: {terminology.get('nomenclature_appendix_included', False)}",
            f"- Remaining visible placeholders: {len(placeholders)}",
            f"- Source-only FIXME comments: {len(fixme_comments)}",
        ]
        if placeholders:
            md += ["", "### Visible placeholder details"] + [f"- `{p['file']}:{p['line']}` - {p['text']}" for p in placeholders]
        if fixme_comments:
            md += ["", "### Source-only FIXME comments"] + [f"- `{p['file']}:{p['line']}` - {p['text']}" for p in fixme_comments]
        for key, title in [("float_warnings", "Float warnings"), ("overfull_hbox", "Overfull hbox log lines"), ("overfull_vbox", "Overfull vbox log lines"), ("bibtex_warnings", "BibTeX warnings")]:
            if log_result.get(key):
                md += ["", f"### {title}"] + [f"- `{line}`" for line in log_result[key]]
        (reports / "build_qa_latest.md").write_text("\n".join(md) + "\n", encoding="utf-8")

    return 1 if hard_failures else 0


if __name__ == "__main__":
    raise SystemExit(main())
