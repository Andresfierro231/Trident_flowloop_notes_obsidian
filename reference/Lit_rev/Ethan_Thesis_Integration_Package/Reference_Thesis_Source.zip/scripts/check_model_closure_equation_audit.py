#!/usr/bin/env python3
"""Verify complete audit coverage for labeled equations in Chapters 5 and 6.

The check is structural: every active equation label must have exactly one audit
row and all contract fields must be nonempty. Scientific adequacy remains a
review decision.
"""
from __future__ import annotations

import argparse
import csv
import re
from pathlib import Path

REQUIRED_FIELDS = (
    "equation_id",
    "manuscript_location",
    "physical_domain_or_control_volume",
    "operator_or_definition",
    "sign_convention",
    "si_units",
    "pressure_or_temperature_basis",
    "assumptions_or_validity_conditions",
    "current_evidence_role",
    "predictive_runtime_status",
    "controlling_source",
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--chapter", type=Path, action="append", required=True)
    parser.add_argument("--audit", type=Path, required=True)
    args = parser.parse_args()

    labels: set[str] = set()
    for chapter in args.chapter:
        text = chapter.read_text(encoding="utf-8")
        labels.update(re.findall(r"\\label\{(eq:[^}]+)\}", text))

    with args.audit.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream)
        fieldnames = reader.fieldnames or []
        missing_columns = [name for name in REQUIRED_FIELDS if name not in fieldnames]
        if missing_columns:
            print("FAIL: audit is missing columns: " + ", ".join(missing_columns))
            return 1
        rows = list(reader)

    audited_ids = [row["equation_id"].strip() for row in rows if row["equation_id"].strip()]
    audited = set(audited_ids)
    duplicates = sorted({item for item in audited_ids if audited_ids.count(item) > 1})
    missing_rows = sorted(labels - audited)
    stale_rows = sorted(audited - labels)
    incomplete: list[tuple[int, str, list[str]]] = []
    for index, row in enumerate(rows, start=2):
        empty = [name for name in REQUIRED_FIELDS if not row.get(name, "").strip()]
        if empty:
            incomplete.append((index, row.get("equation_id", "<blank>"), empty))

    if duplicates:
        print("FAIL: duplicate equation audit rows:")
        for item in duplicates:
            print(f"  - {item}")
    if missing_rows:
        print("FAIL: Chapter 5--6 equation labels without audit rows:")
        for item in missing_rows:
            print(f"  - {item}")
    if stale_rows:
        print("FAIL: audit rows without active Chapter 5--6 equation labels:")
        for item in stale_rows:
            print(f"  - {item}")
    if incomplete:
        print("FAIL: incomplete audit rows:")
        for line, equation_id, fields in incomplete:
            print(f"  - CSV line {line}, {equation_id}: {', '.join(fields)}")

    if duplicates or missing_rows or stale_rows or incomplete:
        return 1

    print(f"PASS: {len(labels)} labeled Chapter 5--6 equations have complete audit rows.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
