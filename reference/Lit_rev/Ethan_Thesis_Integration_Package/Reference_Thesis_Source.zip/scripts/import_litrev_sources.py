#!/usr/bin/env python3
"""Refresh the read-only LitRev snapshot and its BibTeX-compatible derivative."""
from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("litrev_root", type=Path, help="Path to the controlling LitRev project")
    parser.add_argument("--repo-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--source-label", help="Stable project label recorded instead of the local absolute path")
    args = parser.parse_args()

    repo = args.repo_root.resolve()
    source_label = args.source_label or str(args.litrev_root.resolve())
    source = (args.litrev_root / "bibliography" / "references.bib").resolve()
    if not source.is_file():
        raise SystemExit(f"LitRev bibliography not found: {source}")

    raw = repo / "bibliography" / "litrev_references.bib"
    compatible = repo / "bibliography" / "litrev_references_bibtex.bib"
    raw.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, raw)

    converter = repo / "scripts" / "prepare_bibtex_litrev.py"
    subprocess.run([
        sys.executable, str(converter),
        "--source", str(raw),
        "--output", str(compatible),
        "--exclude-bib", str(repo / "references.bib"),
    ], check=True)

    updater = repo / "scripts" / "update_bibliography_register.py"
    subprocess.run([
        sys.executable, str(updater),
        "--source-project", source_label,
        "--source-path", "bibliography/references.bib",
    ], check=True)

    print(f"Imported raw snapshot: {raw}")
    print(f"Generated BibTeX resource: {compatible}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
