#!/usr/bin/env bash
set -uo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
repo_root="$(cd "${script_dir}/.." && pwd)"
cd "${repo_root}"

build_status=0
scientific_status=0
source_status=0
release_status=0
figure_layout_status=0

# Invoke the build explicitly through Bash so this gate does not depend on the
# executable bit of a checked-out script.
bash "${script_dir}/build_thesis.sh" || build_status=$?

python3 "${script_dir}/scientific_triage_qa.py" \
  --repo-root "${repo_root}" \
  --build-exit-code "${build_status}" || scientific_status=$?

python3 "${script_dir}/run_qa.py" \
  --repo-root "${repo_root}" \
  --write-report >/dev/null || source_status=$?

python3 "${script_dir}/figures/final_qa.py" >/dev/null || release_status=$?
python3 "${script_dir}/figures/check_figure_layout.py" >/dev/null || figure_layout_status=$?

cat <<EOF

Thesis build status: ${build_status}
Scientific triage QA status: ${scientific_status}
Source/build QA status: ${source_status}
Final scientific-readiness QA status: ${release_status}
Figure-layout QA status: ${figure_layout_status}
JSON report: reports/scientific_triage_qa.json
Markdown report: reports/scientific_triage_qa.md
Source/build report: reports/build_qa_latest.md
Final-readiness report: reports/final_qa.md
EOF

if [[ ${build_status} -ne 0 || ${scientific_status} -ne 0 || ${source_status} -ne 0 || ${release_status} -ne 0 || ${figure_layout_status} -ne 0 ]]; then
  exit 1
fi
