#!/usr/bin/env bash
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
repo_root="$(cd "${script_dir}/.." && pwd)"
cd "${repo_root}"

if command -v module >/dev/null 2>&1; then
  module load texlive/2023 >/dev/null 2>&1 || true
fi

latexmk -pdf -interaction=nonstopmode -halt-on-error masterthesis.tex
