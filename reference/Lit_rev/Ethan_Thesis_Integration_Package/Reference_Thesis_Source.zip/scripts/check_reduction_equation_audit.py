#!/usr/bin/env python3
"""Verify that every labeled Chapter 4 reduction equation has an audit row.

The check is intentionally structural. It confirms equation-label coverage and
nonempty documentation fields; scientific adequacy remains a review decision.
"""
from __future__ import annotations

import argparse
import csv
import re
from pathlib import Path

REQUIRED_FIELDS = (
    "equation_id",
    "physical_domain_or_control_volume",
    "operator_or_definition",
    "sign_convention",
    "si_units",
    "pressure_or_temperature_basis",
    "assumptions_or_validity_conditions",
    "current_evidence_role",
    "predictive_runtime_status",
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--chapter", type=Path, required=True)
    parser.add_argument("--audit", type=Path, required=True)
    args = parser.parse_args()

    chapter_text = args.chapter.read_text(encoding="utf-8")
    labels = set(re.findall(r"\\label\{(eq:[^}]+)\}", chapter_text))

    with args.audit.open(newline="", encoding="utf-8") as stream:
        reader = csv.DictReader(stream)
        missing_columns = [name for name in REQUIRED_FIELDS if name not in (reader.fieldnames or [])]
        if missing_columns:
            print("FAIL: audit is missing columns: " + ", ".join(missing_columns))
            return 1
        rows = list(reader)

    audited = {row["equation_id"].strip() for row in rows if row["equation_id"].strip().startswith("eq:")}
    missing_rows = sorted(labels - audited)
    stale_rows = sorted(audited - labels)
    incomplete = []
    for index, row in enumerate(rows, start=2):
        empty = [name for name in REQUIRED_FIELDS if not row.get(name, "").strip()]
        if empty:
            incomplete.append((index, row.get("equation_id", "<blank>"), empty))

    if missing_rows:
        print("FAIL: Chapter 4 equation labels without audit rows:")
        for item in missing_rows:
            print(f"  - {item}")
    if stale_rows:
        print("FAIL: audit rows without Chapter 4 equation labels:")
        for item in stale_rows:
            print(f"  - {item}")
    if incomplete:
        print("FAIL: incomplete audit rows:")
        for line, equation_id, fields in incomplete:
            print(f"  - CSV line {line}, {equation_id}: {', '.join(fields)}")

    if missing_rows or stale_rows or incomplete:
        return 1

    print(f"PASS: {len(labels)} labeled Chapter 4 equations have complete audit rows.")
    inline_count = sum(1 for row in rows if row["equation_id"].strip().startswith("inline:"))
    if inline_count:
        print(f"NOTE: {inline_count} additional inline relation(s) are documented.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
