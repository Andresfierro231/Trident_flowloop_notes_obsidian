# Scripts

- `compile_and_qa.sh`: full build, scientific triage, source/build QA, and
  final-readiness workflow.
- `build_thesis.sh`: Natbib/BibTeX build only.
- `run_qa.py`: active six-chapter source, bibliography, figure, and build-log QA.
- `check_terminology.py`: coordination-jargon and notation guardrails; scientific
  uses of pressure ledgers and component branches are permitted.
- `figures/final_qa.py`: 28-check final scientific-readiness gate, including
  recomputation of the restored-TW4--TW6 score sensitivity.
- `check_guardrails.sh`: aggregate source guardrails.
- `check_navigation.py`: repository-map and active-manifest integrity audit.
- `update_active_manifest.py`: regenerate the Markdown manifest from CSV.
- `clean_build_artifacts.sh`: remove reproducible LaTeX intermediates.
- equation-audit scripts: validate current Chapter 4 and Chapters 5-6 tables.
- `figures/rebuild_all.sh`: regenerate all approved dissertation figures and generated tables.
- `figures/generate_pass7_figures.py`: evidence-supported schematics/status plots and the internal recirculation composite call.
- `figures/generate_pass7_tables.py`: regenerate Chapter 8 tables from controlled CSV inputs.
- `figures/build_pass7_inventories.py`: rebuild the figure/script/data inventories and production reports.
- `figures/check_pass7_assets.py`: verify figure/table source and output hashes, insertions, and blocked-target status.
- `figures/check_figure_layout.py`: enforce the extension-specific
  `figures/pdf`, `figures/png`, `figures/svg`, `figures/tex`, and
  `figures/data` layout.

Do not edit generated LaTeX outputs. Keep scripts dependency-light and runnable
from the repository root.
