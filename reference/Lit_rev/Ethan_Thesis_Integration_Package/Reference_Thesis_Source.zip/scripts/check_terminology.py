#!/usr/bin/env python3
"""Check terminology and notation in the active reader-facing dissertation."""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

COMMENT_RE = re.compile(r"(?m)(?<!\\)%.*$")
INCLUDE_RE = re.compile(r"\\(?:input|include)\{([^}]+)\}")
REMOVE_COMMANDS = ("label", "ref", "pageref", "cref", "Cref", "path", "texttt")

TERM_PATTERNS = {
    "lane": r"\blanes?\b",
    "owner": r"\bowners?\b|\bownership\b",
    "gate": r"\bgates?\b|\bgated\b|\bgating\b",
    "runtime leakage": r"\bruntime[- ]leakage\b",
    "runtime legality": r"\bruntime[- ]legal(?:ity)?\b",
    "legal use": r"\blegal (?:use|role|split)\b",
    "freeze/frozen": r"\bfreeze\b|\bfrozen\b",
    "admit/admission": r"\badmit(?:ted|s|ting)?\b|\badmission\b",
    "scoreboard": r"\bscoreboards?\b",
    "genealogy": r"\bgenealog(?:y|ies|ical)\b",
    "ledger": r"\bledgers?\b",
    "score/scoring": r"\bscores?\b|\bscored\b|\bscoring\b|\bscorecards?\b",
    "screen/screening": r"\bscreens?\b|\bscreened\b|\bscreening\b",
    "contract": r"\bcontracts?\b(?!\s+No\.)",
    "runtime": r"\bruntime\b",
    "target-free": r"\btarget[- ]free\b",
}

NOTATION_PATTERNS = {
    "ambiguous dynamic-pressure q": r"\bq_i\b|q_\{i\}\s*=\s*\\frac\{1\}\{2\}",
    "non-Darcy friction symbol f_i": r"(?<![A-Za-z])f_i\b|f_\{i\}(?![A-Za-z])",
    "T_env": r"T_\{\\mathrm\{env\}",
    "T_drive": r"T_\{\\mathrm\{drive\}",
}


def strip_comments(text: str) -> str:
    return COMMENT_RE.sub("", text)


def remove_machine_text(text: str) -> str:
    text = strip_comments(text)
    for command in REMOVE_COMMANDS:
        text = re.sub(r"\\" + re.escape(command) + r"\{[^{}]*\}", "", text)
    return text


def resolve_tex(repo: Path, token: str) -> Path:
    path = repo / token
    return path if path.suffix else path.with_suffix(".tex")


def active_manuscript_files(repo: Path) -> list[Path]:
    seen: set[Path] = set()
    ordered: list[Path] = []

    def walk(path: Path) -> None:
        path = path.resolve()
        if path in seen or not path.is_file():
            return
        seen.add(path)
        ordered.append(path)
        text = strip_comments(path.read_text(encoding="utf-8", errors="replace"))
        for token in INCLUDE_RE.findall(text):
            walk(resolve_tex(repo, token))

    walk(repo / "masterthesis.tex")
    return [
        path for path in ordered
        if path.name != "masterthesis.tex"
        and path.parent.name in {"chapters", "structural"}
    ]


def scan(repo: Path) -> dict:
    term_hits: list[dict] = []
    notation_hits: list[dict] = []
    files = active_manuscript_files(repo)
    for path in files:
        for line_no, raw in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), 1):
            line = remove_machine_text(raw)
            for term, pattern in TERM_PATTERNS.items():
                if re.search(pattern, line, flags=re.I):
                    term_hits.append({"term": term, "file": str(path.relative_to(repo)), "line": line_no, "text": raw.strip()})
            for term, pattern in NOTATION_PATTERNS.items():
                if re.search(pattern, line):
                    notation_hits.append({"term": term, "file": str(path.relative_to(repo)), "line": line_no, "text": raw.strip()})

    body = strip_comments((repo / "structural/body.tex").read_text(encoding="utf-8", errors="replace"))
    nomenclature_included = "\\include{chapters/appendix_nomenclature}" in body
    return {
        "active_files": [str(path.relative_to(repo)) for path in files],
        "term_hits": term_hits,
        "notation_hits": notation_hits,
        "missing_required_definitions": [],
        "nomenclature_appendix_included": nomenclature_included,
        "ok": not term_hits and not notation_hits and nomenclature_included,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()
    result = scan(args.repo_root.resolve())
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print("== Terminology and notation check ==")
        print(f"Active files: {len(result['active_files'])}")
        print(f"User-facing terminology hits: {len(result['term_hits'])}")
        for hit in result["term_hits"]:
            print(f"- {hit['file']}:{hit['line']} [{hit['term']}] {hit['text']}")
        print(f"Notation-conflict hits: {len(result['notation_hits'])}")
        for hit in result["notation_hits"]:
            print(f"- {hit['file']}:{hit['line']} [{hit['term']}] {hit['text']}")
        print(f"Nomenclature appendix included: {result['nomenclature_appendix_included']}")
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
