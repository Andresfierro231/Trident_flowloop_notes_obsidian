#!/usr/bin/env python3
"""Audit dissertation evidence products and generate Pass 9 incorporation artifacts.

The audit treats package-level source records as authoritative for quantitative
claims. Synthesis scoreboards and figure packages are checked against those
records and are used only within their verified scope.
"""
from __future__ import annotations

import argparse
import csv
import json
from collections import Counter
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
REPORTS = REPO / "reports"
TABLE_DATA = REPO / "tables" / "data"
TABLE_GEN = REPO / "tables" / "generated"


def read_json(path: Path):
    with path.open(encoding="utf-8") as f:
        return json.load(f)


def write_csv(path: Path, rows: list[dict], fields: list[str]):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        w=csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(rows)


def esc(s: str) -> str:
    return (str(s).replace("\\", r"\textbackslash{}")
            .replace("&", r"\&").replace("%", r"\%")
            .replace("_", r"\_").replace("#", r"\#"))


def top_level_inventory():
    root=REPO/"evidence"
    rows=[]
    for p in sorted(x for x in root.iterdir() if x.is_dir()):
        files=[f for f in p.rglob("*") if f.is_file()]
        exts=Counter((f.suffix.lower() or "<none>") for f in files)
        rows.append({
            "evidence_family":p.name,
            "file_count":len(files),
            "size_bytes":sum(f.stat().st_size for f in files),
            "extensions":"; ".join(f"{k}:{v}" for k,v in exts.most_common()),
        })
    return rows


def credibility_rows():
    return [
      {"evidence_product":"Author clarifications and current model-status records","credibility":"A - controlling","permitted_claim":"Author-specified geometry, title, scope, and current model framing.","limitation":"Controls scope and definitions; does not create new numerical evidence.","thesis_action":"Use directly and record provenance."},
      {"evidence_product":"Current evidence cards with exact source paths","credibility":"A - verified support","permitted_claim":"Bounded numerical or methodological claims stated on each card.","limitation":"Respect case, mesh, quantity, and permitted-use limits.","thesis_action":"Primary route for new quantitative claims."},
      {"evidence_product":"Component package CSV/JSON/README outputs","credibility":"A/B - package dependent","permitted_claim":"Package-level results when source manifest, split role, and guardrails agree.","limitation":"Diagnostic packages do not release predictive coefficients.","thesis_action":"Treat as authoritative over synthesis scoreboards."},
      {"evidence_product":"Master model-form scoreboard","credibility":"B - synthesis","permitted_claim":"Model-development sequence, current blockers, and prioritization after cross-checking.","limitation":"Contains at least one internally inconsistent status row; not a standalone quantitative source.","thesis_action":"Use for navigation and decision structure only."},
      {"evidence_product":"Model-form figure package","credibility":"C for numeric CFD-main-body ranking","permitted_claim":"Nonnumeric model-form ladder and blocked-score structure.","limitation":"Temperature target basis is experimental; numeric ranking is out of the CFD-only main-body scope.","thesis_action":"Retain structural panels; exclude numeric rankings."},
      {"evidence_product":"Velocity-field source package","credibility":"B - qualitative topology","permitted_claim":"Persistent simultaneous upward and downward transport and qualitative recirculation topology.","limitation":"Rendered fields alone do not release an exchange coefficient or mesh-qualified scalar.","thesis_action":"Use existing regenerated composite only."},
      {"evidence_product":"Empty, pending, or not-run scorecards","credibility":"D - no numerical claim","permitted_claim":"A planned model or comparison exists and remains unexecuted.","limitation":"Rows or placeholders are not completed simulations.","thesis_action":"Report as blocked; never infer scores."},
      {"evidence_product":"Superseded or stale staged records","credibility":"C/D - historical","permitted_claim":"Development history or provenance only.","limitation":"May understate current progress or use an incompatible target basis.","thesis_action":"Keep out of controlling prose unless explicitly historical."},
    ]


def scoreboard_checks():
    rows=[]
    cooler_summary=read_json(REPO/"evidence/latest_model_updates_2026_07_22/cooler_removal_model/summary.json")
    master=(REPO/"evidence/latest_model_updates_2026_07_22/master_model_form_scoreboard/master_model_form_scoreboard.csv").read_text(encoding="utf-8")
    cooler_master_line=next((ln for ln in master.splitlines() if ln.startswith("HX_LUMPED_UA_NTU/latest,")),"")
    master_claims_completed=("coupled rows completed=12" in cooler_master_line and "accepted roots=12" in cooler_master_line)
    package_not_run=(cooler_summary.get("run_fluid") is False and cooler_summary.get("coupled_status_counts",{}).get("not_run_use_--run-fluid_on_compute_node",0)==12)
    rows.append({
      "check_id":"SC-COOLER-01","artifact":"Master scoreboard versus cooler package",
      "result":"conflict" if master_claims_completed and package_not_run else "pass",
      "controlling_interpretation":"The package records zero executed coupled cooler rows; only the fixed-mass-flow duty screen is available.",
      "thesis_use":"Do not claim a completed coupled cooler evaluation.",
      "details":f"master_completed_text={master_claims_completed}; package_run_fluid={cooler_summary.get('run_fluid')}; package_status={cooler_summary.get('coupled_status_counts')}"})
    fig_summary=read_json(REPO/"evidence/model_form_figure_package/summary.json")
    rows.append({
      "check_id":"SC-FIGBASIS-01","artifact":"Model-form figure package numeric ranking",
      "result":"scope_exclusion" if fig_summary.get("temperature_target_basis")=="experimental_fluid_validation_targets" else "pass",
      "controlling_interpretation":"The numerical ranking uses experimental temperature targets and is excluded from the CFD-only main-body comparison.",
      "thesis_use":"Use only the nonnumeric ladder and blocked-score structure.",
      "details":f"temperature_target_basis={fig_summary.get('temperature_target_basis')}; final_score_values={fig_summary.get('final_score_values')}"})
    passive=read_json(REPO/"evidence/latest_model_updates_2026_07_22/passive_h2_candidate_source_property_gate_rerun/summary.json")
    rows.append({
      "check_id":"SC-PASSIVE-01","artifact":"PASSIVE-H2 rerun",
      "result":"pass",
      "controlling_interpretation":"Setup and same-quantity diagnostic support improved, while source/property release, freeze, and protected scoring remain closed.",
      "thesis_use":"Report progress and blockers together; no released coefficient.",
      "details":f"decision={passive.get('decision')}"})
    current=read_json(REPO/"evidence/writer_control_surface/summary.json")
    rows.append({
      "check_id":"SC-FINAL-01","artifact":"Final-score status",
      "result":"pass",
      "controlling_interpretation":"No final physical score is released.",
      "thesis_use":"Retain predictive-readiness framing rather than forced validation.",
      "details":json.dumps({k:current.get(k) for k in ['final_score_values','candidate_freeze','protected_scoring']},sort_keys=True)})
    return rows



def incorporation_rows():
    """Curated evidence-to-thesis disposition for the complete repository audit."""
    return [
      {"evidence_id":"EC-EXTRACTION-METHOD-01","product":"CFD extraction methodology and quantity-role matrix","credibility":"A","status_before":"already represented","decision":"retain","thesis_location":"Chapters 3-4","claim_or_use":"Conservative extraction classes and restrictions on predictive runtime inputs.","restriction":"Methodological support only; realized CFD outputs remain evaluation or diagnostic quantities."},
      {"evidence_id":"EC-GEOM-01","product":"Mesh geometry and probe-label provenance","credibility":"A","status_before":"qualitative geometry present; quantitative consequence omitted","decision":"incorporate","thesis_location":"Chapter 3; Chapter 9","claim_or_use":"Corrected span labels and mesh-derived lengths changed downstream UA-prime and line-heat-rate reductions by approximately 27-33 percent.","restriction":"Provenance correction, not a fitted model improvement; retain distinct CFD, physical, and mesh-local diameters."},
      {"evidence_id":"EC-TIMESERIES-UQ-01","product":"Retained-window temporal analysis","credibility":"A","status_before":"method mentioned; quantitative result omitted","decision":"incorporate","thesis_location":"Chapters 3 and 6","claim_or_use":"Fifty-two postprocessing directories support a 600-s retained window and approximately 0.001-0.05 percent relative temporal uncertainty for analyzed steady quantities.","restriction":"Temporal averaging evidence only; does not establish mesh convergence or model accuracy."},
      {"evidence_id":"EC-RADIATION-01","product":"External radiation-boundary microcases","credibility":"A","status_before":"boundary treatment present; sensitivity and supersession omitted","decision":"incorporate","thesis_location":"Chapters 3 and 7","claim_or_use":"CFD total wall heat already contains radiation; fixed-boundary microcases demonstrate the no-double-counting rule.","restriction":"Sensitivity study, not a property/insulation uncertainty range or a per-case radiation split."},
      {"evidence_id":"EC-METRIC-01","product":"Pressure-versus-mass-flow metric lesson","credibility":"A with open item","status_before":"methodological conclusion already present","decision":"retain_bounded","thesis_location":"Chapters 5 and 8","claim_or_use":"Per-section pressure demand is more diagnostic of local hydraulic closure than loop mass flow alone.","restriction":"Do not elevate the unresolved matched-temperature mass-flow discrepancy into a conclusion."},
      {"evidence_id":"EC-REGIME-MAP-01","product":"Nondimensional regime and closure-eligibility study","credibility":"A diagnostic","status_before":"principle implicit; quantitative audit count omitted","decision":"incorporate","thesis_location":"Chapter 5","claim_or_use":"Eighteen case-span rows, eight formula-validity checks, and seven source-overlap records support section-specific model forms.","restriction":"Selection evidence only; it releases no coefficient. Full figure source is not present in the ZIP."},
      {"evidence_id":"EC-UPCOMER-RECIRC-01","product":"Upcomer recirculation and onset evidence","credibility":"A diagnostic","status_before":"already represented","decision":"retain","thesis_location":"Chapters 4, 5, and 7","claim_or_use":"Persistent simultaneous upward and downward transport invalidates an ordinary single-stream upcomer closure.","restriction":"Do not infer a predictive exchange coefficient or mesh-qualified onset threshold."},
      {"evidence_id":"EC-FRICTION-01","product":"Buoyancy-corrected momentum budgets","credibility":"A partial","status_before":"already represented","decision":"retain","thesis_location":"Chapters 5 and 7","claim_or_use":"Fit-safe section friction, substantial local/development demand, and explicit no-double-counting pressure accounting.","restriction":"No global friction multiplier and no coefficient fitting from buoyancy-contaminated gradients."},
      {"evidence_id":"EC-THERMAL-NU-01","product":"Patch-derived thermal quantities","credibility":"A coarse-mesh diagnostic","status_before":"already represented","decision":"retain","thesis_location":"Chapters 5-7","claim_or_use":"Section-resolved Nu, h, and UA-prime values identify local model needs.","restriction":"Diagnostic CFD-derived quantities; not released predictive closures and not substitutes for residual attribution."},
      {"evidence_id":"EC-HYD-GCI-01","product":"Pressure-family mesh comparison","credibility":"A partial","status_before":"already represented","decision":"retain","thesis_location":"Chapter 6","claim_or_use":"Medium/fine consistency supports specified hydraulic quantities on their documented spans.","restriction":"Does not establish global hydraulic mesh independence."},
      {"evidence_id":"EC-MESHGCI-01","product":"S13 same-QOI stability and mesh sensitivity","credibility":"A diagnostic","status_before":"older formal-GCI admission superseded by stricter exact-label audit","decision":"retain_bounded","thesis_location":"Chapter 5","claim_or_use":"Diagnostic medium/fine differences are 0.503 percent for Qwall and 95.499, 24.149, and 52.908 percent for exchange flow, turnover time, and wall-to-adjacent-core contrast.","restriction":"Different physical times and mesh-specific masks prevent formal GCI, discretization-error, QOI-release, or coefficient-admission claims."},
      {"evidence_id":"EC-PASSIVEH2-01","product":"Strict passive-loss source envelope","credibility":"A controlling","status_before":"already represented","decision":"retain","thesis_location":"Chapters 6-8","claim_or_use":"Eight of sixteen strict training rows satisfy the setup-derived source envelope.","restriction":"No source/property release, candidate lock, or final score."},
      {"evidence_id":"EC-PRESSURE-LEDGER-01","product":"Named pressure-term decomposition","credibility":"A","status_before":"already represented","decision":"retain","thesis_location":"Chapters 4, 6, and 7","claim_or_use":"Eighteen section-case rows close with negligible explicit residual and preserve development/local contributions.","restriction":"Do not absorb local, development, recovery, or recirculation terms into global friction."},
      {"evidence_id":"EC-SENSOR-PROJ-01","product":"Sensor projection operator","credibility":"A diagnostic","status_before":"already represented","decision":"retain","thesis_location":"Chapters 3, 4, and 8","claim_or_use":"TP/TW comparisons are made through declared score-only projection operators.","restriction":"Projected evaluation temperatures are not predictive runtime inputs."},
      {"evidence_id":"EC-CFD-ROM-01","product":"CFD-basis affine predictor","credibility":"A controlling for declared split","status_before":"already represented","decision":"retain","thesis_location":"Chapters 7-9 and abstract","claim_or_use":"Quantifies the accuracy-oriented predictive path on the declared CFD split.","restriction":"Separate from the local physical closure path; not experimental validation or a protected physical score."},
      {"evidence_id":"SC-COOLER-01","product":"Master scoreboard cooler row","credibility":"B conflict","status_before":"potentially misleading synthesis row","decision":"exclude_numeric_claim","thesis_location":"Chapter 8 methodology; repository audit","claim_or_use":"Use the conflict to formalize package-over-scoreboard evidence precedence.","restriction":"Controlling cooler package records zero executed coupled rows; retain only fixed-mass-flow duty results."},
      {"evidence_id":"SC-FIGBASIS-01","product":"Model-form figure-package numeric ranking","credibility":"C for current main-body scope","status_before":"available but incompatible target basis","decision":"exclude_numeric_claim","thesis_location":"Structural model-form figure only","claim_or_use":"Use the nonnumeric development ladder and blocked-score structure.","restriction":"Numeric ranking uses experimental targets and is outside the CFD-only main-body comparison."},
      {"evidence_id":"SC-PENDING-01","product":"Empty, pending, and not-run scorecards","credibility":"D","status_before":"available placeholders","decision":"report_blocked","thesis_location":"Chapter 8 readiness discussion; repository reports","claim_or_use":"Identify intended comparisons and computational next steps.","restriction":"No result, coefficient, or score may be inferred."},
      {"evidence_id":"VP-QUAL-01","product":"Velocity-field visual packages","credibility":"B qualitative","status_before":"already represented by reproducible composite","decision":"retain_qualitative","thesis_location":"Chapter 7","claim_or_use":"Locate and interpret persistent recirculation topology.","restriction":"Images alone do not release an exchange coefficient, convergence claim, or scalar onset law."},
    ]

def chapter3_table_rows():
    return [
      {"audit_result":"Geometry and probe-label provenance","quantitative_evidence":r"The legacy probe file interchanged the lower and right leg labels; correcting the labels and mesh-derived lengths changed downstream $UA^\prime$ and $\dot q^\prime$ values by approximately 27--33\%.","modeling_consequence":"Mesh-derived centerlines and span identities control the reduction. The correction is a provenance result, not a fitted model improvement.","evidence_status":"Verified diagnostic; exact rig/mesh orientation audit remains separate."},
      {"audit_result":"Retained-window temporal behavior","quantitative_evidence":r"A trend, autocorrelation, and standard-error study covered 52 postprocessing directories and adopted a 600-s averaging window; analyzed steady quantities had relative temporal uncertainty of approximately 0.001--0.05\%.","modeling_consequence":"The analyzed time averages are statistically settled on their retained windows. This result does not establish mesh independence or model-form accuracy.","evidence_status":"Current, quantity-specific temporal evidence."},
      {"audit_result":"External radiation boundary","quantitative_evidence":r"The CFD boundary uses emissivity 0.95 on 36 external patches with $T_{\mathrm{sur}}\approx T_\infty\approx299$ K. Diagnostic microcases changed the reported wall-heat integral by $-658.6$ W ($\varepsilon=0.10$), $-809.1$ W ($\varepsilon=0$), and $+1912.5$ W ($T_{\mathrm{sur}}=350$ K).","modeling_consequence":"Radiation is already included in the total CFD wall-heat flux. The one-dimensional comparison must reproduce the fixed boundary basis or use the total wall flux without adding radiation again.","evidence_status":"Verified boundary sensitivity; not an uncertainty range for this project."},
    ]


def chapter8_table_rows():
    return [
      {"product_class":"Source-linked component result","permitted_use":"Quantitative claim when case role, geometry, quantity basis, and guardrails are explicit.","restriction":"A diagnostic coefficient remains diagnostic unless predictive-use criteria are met."},
      {"product_class":"Reproducible script output","permitted_use":"Figure or table regenerated directly from controlled inputs, with command and source paths recorded.","restriction":"A reproducible plot cannot create missing fields or upgrade the evidence status of its inputs."},
      {"product_class":"Synthesis scoreboard","permitted_use":"Compare development stages, expose blockers, and prioritize the next calculation or experiment.","restriction":"Cross-check every numerical row against the component package; package-level evidence controls conflicts."},
      {"product_class":"Visual field package","permitted_use":"Qualitative topology, location, and mechanism evidence.","restriction":"Do not infer an exchange coefficient, convergence claim, or predictive score from images alone."},
      {"product_class":"Blocked or negative result","permitted_use":"Reject an inadequate model form or identify the evidence needed to proceed.","restriction":"Do not convert a blocked row into a fitted coefficient or fill an unexecuted scorecard."},
    ]


def latex_table(path: Path, rows: list[dict], kind: str):
    path.parent.mkdir(parents=True, exist_ok=True)
    if kind=="ch3":
        lines=[r"\begin{table}[!htbp]",r"\centering",r"\scriptsize",r"\setlength{\tabcolsep}{3pt}",
               r"\caption{Evidence audits that materially affect the CFD-to-one-dimensional reduction. Values are used only on their stated diagnostic or methodological basis.}",
               r"\label{tab:ch3-evidence-audit-findings}",
               r"\begin{tabularx}{\textwidth}{@{}p{0.17\textwidth}p{0.29\textwidth}Xp{0.18\textwidth}@{}}",r"\toprule",
               r"Audit result & Quantitative evidence & Consequence for the reduced model & Status \\",r"\midrule"]
        for r in rows:
            lines.append(f"{r['audit_result']} & {r['quantitative_evidence']} & {r['modeling_consequence']} & {r['evidence_status']}" + r" \\")
        lines += [r"\bottomrule",r"\end{tabularx}",r"\end{table}"]
    else:
        lines=[r"\begin{table}[!htbp]",r"\centering",r"\small",r"\setlength{\tabcolsep}{4pt}",
               r"\caption{Evidence-product hierarchy used in the model assessment. The hierarchy prevents a synthesis artifact or visual product from overruling its source-level evidence.}",
               r"\label{tab:ch8-evidence-product-hierarchy}",
               r"\begin{tabularx}{\textwidth}{@{}p{0.20\textwidth}XX@{}}",r"\toprule",
               r"Evidence product & Permitted analytical use & Required restriction \\",r"\midrule"]
        for r in rows:
            lines.append(f"{r['product_class']} & {r['permitted_use']} & {r['restriction']}" + r" \\")
        lines += [r"\bottomrule",r"\end{tabularx}",r"\end{table}"]
    path.write_text("\n".join(lines)+"\n",encoding="utf-8")


def main():
    parser=argparse.ArgumentParser(); parser.add_argument("--check",action="store_true")
    args=parser.parse_args()
    REPORTS.mkdir(exist_ok=True); TABLE_DATA.mkdir(parents=True,exist_ok=True); TABLE_GEN.mkdir(parents=True,exist_ok=True)
    inv=top_level_inventory(); cred=credibility_rows(); checks=scoreboard_checks(); incorporation=incorporation_rows(); ch3=chapter3_table_rows(); ch8=chapter8_table_rows()
    write_csv(REPORTS/"2026-07-24_pass9_evidence_inventory.csv",inv,["evidence_family","file_count","size_bytes","extensions"])
    write_csv(REPORTS/"2026-07-24_pass9_evidence_credibility_matrix.csv",cred,["evidence_product","credibility","permitted_claim","limitation","thesis_action"])
    write_csv(REPORTS/"2026-07-24_pass9_scoreboard_consistency_audit.csv",checks,["check_id","artifact","result","controlling_interpretation","thesis_use","details"])
    write_csv(REPORTS/"2026-07-24_pass9_evidence_incorporation_matrix.csv",incorporation,["evidence_id","product","credibility","status_before","decision","thesis_location","claim_or_use","restriction"])
    write_csv(TABLE_DATA/"ch03_evidence_audit_findings.csv",ch3,["audit_result","quantitative_evidence","modeling_consequence","evidence_status"])
    write_csv(TABLE_DATA/"ch08_evidence_product_hierarchy.csv",ch8,["product_class","permitted_use","restriction"])
    latex_table(TABLE_GEN/"ch03_evidence_audit_findings.tex",ch3,"ch3")
    latex_table(TABLE_GEN/"ch08_evidence_product_hierarchy.tex",ch8,"ch8")
    failures=[r for r in checks if r["result"] not in {"pass","scope_exclusion","conflict"}]
    print(f"Evidence families: {len(inv)}")
    print(f"Credibility classes: {len(cred)}")
    print(f"Scoreboard checks: {len(checks)} (documented conflicts/exclusions are intentional)")
    print(f"Evidence dispositions: {len(incorporation)}")
    print(f"Unexpected failures: {len(failures)}")
    if failures: raise SystemExit(1)

if __name__=="__main__": main()
