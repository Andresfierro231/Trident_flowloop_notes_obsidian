#!/usr/bin/env python3
"""Combine the equal-population Salt2 +/-5% and Salt2/Salt4 +/-10% grades."""

import csv
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OLD = ROOT / "evidence/predictive_model_score_release_2026_07_28/holdout_candidate_scorecard.csv"
NEW = ROOT / "evidence/salt24_test_grading_2026_08_04/model_aggregate_scorecard_pm10.csv"
OUT = ROOT / "evidence/salt24_test_grading_2026_08_04/combined_six_case_scorecard.csv"


def rows(path):
    with path.open(newline="") as handle:
        return {row["publication_id"]: row for row in csv.DictReader(handle)}


old, new = rows(OLD), rows(NEW)
fields = ["publication_id", "case_count", "tp_rmse_K", "tw_rmse_K",
          "balanced_tp_tw_rmse_K", "cfd_mdot_mape_pct"]
with OUT.open("w", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=fields)
    writer.writeheader()
    for model in old:
        a, b = old[model], new[model]
        tp = math.sqrt((float(a["tp_rmse_K"])**2 + 2*float(b["tp_rmse_K"])**2)/3)
        tw = math.sqrt((float(a["tw_rmse_K"])**2 + 2*float(b["tw_rmse_K"])**2)/3)
        writer.writerow({
            "publication_id": model,
            "case_count": 6,
            "tp_rmse_K": f"{tp:.12f}",
            "tw_rmse_K": f"{tw:.12f}",
            "balanced_tp_tw_rmse_K": f"{math.sqrt((tp*tp+tw*tw)/2):.12f}",
            "cfd_mdot_mape_pct": f"{(float(a['cfd_mdot_mape_pct'])+2*float(b['cfd_mdot_mape_pct']))/3:.12f}",
        })
