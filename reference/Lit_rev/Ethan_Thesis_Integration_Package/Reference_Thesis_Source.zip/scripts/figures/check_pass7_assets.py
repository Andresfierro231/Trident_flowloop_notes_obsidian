#!/usr/bin/env python3
"""Validate generated figure assets used by the active dissertation."""
from __future__ import annotations

import csv
import hashlib
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
COMMENT_RE = re.compile(r"(?m)(?<!\\)%.*$")
INCLUDE_RE = re.compile(r"\\(?:input|include)\{([^}]+)\}")
GRAPHICS_RE = re.compile(r"\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def resolve_tex(token: str) -> Path:
    path = ROOT / token
    return path if path.suffix else path.with_suffix(".tex")


def active_tex() -> list[Path]:
    seen: set[Path] = set()
    ordered: list[Path] = []

    def walk(path: Path) -> None:
        path = path.resolve()
        if path in seen or not path.is_file():
            return
        seen.add(path)
        ordered.append(path)
        text = COMMENT_RE.sub("", path.read_text(encoding="utf-8", errors="replace"))
        for token in INCLUDE_RE.findall(text):
            walk(resolve_tex(token))

    walk(ROOT / "masterthesis.tex")
    return ordered


def main() -> int:
    issues: list[str] = []
    checks: list[dict[str, str]] = []
    files = active_tex()
    graphics: set[str] = set()
    for path in files:
        text = COMMENT_RE.sub("", path.read_text(encoding="utf-8", errors="replace"))
        graphics.update(GRAPHICS_RE.findall(text))
    manifest_path = ROOT / "figures/data/figure_manifest.csv"
    rows: list[dict[str, str]] = []
    if not manifest_path.is_file():
        issues.append("missing figure manifest")
    else:
        with manifest_path.open(newline="", encoding="utf-8") as handle:
            rows = list(csv.DictReader(handle))
    by_output: dict[str, list[dict[str, str]]] = {}
    for row in rows:
        by_output.setdefault(row["output_path"], []).append(row)
    # File-type grouping removes the former `figures/generated/` namespace.
    # Identify pass-7 outputs from the pass-7 manifest itself so unrelated
    # retained PDFs and PNGs are not incorrectly claimed by this checker.
    generated = sorted(token for token in graphics if token in by_output)

    for token in generated:
        output = ROOT / token
        if not output.is_file():
            issues.append(f"missing active figure output: {token}")
            continue
        matching = by_output.get(token, [])
        if not matching:
            issues.append(f"active generated figure absent from manifest: {token}")
            continue
        actual = sha256(output)
        if any(row["output_sha256"] != actual for row in matching):
            issues.append(f"active figure output hash mismatch: {token}")
        for row in matching:
            source = ROOT / row["source_path"]
            if not source.is_file():
                issues.append(f"missing figure source: {row['source_path']}")
            elif sha256(source) != row["source_sha256"]:
                issues.append(f"figure source hash mismatch: {row['source_path']}")

    checks.append({"check": "active generated figures", "status": "pass" if not issues else "fail", "detail": f"{len(generated)} active assets"})
    report = {
        "status": "pass" if not issues else "fail",
        "active_generated_figures": generated,
        "manifest_rows": len(rows),
        "checks": checks,
        "issues": issues,
    }
    (ROOT / "reports/2026-07-29_generated_asset_integrity.json").write_text(json.dumps(report, indent=2) + "\n")
    lines = [
        "# Generated-Asset Integrity Check",
        "",
        f"Status: **{report['status']}**",
        "",
        f"Active generated figures: {len(generated)}",
        f"Manifest rows: {len(rows)}",
        "",
        "## Active generated figures",
    ]
    lines += [f"- `{item}`" for item in generated] or ["- None."]
    lines += ["", "## Issues"] + ([f"- {item}" for item in issues] or ["- None."])
    (ROOT / "reports/2026-07-29_generated_asset_integrity.md").write_text("\n".join(lines) + "\n")
    print(json.dumps(report, indent=2))
    return 1 if issues else 0


if __name__ == "__main__":
    raise SystemExit(main())
