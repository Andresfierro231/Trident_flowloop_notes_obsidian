#!/usr/bin/env python3
"""Final integrity gate for the six-chapter CSEM dissertation."""
from __future__ import annotations

import csv
import hashlib
import json
import math
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
COMMENT_RE = re.compile(r"(?m)(?<!\\)%.*$")
INCLUDE_RE = re.compile(r"\\(?:input|include)\{([^}]+)\}")
GRAPHICS_RE = re.compile(r"\\includegraphics(?:\[[^]]*\])?\{([^}]+)\}")
CITE_RE = re.compile(r"\\cite[a-zA-Z*]*?(?:\[[^]]*\])?(?:\[[^]]*\])?\{([^}]+)\}")
BIB_RE = re.compile(r"@[A-Za-z]+\s*\{\s*([^,\s]+)", re.M)

ACTIVE_CHAPTERS = [
    "chapters/01_introduction",
    "chapters/02_thermal_fluids_and_reduction",
    "chapters/03_cfd_reference_and_model_targets",
    "chapters/04_reduced_model_methodology",
    "chapters/05_model_assessment_and_interpretation",
    "chapters/06_conclusions",
]
ACTIVE_APPENDICES = [
    "chapters/appendix_nomenclature",
    "chapters/appendix_air_properties",
    "chapters/appendix_segment_atlas",
]
OLD_SOURCE = [
    "chapters/00_motivation.tex",
    "chapters/02_background_literature.tex",
    "chapters/03_physical_system_and_evidence.tex",
    "chapters/04_cfd_to_1d_reduction.tex",
    "chapters/05_coupled_fluid_walls_model.tex",
    "chapters/06_closure_admission_uncertainty.tex",
    "chapters/07_reduced_cfd_evidence.tex",
    "chapters/08_predictive_model_assessment.tex",
    "chapters/09_implications_conclusions_future_work.tex",
    "chapters/04_model_development_and_assessment.tex",
    "chapters/05_conclusions.tex",
    "draft_coordination",
]


def strip_comments(text: str) -> str:
    return COMMENT_RE.sub("", text)


def resolve_tex(token: str) -> Path:
    p = ROOT / token
    return p if p.suffix else p.with_suffix(".tex")


def active_tex() -> list[Path]:
    seen: set[Path] = set()
    order: list[Path] = []

    def walk(p: Path) -> None:
        p = p.resolve()
        if p in seen:
            return
        seen.add(p)
        if not p.is_file():
            return
        order.append(p)
        for token in INCLUDE_RE.findall(strip_comments(p.read_text(encoding="utf-8", errors="replace"))):
            walk(resolve_tex(token))

    walk(ROOT / "masterthesis.tex")
    return order


def tree_digest(p: Path) -> tuple[str, int, int]:
    h = hashlib.sha256()
    count = total = 0
    for f in sorted(x for x in p.rglob("*") if x.is_file()):
        rel = f.relative_to(p).as_posix()
        data = f.read_bytes()
        count += 1
        total += len(data)
        h.update(rel.encode())
        h.update(b"\0")
        h.update(data)
        h.update(b"\0")
    return h.hexdigest(), count, total


def add(checks: list[dict], name: str, passed: bool, detail: str) -> None:
    checks.append({"check": name, "passed": bool(passed), "detail": detail})


def main() -> int:
    checks: list[dict] = []
    files = active_tex()
    rel = [str(p.relative_to(ROOT)) for p in files]
    missing_includes = []
    for p in files:
        for token in INCLUDE_RE.findall(strip_comments(p.read_text(encoding="utf-8", errors="replace"))):
            q = resolve_tex(token)
            if not q.is_file():
                missing_includes.append(f"{p.relative_to(ROOT)} -> {token}")
    add(checks, "all included TeX files exist", not missing_includes, "; ".join(missing_includes) or f"{len(files)} active TeX files")

    body = strip_comments((ROOT / "structural/body.tex").read_text(encoding="utf-8"))
    includes = INCLUDE_RE.findall(body)
    active_count = len(ACTIVE_CHAPTERS) + len(ACTIVE_APPENDICES)
    add(checks, "exact six-chapter order",
        includes[:len(ACTIVE_CHAPTERS)] == ACTIVE_CHAPTERS
        and includes[len(ACTIVE_CHAPTERS):active_count] == ACTIVE_APPENDICES,
        " -> ".join(includes[:active_count]))

    absent = [p for p in OLD_SOURCE if not (ROOT / p).exists()]
    add(checks, "superseded source and coordination tree removed", len(absent) == len(OLD_SOURCE),
        f"{len(absent)}/{len(OLD_SOURCE)} absent")

    raw = "\n".join(p.read_text(encoding="utf-8", errors="replace") for p in files)
    active = strip_comments(raw)
    normalized_active = re.sub(r"\s+", " ", active)
    placeholders = sorted(set(re.findall(r"\b(?:TODO|TBD|PLACEHOLDER|TO BE CONFIRMED|XXX)\b", active, flags=re.I)))
    unresolved_fixmes = re.findall(r"\bFIXME\b(?!\(2\))", raw, flags=re.I)
    add(checks, "no unresolved class-0/class-1 comments or active placeholders",
        not placeholders and not unresolved_fixmes,
        f"active={placeholders}; non-class-2 FIXME hits={len(unresolved_fixmes)}")

    prohibited = re.findall(
        r"\b(?:lane(?:s)?|runtime[- ]legal(?:ity)?|scoreboard(?:s)?|super[- ]?converg\w*)\b",
        active,
        flags=re.I,
    )
    add(checks, "reader-facing terminology guardrail", not prohibited, f"hits={len(prohibited)}")

    metadata = (ROOT / "structural/metadata.tex").read_text(encoding="utf-8")
    add(checks, "August 2026 graduation metadata", "\\graduationmonth{August}" in metadata and "\\graduationyear{2026}" in metadata,
        "August 2026")
    add(checks, "confirmed supervisor and co-supervisor metadata", "\\supervisor[Dr. Kevin Clarno]{Dr. Robert Moser}" in metadata,
        "Dr. Kevin Clarno / Dr. Robert Moser")
    add(checks, "confirmed mentor metadata", "\\committeemembers{Dr. Cole Gentry, Mentor}" in metadata,
        "Dr. Cole Gentry, Mentor")

    required_phrases = {
        "CFD and 1D test-section diameters distinguished": ["0.835~in", "20.94~mm", "survey-grade"],
        "physical and empirical insulation distinguished": ["1.40-in", "global 0.08"],
        "six-case test-data grade labeled": ["six-case test", "previously exposed"],
        "P1 development/test scores present": ["9.280", "12.853"],
        "P2-CFD development/test mass-flow scores present": ["3.538", "2.835"],
        "localized progression and P-model junction semantics present": [
            "Eleven model settings",
            "use neither $G_J$ nor $G_B$",
            "4.957",
            "0.967",
            "5.989",
            "1.310",
        ],
        "mass-flow figure includes localized forms and complete six-case test": [
            "three global-compensation candidates",
            "two full-insulation localized settings",
            "Salt2 $\\pm5\\%Q$ and $\\pm10\\%Q$",
            "Salt4 $\\pm10\\%Q$",
        ],
        "localized heat-path magnitude and spatial audit present": [
            "Where the localized model removes heat",
            "151.5--214.1-W",
            "57.4--60.8\\%",
            "36.1\\%",
        ],
        "normalized heat-path share figure included": [
            "figures/pdf/localized_heat_path_comparison.pdf",
            "Each CFD and localized stack is normalized independently",
            "bar heights do not compare absolute heat input or total removal",
        ],
        "conditional TW score disclosed": ["TW4--TW6", "14.551", "14.381", "14.848", "14.699"],
        "quantity-specific uncertainty boundary disclosed": [
            "does not support formal GCI",
            "diagnostic medium--fine",
            "different physical times",
            "mesh-specific masks",
            "No matched three-grid",
        ],
        "model-development status disclosed": ["independently", "validated", "target-informed calibration"],
        "partial-external affine status disclosed": ["partial-external", "repeated-exposure"],
        "test-section source present": ["37~W"],
    }
    for name, phrases in required_phrases.items():
        add(
            checks,
            name,
            all(re.sub(r"\s+", " ", phrase) in normalized_active for phrase in phrases),
            "; ".join(phrases),
        )

    graphics = []
    missing_graphics = []
    for p in files:
        for token in GRAPHICS_RE.findall(strip_comments(p.read_text(encoding="utf-8", errors="replace"))):
            graphics.append(token)
            q = ROOT / token
            if not q.is_file():
                missing_graphics.append(token)
    add(checks, "all active figures exist", not missing_graphics, f"{len(graphics)} figures; missing={missing_graphics}")

    citations: set[str] = set()
    for group in CITE_RE.findall(active):
        citations.update(k.strip() for k in group.split(",") if k.strip())
    bib_sources = [ROOT / "references.bib", ROOT / "bibliography/litrev_references_bibtex.bib"]
    bib_counts: dict[str, int] = {}
    for p in bib_sources:
        for key in BIB_RE.findall(p.read_text(encoding="utf-8", errors="replace")):
            bib_counts[key] = bib_counts.get(key, 0) + 1
    missing_cites = sorted(citations - set(bib_counts))
    dup_bib = sorted(k for k, n in bib_counts.items() if n > 1)
    add(checks, "all citation keys resolve", not missing_cites, f"{len(citations)} cited keys; missing={missing_cites}")
    add(checks, "no duplicate keys across active bibliography resources", not dup_bib, f"duplicates={dup_bib}")

    log = ROOT / "masterthesis.log"
    log_text = log.read_text(encoding="utf-8", errors="replace") if log.is_file() else ""
    fatal_patterns = [
        r"^!", r"undefined citations", r"undefined references", r"Citation .* undefined",
        r"Reference .* undefined", r"Overfull \\hbox", r"Overfull \\vbox",
        r"Float too large", r"Too many unprocessed floats", r"LaTeX Warning:", r"Package .* Warning:",
    ]
    log_hits = []
    for line in log_text.splitlines():
        if any(re.search(pat, line, flags=re.I) for pat in fatal_patterns):
            log_hits.append(line)
    add(checks, "clean final LaTeX log", log.is_file() and not log_hits, f"hits={len(log_hits)}" + (f": {log_hits[:5]}" if log_hits else ""))

    pdf = ROOT / "masterthesis.pdf"
    pdf_info = {}
    if pdf.is_file():
        proc = subprocess.run(["pdfinfo", str(pdf)], text=True, capture_output=True)
        for line in proc.stdout.splitlines():
            if ":" in line:
                k, v = line.split(":", 1)
                pdf_info[k.strip()] = v.strip()
    pages = int(pdf_info.get("Pages", "0") or 0)
    # The two-state and localized-conjugate methods/results integrations grow
    # the six-chapter dissertation beyond the former 110-page scaffold ceiling.
    add(checks, "final PDF exists and page count is plausible", pdf.is_file() and 70 <= pages <= 145,
        f"pages={pages}; bytes={pdf.stat().st_size if pdf.is_file() else 0}")
    add(checks, "PDF metadata title and author", "Test-Data Grading" in pdf_info.get("Title", "") and "Andres Nicolas Fierro Lopez" in pdf_info.get("Author", ""),
        f"title={pdf_info.get('Title','')}; author={pdf_info.get('Author','')}")

    manifest = ROOT / "evidence/RETAINED_EVIDENCE_MANIFEST.csv"
    manifest_rows = list(csv.DictReader(manifest.open(encoding="utf-8"))) if manifest.is_file() else []
    expected = {r["package"] for r in manifest_rows}
    actual = {p.name for p in (ROOT / "evidence").iterdir() if p.is_dir()}
    add(checks, "curated evidence-manifest packages exist", expected <= actual,
        f"curated={len(expected)} actual={len(actual)} unmanifested_support={len(actual-expected)} missing={sorted(expected-actual)}")
    digest_errors = []
    for r in manifest_rows:
        d, n, b = tree_digest(ROOT / "evidence" / r["package"])
        if d != r["sha256_tree"] or n != int(r["file_count"]) or b != int(r["bytes"]):
            digest_errors.append(r["package"])
    add(checks, "retained evidence digests and counts match", not digest_errors, f"mismatches={digest_errors}")

    score_root = ROOT / "evidence/predictive_model_score_release_2026_07_28"
    score_inputs = {
        "nominal": score_root / "all_model_training_sensor_scores.csv",
        "retrospective": score_root / "holdout_sensor_scores.csv",
    }
    candidate_ids = {"P1": "P1_shah_global008", "P2-CFD": "P2_f6_major080"}
    expected_sensitivity = {
        ("nominal", "P1"): 14.550618334073352,
        ("retrospective", "P1"): 14.380602119386623,
        ("nominal", "P2-CFD"): 14.84756707778812,
        ("retrospective", "P2-CFD"): 14.699139191202292,
    }
    sensitivity_errors = []
    for split, path in score_inputs.items():
        rows = list(csv.DictReader(path.open(encoding="utf-8"))) if path.is_file() else []
        for publication_id, candidate_id in candidate_ids.items():
            selected = [r for r in rows if r.get("candidate_id") == candidate_id]
            tp = [r for r in selected if r.get("sensor_kind") == "TP"]
            tw = [r for r in selected if r.get("sensor_kind") == "TW" and r.get("sensor") != "TW10"]
            if not tp or not tw:
                sensitivity_errors.append(f"{split}:{publication_id}:missing")
                continue
            rmse_tp = math.sqrt(sum(float(r["signed_error_K"]) ** 2 for r in tp) / len(tp))
            rmse_tw = math.sqrt(sum(float(r["signed_error_K"]) ** 2 for r in tw) / len(tw))
            balanced = math.sqrt((rmse_tp ** 2 + rmse_tw ** 2) / 2)
            if abs(balanced - expected_sensitivity[(split, publication_id)]) > 5e-10:
                sensitivity_errors.append(f"{split}:{publication_id}:{balanced:.12f}")
    add(checks, "TW4--TW6 restored-score sensitivity reproduces from sensor rows",
        not sensitivity_errors, f"errors={sensitivity_errors}")

    closure = ROOT / "reports/FINAL_FIXME_CLOSURE_REGISTER.csv"
    closure_rows = list(csv.DictReader(closure.open(encoding="utf-8"))) if closure.is_file() else []
    stale_current_paths = [
        r for r in closure_rows
        if any(f"chapters/{n:02d}" in (r.get("final_resolution_file") or "") for n in range(6, 10))
    ]
    add(checks, "review closure register points to active resolution paths", len(closure_rows) == 73
        and all(r.get("final_status") == "resolved" for r in closure_rows)
        and not stale_current_paths,
        f"rows={len(closure_rows)} resolved={sum(r.get('final_status') == 'resolved' for r in closure_rows)} stale_current_paths={len(stale_current_paths)}")

    repo_bytes = sum(p.stat().st_size for p in ROOT.rglob("*") if p.is_file() and ".git" not in p.parts)
    add(checks, "repository size recorded without cleanup claim", repo_bytes > 0, f"bytes={repo_bytes}")

    failed = [c for c in checks if not c["passed"]]
    result = {
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "status": "PASS" if not failed else "FAIL",
        "checks_passed": len(checks) - len(failed),
        "checks_total": len(checks),
        "active_tex_files": rel,
        "pdf_info": pdf_info,
        "checks": checks,
    }
    reports = ROOT / "reports"
    reports.mkdir(exist_ok=True)
    (reports / "final_qa.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    lines = [
        "# Final Dissertation QA", "",
        f"Generated: {result['generated_utc']}",
        f"Status: **{result['status']}** ({result['checks_passed']}/{result['checks_total']} checks passed)", "",
    ]
    for c in checks:
        lines.append(f"- {'PASS' if c['passed'] else 'FAIL'} — **{c['check']}**: {c['detail']}")
    (reports / "final_qa.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0 if not failed else 1


if __name__ == "__main__":
    sys.exit(main())
