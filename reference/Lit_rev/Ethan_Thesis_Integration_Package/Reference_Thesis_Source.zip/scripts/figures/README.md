# Dissertation build and QA scripts

- `build_thesis.sh`: regenerate the BibTeX-compatible LitRev resource and compile with Latexmk/BibTeX.
- `compile_and_qa.sh`: run the complete build and final QA gate.
- `final_qa.py`: verify active structure, metadata, terminology, scientific guardrails, citations, figures, log cleanliness, PDF, and retained-evidence integrity.
- `check_figure_layout.py`: verify that every retained figure asset is grouped
  by extension under `figures/pdf`, `figures/png`, `figures/svg`,
  `figures/tex`, or `figures/data`.
- `build_pressure_leverage_figure.py`: build the publication pressure-group
  leverage figure, including the loop-region key, from the retained V2
  sensitivity CSV.
- `clean_build_artifacts.sh`: remove LaTeX intermediate files.
- `prepare_bibtex_litrev.py` and `update_bibliography_register.py`: maintain the declared bibliography workflow.
