#!/usr/bin/env python3
"""Generate nominal CFD-versus-1D TP temperature profiles by elevation."""

from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

import matplotlib.pyplot as plt


CASE_ORDER = ("salt_1", "salt_2", "salt_3", "salt_4")
SENSOR_ORDER = ("TP1", "TP2", "TP3", "TP4", "TP5", "TP6")
CFD_STYLE = {"color": "#222222", "marker": "o", "linestyle": "-"}
MODEL_STYLE = {"color": "#0072B2", "marker": "s", "linestyle": "--"}


def parse_args() -> argparse.Namespace:
    repo_root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(
        description="Plot nominal CFD and localized 1D TP temperature versus height."
    )
    parser.add_argument(
        "--input",
        type=Path,
        default=repo_root
        / "evidence"
        / "tp_temperature_elevation_2026_08_10"
        / "tp_nominal_cfd_localized_1d.csv",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=repo_root / "figures",
    )
    return parser.parse_args()


def read_rows(path: Path) -> dict[str, list[dict[str, str]]]:
    with path.open(newline="", encoding="utf-8") as stream:
        rows = list(csv.DictReader(stream))

    expected = {(case, sensor) for case in CASE_ORDER for sensor in SENSOR_ORDER}
    observed = {(row["case_id"], row["sensor"]) for row in rows}
    if len(rows) != 24 or observed != expected:
        missing = sorted(expected - observed)
        extra = sorted(observed - expected)
        raise ValueError(
            f"Expected one row for 4 cases x 6 TP sensors; "
            f"rows={len(rows)}, missing={missing}, extra={extra}"
        )

    grouped: dict[str, list[dict[str, str]]] = {}
    for case in CASE_ORDER:
        case_rows = [row for row in rows if row["case_id"] == case]
        by_sensor = {row["sensor"]: row for row in case_rows}
        ordered = [by_sensor[sensor] for sensor in SENSOR_ORDER]
        for row in ordered:
            predicted = float(row["model_temperature_K"])
            target = float(row["cfd_temperature_K"])
            residual = float(row["signed_error_K"])
            if not math.isclose(predicted - target, residual, abs_tol=1.0e-10):
                raise ValueError(f"Residual mismatch in {case} {row['sensor']}")
        grouped[case] = ordered
    return grouped


def case_rmse(rows: list[dict[str, str]]) -> float:
    return math.sqrt(
        sum(float(row["signed_error_K"]) ** 2 for row in rows) / len(rows)
    )


def draw_case(ax: plt.Axes, rows: list[dict[str, str]], *, annotate: bool) -> None:
    height = [float(row["height_above_tp2_m"]) for row in rows]
    cfd = [float(row["cfd_temperature_K"]) for row in rows]
    model = [float(row["model_temperature_K"]) for row in rows]

    closed_height = height + [height[0]]
    ax.plot(
        cfd + [cfd[0]],
        closed_height,
        linewidth=1.8,
        markersize=5.2,
        label="CFD",
        **CFD_STYLE,
    )
    ax.plot(
        model + [model[0]],
        closed_height,
        linewidth=1.8,
        markersize=5.0,
        label="Localized 1D",
        **MODEL_STYLE,
    )
    if annotate:
        for row, cfd_x, model_x, y in zip(rows, cfd, model, height):
            ax.annotate(
                row["sensor"],
                (cfd_x, y),
                xytext=(5, 3),
                textcoords="offset points",
                fontsize=7.5,
                color=CFD_STYLE["color"],
            )
            ax.annotate(
                row["sensor"],
                (model_x, y),
                xytext=(5, -10),
                textcoords="offset points",
                fontsize=7.5,
                color=MODEL_STYLE["color"],
            )

    ax.set_ylim(-0.06, 1.29)
    ax.grid(axis="y", color="#D9D9D9", linewidth=0.7)
    ax.tick_params(direction="out")


def save_all_formats(fig: plt.Figure, base: Path) -> None:
    figure_root = base.parent
    pdf_path = figure_root / "pdf" / base.with_suffix(".pdf").name
    svg_path = figure_root / "svg" / base.with_suffix(".svg").name
    png_path = figure_root / "png" / base.with_suffix(".png").name
    for path in (pdf_path, svg_path, png_path):
        path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(pdf_path, bbox_inches="tight")
    fig.savefig(svg_path, bbox_inches="tight")
    svg_text = svg_path.read_text(encoding="utf-8")
    svg_path.write_text(
        "\n".join(line.rstrip() for line in svg_text.splitlines()) + "\n",
        encoding="utf-8",
    )
    fig.savefig(png_path, dpi=300, bbox_inches="tight")


def make_individual(case: str, rows: list[dict[str, str]], output_dir: Path) -> None:
    fig, ax = plt.subplots(figsize=(5.2, 5.2))
    draw_case(ax, rows, annotate=True)
    ax.set_title(f"{rows[0]['case_label']} (TP RMSE = {case_rmse(rows):.2f} K)")
    ax.set_xlabel("Temperature (K)")
    ax.set_ylabel("Height above TP2 (m)")
    ax.legend(frameon=False, loc="best")
    fig.tight_layout()
    save_all_formats(
        fig, output_dir / f"csem_tp_temperature_vs_elevation_nominal_{case}"
    )
    plt.close(fig)


def make_combined(grouped: dict[str, list[dict[str, str]]], output_dir: Path) -> None:
    fig, axes = plt.subplots(2, 2, figsize=(8.0, 7.3), sharey=True)
    for ax, case in zip(axes.flat, CASE_ORDER):
        rows = grouped[case]
        draw_case(ax, rows, annotate=True)
        ax.set_title(f"{rows[0]['case_label']} (RMSE = {case_rmse(rows):.2f} K)")
        ax.set_xlabel("Temperature (K)")

    axes[0, 0].set_ylabel("Height above TP2 (m)")
    axes[1, 0].set_ylabel("Height above TP2 (m)")
    handles, labels = axes[0, 0].get_legend_handles_labels()
    fig.suptitle("Nominal TP temperatures: CFD vs localized 1D", y=0.995)
    fig.legend(
        handles,
        labels,
        loc="upper center",
        bbox_to_anchor=(0.5, 0.962),
        ncol=2,
        frameon=False,
    )
    fig.tight_layout(rect=(0, 0, 1, 0.90))
    save_all_formats(
        fig, output_dir / "csem_tp_temperature_vs_elevation_nominal_all"
    )
    plt.close(fig)


def main() -> None:
    args = parse_args()
    grouped = read_rows(args.input)
    for case in CASE_ORDER:
        make_individual(case, grouped[case], args.output_dir)
    make_combined(grouped, args.output_dir)
    print(f"Validated 24 rows from {args.input}")
    print(f"Generated 15 files under type folders in {args.output_dir}")


if __name__ == "__main__":
    main()
