#!/usr/bin/env python3
"""Build the thesis pressure-group leverage figure from retained CSV evidence."""

from __future__ import annotations

import argparse
import csv
import os
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_INPUT = (
    REPO_ROOT
    / "evidence/pressure_demand_ledger_v2_2026_08_03"
    / "model_pressure_sensitivity_priority.csv"
)
DEFAULT_OUTPUT = REPO_ROOT / "figures/pdf/two_state_pressure_leverage.pdf"

ORDER = (
    "minor_losses",
    "upcomer",
    "cooler_assembly",
    "right_downcomer",
    "heated_incline",
    "top_horizontals",
    "bottom_horizontals",
)
LABELS = {
    "minor_losses": "Aggregate local losses",
    "upcomer": "Rising section (upcomer)",
    "cooler_assembly": "Cooled upper path",
    "right_downcomer": "Right return leg",
    "heated_incline": "Heated lower path",
    "top_horizontals": "Top 1-in connectors",
    "bottom_horizontals": "Bottom 1-in connectors",
}
COLORS = {
    "minor_losses": "#5F6368",
    "upcomer": "#4477AA",
    "cooler_assembly": "#228833",
    "right_downcomer": "#CCBB44",
    "heated_incline": "#EE6677",
    "top_horizontals": "#AA3377",
    "bottom_horizontals": "#66AFC7",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=DEFAULT_INPUT)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    return parser.parse_args()


def read_values(path: Path) -> dict[str, float]:
    with path.open(newline="", encoding="utf-8") as handle:
        rows = list(csv.DictReader(handle))
    values = {
        row["pressure_group"]: float(
            row["mean_mdot_change_pct_for_10pct_loss_increase"]
        )
        for row in rows
    }
    missing = [group for group in ORDER if group not in values]
    if missing:
        raise ValueError(f"missing pressure groups: {', '.join(missing)}")
    return values


def draw_loop_schematic(ax, plt) -> None:
    """Draw a topology-faithful, not-to-scale map of the perturbed groups."""
    # Counterclockwise path: up the left side, across the cooled decline,
    # down the right return, then through the heated incline to TP3.
    upcomer = ((0.0, 0.9), (0.0, 4.0))
    top_inlet = ((0.0, 4.0), (0.45, 4.0))
    cooled = ((0.45, 4.0), (2.95, 2.95))
    top_exit = ((2.95, 2.95), (3.4, 2.95))
    downcomer = ((3.4, 2.95), (3.4, 0.0))
    bottom_inlet = ((3.4, 0.0), (2.95, 0.0))
    heated = ((2.95, 0.0), (0.45, 0.9))
    bottom_exit = ((0.45, 0.9), (0.0, 0.9))

    segments = (
        (upcomer, "upcomer", 7.0),
        (top_inlet, "top_horizontals", 6.0),
        (cooled, "cooler_assembly", 7.0),
        (top_exit, "top_horizontals", 6.0),
        (downcomer, "right_downcomer", 7.0),
        (bottom_inlet, "bottom_horizontals", 6.0),
        (heated, "heated_incline", 7.0),
        (bottom_exit, "bottom_horizontals", 6.0),
    )
    for ((x0, y0), (x1, y1)), group, width in segments:
        ax.plot(
            (x0, x1),
            (y0, y1),
            color=COLORS[group],
            linewidth=width,
            solid_capstyle="round",
            zorder=2,
        )

    # Minor-loss dots indicate that this group is distributed rather than one
    # contiguous region: bends plus the test-section diameter changes.
    bend_points = (
        (0.0, 0.9),
        (0.0, 4.0),
        (0.45, 4.0),
        (2.95, 2.95),
        (3.4, 2.95),
        (3.4, 0.0),
        (2.95, 0.0),
        (0.45, 0.9),
    )
    test_section_points = ((0.0, 2.05), (0.0, 2.80))
    for x, y in bend_points + test_section_points:
        ax.scatter(
            x,
            y,
            s=24,
            color=COLORS["minor_losses"],
            edgecolor="white",
            linewidth=0.55,
            zorder=4,
        )

    ax.annotate(
        "",
        xy=(0.0, 3.55),
        xytext=(0.0, 3.05),
        arrowprops={"arrowstyle": "-|>", "color": "white", "lw": 1.4},
        zorder=5,
    )
    ax.text(-0.13, 2.43, "Rising section\n(upcomer)", ha="right", va="center")
    ax.text(1.68, 3.20, "Cooled upper path", ha="center", va="top", rotation=-23)
    ax.text(3.55, 1.48, "Right return\nleg", ha="left", va="center")
    ax.text(1.70, 0.19, "Heated lower path", ha="center", va="bottom", rotation=17)
    ax.text(0.18, 4.28, "top connectors", color=COLORS["top_horizontals"], ha="left")
    ax.text(1.70, -0.40, "bottom connectors", color=COLORS["bottom_horizontals"], ha="center")
    ax.scatter([], [], s=28, color=COLORS["minor_losses"], label="local-loss locations (scaled together)")
    ax.legend(loc="lower center", bbox_to_anchor=(0.5, -0.18), frameon=False, fontsize=8)
    ax.text(0.02, 0.03, "Schematic—not to scale", transform=ax.transAxes, va="bottom", fontsize=8, color="#555555")
    ax.set_xlim(-1.30, 4.20)
    ax.set_ylim(-0.65, 4.65)
    ax.set_aspect("equal")
    ax.axis("off")
    ax.set_title("(a) Model pressure groups", loc="left", fontweight="bold", pad=8)


def build_figure(input_path: Path, output_path: Path) -> None:
    cache = Path("/tmp/csem_pressure_leverage_matplotlib")
    cache.mkdir(parents=True, exist_ok=True)
    os.environ.setdefault("MPLCONFIGDIR", str(cache))

    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np

    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.size": 9.5,
            "axes.titlesize": 10.5,
            "axes.labelsize": 9.5,
            "xtick.labelsize": 8.5,
            "ytick.labelsize": 8.8,
            "pdf.fonttype": 42,
        }
    )

    values_by_group = read_values(input_path)
    values = [values_by_group[group] for group in ORDER]
    labels = [LABELS[group] for group in ORDER]
    colors = [COLORS[group] for group in ORDER]

    fig = plt.figure(figsize=(11.2, 5.35), facecolor="white")
    grid = fig.add_gridspec(1, 2, width_ratios=(0.95, 1.35), wspace=0.28)
    schematic_ax = fig.add_subplot(grid[0, 0])
    response_ax = fig.add_subplot(grid[0, 1])
    draw_loop_schematic(schematic_ax, plt)

    y = np.arange(len(ORDER))
    response_ax.barh(y, values, height=0.64, color=colors, edgecolor="white", linewidth=0.7)
    response_ax.set_yticks(y, labels)
    response_ax.invert_yaxis()
    response_ax.axvline(0.0, color="#222222", linewidth=0.9)
    response_ax.set_xlim(-4.75, 0.25)
    response_ax.set_xlabel(r"Mean change in $\dot{m}$ after +10% group pressure demand (%)")
    response_ax.set_title("(b) Coupled circulation response", loc="left", fontweight="bold", pad=8)
    response_ax.grid(axis="x", color="#D7DCE2", linewidth=0.7)
    response_ax.set_axisbelow(True)
    response_ax.spines[["top", "right", "left"]].set_visible(False)
    response_ax.tick_params(axis="y", length=0, pad=7)
    for y_pos, value in zip(y, values):
        response_ax.text(
            value - 0.07,
            y_pos,
            f"{value:.2f}%",
            ha="right",
            va="center",
            color="#1F2933",
            fontweight="bold",
            fontsize=8.5,
        )
    response_ax.text(
        0.01,
        0.02,
        "Negative response = lower circulation; Salt1–Salt4 mean",
        transform=response_ax.transAxes,
        ha="left",
        va="bottom",
        fontsize=8,
        color="#555555",
    )

    fig.suptitle(
        "Where additional modeled pressure demand most changes circulation",
        x=0.50,
        y=0.985,
        fontsize=13,
        fontweight="bold",
    )
    fig.text(
        0.5,
        0.012,
        "Each bar scales one declared loss group by 10%, then re-solves both coupled roots. "
        "Groups are nonadditive sensitivities—not shares of total pressure demand.",
        ha="center",
        va="bottom",
        fontsize=8.2,
        color="#40464D",
    )
    fig.subplots_adjust(left=0.055, right=0.985, top=0.89, bottom=0.14)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(
        output_path,
        bbox_inches="tight",
        metadata={
            "Title": "Regional pressure-group leverage in the reduced model",
            "Author": "Andres Nicolas Fierro Lopez",
            "Subject": "Coupled Salt1-Salt4 circulation sensitivity",
        },
    )
    plt.close(fig)


def main() -> int:
    args = parse_args()
    build_figure(args.input.resolve(), args.output.resolve())
    print(args.output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
