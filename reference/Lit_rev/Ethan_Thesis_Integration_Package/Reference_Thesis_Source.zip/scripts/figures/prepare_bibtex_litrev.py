#!/usr/bin/env python3
"""Create a BibTeX-compatible resource from the read-only LitRev snapshot.

The controlling LitRev bibliography uses BibLaTeX-oriented fields. The
CSEM dissertation intentionally retains Natbib/BibTeX, so this script creates a
local generated resource without modifying the LitRev project or raw snapshot.
"""
from __future__ import annotations

import argparse
import re
from collections import OrderedDict
from pathlib import Path

ENTRY_HEADER = re.compile(r"@([A-Za-z]+)\s*\{\s*([^,\s]+)\s*,", re.M)
MONTHS = {
    "01": "January", "02": "February", "03": "March", "04": "April",
    "05": "May", "06": "June", "07": "July", "08": "August",
    "09": "September", "10": "October", "11": "November", "12": "December",
}
TYPE_MAP = {
    "article": "article",
    "techreport": "techreport",
    "collection": "book",
    "book": "book",
    "online": "misc",
    "misc": "misc",
    "manual": "manual",
}
FIELD_ORDER = [
    "author", "editor", "title", "journal", "booktitle", "institution",
    "school", "organization", "publisher", "address", "edition", "type",
    "number", "year", "month", "volume", "pages", "howpublished", "note",
    "doi", "url", "isbn",
]
DROP_FIELDS = {"ids", "keywords", "date", "journaltitle", "location", "eid"}


def find_entries(text: str):
    """Yield (entry_type, key, content) using balanced braces."""
    pos = 0
    while True:
        match = ENTRY_HEADER.search(text, pos)
        if not match:
            break
        brace_start = text.find("{", match.start())
        depth = 0
        escaped = False
        end = None
        for idx in range(brace_start, len(text)):
            char = text[idx]
            if escaped:
                escaped = False
                continue
            if char == "\\":
                escaped = True
                continue
            if char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
                if depth == 0:
                    end = idx
                    break
        if end is None:
            raise ValueError(f"Unbalanced entry beginning at character {match.start()}")
        content_start = match.end()
        yield match.group(1).lower(), match.group(2), text[content_start:end]
        pos = end + 1


def split_top_level(content: str):
    fields = []
    start = 0
    depth = 0
    quote = False
    escaped = False
    for idx, char in enumerate(content):
        if escaped:
            escaped = False
            continue
        if char == "\\":
            escaped = True
            continue
        if char == '"' and depth == 0:
            quote = not quote
        elif not quote:
            if char == "{":
                depth += 1
            elif char == "}":
                depth -= 1
            elif char == "," and depth == 0:
                fields.append(content[start:idx])
                start = idx + 1
    tail = content[start:]
    if tail.strip():
        fields.append(tail)
    return fields


def parse_fields(content: str):
    result: OrderedDict[str, str] = OrderedDict()
    for token in split_top_level(content):
        token = token.strip()
        if not token or "=" not in token:
            continue
        name, value = token.split("=", 1)
        result[name.strip().lower()] = value.strip()
    return result


def unwrap(value: str) -> str:
    value = value.strip()
    if len(value) >= 2 and ((value[0] == "{" and value[-1] == "}") or (value[0] == '"' and value[-1] == '"')):
        return value[1:-1].strip()
    return value


def braced(value: str) -> str:
    return "{" + value + "}"


def normalize_value(value: str) -> str:
    # The raw snapshot contains one malformed tab escape where \textdegree was
    # interpreted before reaching the file. Repair only the generated resource.
    value = value.replace("\textdegree", r"$^\circ$")
    value = value.replace(r"\textdegree", r"$^\circ$")
    return value


def convert(entry_type: str, fields: OrderedDict[str, str]):
    converted: OrderedDict[str, str] = OrderedDict((k, normalize_value(v)) for k, v in fields.items())

    if "journal" not in converted and "journaltitle" in converted:
        converted["journal"] = converted["journaltitle"]
    if "address" not in converted and "location" in converted:
        converted["address"] = converted["location"]
    if "pages" not in converted and "eid" in converted:
        converted["pages"] = converted["eid"]

    date_value = unwrap(converted.get("date", ""))
    date_match = re.fullmatch(r"(\d{4})(?:-(\d{2}))?(?:-(\d{2}))?", date_value)
    if date_match:
        if "year" not in converted:
            converted["year"] = braced(date_match.group(1))
        if date_match.group(2) and "month" not in converted:
            converted["month"] = braced(MONTHS.get(date_match.group(2), date_match.group(2)))

    mapped_type = TYPE_MAP.get(entry_type, "misc")
    if entry_type == "online" and "howpublished" not in converted:
        converted["howpublished"] = braced("Online resource")
    if entry_type not in TYPE_MAP:
        note = unwrap(converted.get("note", ""))
        extra = f"Original BibLaTeX entry type: {entry_type}."
        converted["note"] = braced((note + " " + extra).strip())

    for field in DROP_FIELDS:
        converted.pop(field, None)

    # Keep standard BibTeX fields first and any remaining compatible metadata
    # afterward. Unknown non-BibLaTeX fields are harmless to BibTeX styles.
    ordered: OrderedDict[str, str] = OrderedDict()
    for field in FIELD_ORDER:
        if field in converted:
            ordered[field] = converted[field]
    for field, value in converted.items():
        if field not in ordered:
            ordered[field] = value
    return mapped_type, ordered


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--exclude-bib",
        type=Path,
        action="append",
        default=[],
        help="BibTeX resource whose keys should be omitted from the generated LitRev derivative.",
    )
    args = parser.parse_args()

    source = args.source.resolve()
    output = args.output.resolve()
    if not source.is_file():
        raise SystemExit(f"LitRev snapshot not found: {source}")

    text = source.read_text(encoding="utf-8", errors="replace")

    excluded_keys: set[str] = set()
    for excluded_path in args.exclude_bib:
        excluded_path = excluded_path.resolve()
        if not excluded_path.is_file():
            raise SystemExit(f"Exclusion bibliography not found: {excluded_path}")
        excluded_text = excluded_path.read_text(encoding="utf-8", errors="replace")
        excluded_keys.update(key for _entry_type, key, _content in find_entries(excluded_text))

    rendered = [
        "% GENERATED FILE - DO NOT EDIT DIRECTLY.",
        "% Source: bibliography/litrev_references.bib (read-only LitRev snapshot).",
        "% Purpose: BibTeX/plainnat compatibility for the CSEM dissertation.",
        "",
    ]
    count = 0
    skipped = 0
    for entry_type, key, content in find_entries(text):
        if key in excluded_keys:
            skipped += 1
            continue
        fields = parse_fields(content)
        mapped_type, fields = convert(entry_type, fields)
        rendered.append(f"@{mapped_type}{{{key},")
        for field, value in fields.items():
            rendered.append(f"  {field} = {value},")
        rendered.append("}")
        rendered.append("")
        count += 1

    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("\n".join(rendered).rstrip() + "\n", encoding="utf-8")
    print(
        f"Generated {count} BibTeX-compatible entries: {output} "
        f"(skipped {skipped} keys already maintained in dissertation-local resources)"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
