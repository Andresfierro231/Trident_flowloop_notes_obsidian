#!/usr/bin/env python3
"""Generate the thesis scientific-triage comparison figures.

The script reads the frozen nominal predictions, the associated CFD setup
inputs, the complete six-case test grade, and the no-refit Salt1--Salt4 CFD
mass-flow target refresh.  The mass-flow figure separates the earlier
global-compensation candidates from the newer full-insulation localized forms:

* P1: temperature-leading compensated forward model;
* P2-0.60 (source ID P2-exp): fixed low-resistance comparator;
* P2-CFD: CFD-mdot-target-informed calibrated comparator.
* Localized-0.60: full-insulation temperature-oriented setting; and
* Localized-CFD: the same thermal form with target-informed resistance.

No fitting, filtering by residual size, or source-table mutation occurs here.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MultipleLocator


ROOT = Path(__file__).resolve().parents[2]
RELEASE = ROOT / "evidence" / "predictive_model_score_release_2026_07_28"
REFRESH = ROOT / "evidence" / "cfd_mdot_salt1_4_refresh_2026_08_03"
SIX_CASE = ROOT / "evidence" / "salt24_test_grading_2026_08_04"
MDOT_REFRESH = ROOT / "evidence" / "mdot_trend_refresh_2026_08_10"
CFD_INPUTS = ROOT / "evidence" / "cfd_run_matrix_2026_07_28" / "canonical_cfd_setup_inputs.csv"
FIGURE_ROOT = ROOT / "figures"
OUTPUT_DIRS = {
    "pdf": FIGURE_ROOT / "pdf",
    "png": FIGURE_ROOT / "png",
    "svg": FIGURE_ROOT / "svg",
}
VALIDATION_DIR = FIGURE_ROOT / "data"

SOURCES = {
    "training_sensor_scores": RELEASE / "all_model_training_sensor_scores.csv",
    "training_case_scores": RELEASE / "all_model_training_case_scores.csv",
    "training_scorecard": RELEASE / "all_model_training_scorecard.csv",
    "holdout_sensor_scores": RELEASE / "holdout_sensor_scores.csv",
    "holdout_case_scores": RELEASE / "holdout_case_scorecard.csv",
    "holdout_scorecard": RELEASE / "holdout_candidate_scorecard.csv",
    "holdout_runtime_results": RELEASE / "holdout_runtime_results.csv",
    "cfd_setup_inputs": CFD_INPUTS,
    "nominal_cfd_mdot_targets": REFRESH / "canonical_cfd_mdot_targets.csv",
    "nominal_mdot_scores": REFRESH / "predictive_model_scorecard_salt1_4.csv",
    "localized_nominal_scores": REFRESH / "localized_model_scorecard_salt1_4.csv",
    "pm10_case_scores": SIX_CASE / "model_case_scorecard_pm10.csv",
    "six_case_scores": SIX_CASE / "combined_six_case_scorecard.csv",
    "localized_mdot_cases": MDOT_REFRESH / "localized_mdot_cases.csv",
    "localized_six_case_scorecard": MDOT_REFRESH / "localized_six_case_scorecard.csv",
    "parity_sensor_scores": MDOT_REFRESH / "temperature_parity_six_case_sensor_scores.csv",
}

MODEL_IDS = {
    "P1": "P1_shah_global008",
    "P2-exp": "P2_f6_global008",
    "P2-CFD": "P2_f6_major080",
}
LOCALIZED_IDS = {
    "Localized-0.60": "experimental_mdot",
    "Localized-CFD": "cfd_mdot_comparator",
}
LOCALIZED_SCORE_IDS = {
    "Localized-0.60": "localized_exp_mdot",
    "Localized-CFD": "localized_cfd_mdot",
}
LOCALIZED_CANDIDATE_IDS = {
    "Localized-0.60": "RW_outer_bridge2p500_r0p600__rad__coupled",
    "Localized-CFD": "RW_outer_bridge2p500_r1p100__rad__coupled",
}
PARITY_MODELS = ("P1", "P2-CFD", "Localized-CFD")
COLORS = {
    "P1": "#0072B2",
    "P2-exp": "#CC79A7",
    "P2-CFD": "#009E73",
    "Localized-0.60": "#9467BD",
    "Localized-CFD": "#E69F00",
}
MARKERS = {
    "P1": "o",
    "P2-exp": "v",
    "P2-CFD": "s",
    "Localized-0.60": "P",
    "Localized-CFD": "^",
}
DISPLAY_LABELS = {"P1": "P1", "P2-exp": "P2-0.60", "P2-CFD": "P2-CFD"}
CASE_TO_SETUP = {
    "salt_1": "salt1_nominal",
    "salt_2": "salt2_jin_nominal",
    "salt_3": "salt3_jin_nominal",
    "salt_4": "salt4_nominal",
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def is_true(value: str) -> bool:
    return value.strip().lower() == "true"


def rmse(rows: Iterable[dict[str, str]]) -> float:
    errors = [float(row["prediction_K"]) - float(row["cfd_target_K"]) for row in rows]
    if not errors:
        raise ValueError("cannot calculate RMSE for an empty population")
    return math.sqrt(sum(error * error for error in errors) / len(errors))


def mape(predicted: Iterable[float], target: Iterable[float]) -> float:
    pairs = list(zip(predicted, target))
    if not pairs:
        raise ValueError("cannot calculate MAPE for an empty population")
    return 100.0 * sum(abs((p - t) / t) for p, t in pairs) / len(pairs)


def linear_fit(x_values: list[float], y_values: list[float]) -> tuple[float, float]:
    """Return ordinary-least-squares slope and intercept for one series."""
    if len(x_values) != len(y_values) or len(x_values) < 2:
        raise ValueError("linear fit requires at least two paired values")
    x_mean = sum(x_values) / len(x_values)
    y_mean = sum(y_values) / len(y_values)
    denominator = sum((value - x_mean) ** 2 for value in x_values)
    if denominator == 0.0:
        raise ValueError("linear fit requires nonconstant x values")
    slope = sum(
        (x_value - x_mean) * (y_value - y_mean)
        for x_value, y_value in zip(x_values, y_values)
    ) / denominator
    return slope, y_mean - slope * x_mean


def configure_style() -> None:
    plt.rcParams.update(
        {
            "font.family": "serif",
            "font.serif": ["DejaVu Serif"],
            "font.size": 9.0,
            "axes.titlesize": 10.0,
            "axes.labelsize": 9.5,
            "axes.linewidth": 0.8,
            "xtick.labelsize": 8.5,
            "ytick.labelsize": 8.5,
            "legend.fontsize": 8.2,
            "figure.dpi": 150,
            "savefig.dpi": 300,
            "savefig.bbox": "tight",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "svg.fonttype": "none",
            "svg.hashsalt": "csem-scientific-triage-2026-07-29",
        }
    )


def save_figure(fig: plt.Figure, stem: str) -> list[str]:
    outputs: list[str] = []
    for suffix in ("pdf", "svg", "png"):
        path = OUTPUT_DIRS[suffix] / f"{stem}.{suffix}"
        path.parent.mkdir(parents=True, exist_ok=True)
        metadata = {
            "pdf": {
                "Creator": "generate_scientific_triage_figures.py",
                "CreationDate": None,
                "ModDate": None,
            },
            "svg": {"Creator": "generate_scientific_triage_figures.py", "Date": None},
            "png": {"Software": "generate_scientific_triage_figures.py"},
        }[suffix]
        fig.savefig(path, facecolor="white", metadata=metadata)
        if suffix == "svg":
            lines = path.read_text(encoding="utf-8").splitlines()
            path.write_text(
                "\n".join(line.rstrip() for line in lines) + "\n",
                encoding="utf-8",
            )
        outputs.append(path.relative_to(ROOT).as_posix())
    return outputs


def build_temperature_parity(
    parity_rows: list[dict[str, str]],
    *,
    write_outputs: bool = True,
) -> tuple[list[str], dict[str, Any]]:
    panels = [
        ("training", "TP", "(a) Training data: fluid temperature"),
        ("training", "TW", "(b) Training data: wall temperature"),
        ("test", "TP", "(c) Test data: fluid temperature"),
        ("test", "TW", "(d) Test data: wall temperature"),
    ]
    fig, axes = plt.subplots(2, 2, figsize=(7.15, 6.65), constrained_layout=True)
    validation: dict[str, Any] = {}

    for ax, (split, sensor_kind, title) in zip(axes.flat, panels):
        selected_by_model: dict[str, list[dict[str, str]]] = {}
        all_values: list[float] = []
        for publication_id in PARITY_MODELS:
            selected = [
                row
                for row in parity_rows
                if row["publication_id"] == publication_id
                and row["split"] == split
                and row["sensor_kind"] == sensor_kind
                and is_true(row["included_in_thesis_aggregate"])
            ]
            selected_by_model[publication_id] = selected
            all_values.extend(float(row["prediction_K"]) for row in selected)
            all_values.extend(float(row["cfd_target_K"]) for row in selected)

        lower = math.floor((min(all_values) - 8.0) / 10.0) * 10.0
        upper = math.ceil((max(all_values) + 8.0) / 10.0) * 10.0
        identity = [lower, upper]
        ax.fill_between(
            identity,
            [lower - 10.0, upper - 10.0],
            [lower + 10.0, upper + 10.0],
            color="#D9D9D9",
            alpha=0.55,
            linewidth=0,
            label=r"$\pm 10$ K",
            zorder=0,
        )
        ax.plot(identity, identity, color="#3A3A3A", linewidth=1.1, zorder=1)

        annotation_lines: list[str] = []
        for publication_id in PARITY_MODELS:
            selected = selected_by_model[publication_id]
            x = [float(row["cfd_target_K"]) for row in selected]
            y = [float(row["prediction_K"]) for row in selected]
            score = rmse(selected)
            ax.scatter(
                x,
                y,
                s=29,
                marker=MARKERS[publication_id],
                facecolor=COLORS[publication_id],
                edgecolor="white",
                linewidth=0.45,
                alpha=0.9,
                label=publication_id,
                zorder=3,
            )
            annotation_lines.append(f"{publication_id}: {score:.2f} K (n={len(selected)})")
            validation_key = f"{split}_{sensor_kind}_{publication_id}"
            validation[validation_key] = {
                "publication_id": publication_id,
                "row_count": len(selected),
                "rmse_K_recomputed": score,
            }

        ax.text(
            0.035,
            0.965,
            "RMSE\n" + "\n".join(annotation_lines),
            transform=ax.transAxes,
            va="top",
            ha="left",
            fontsize=7.1,
            bbox={"boxstyle": "round,pad=0.25", "facecolor": "white", "edgecolor": "#B0B0B0", "alpha": 0.9},
        )
        ax.set_xlim(lower, upper)
        ax.set_ylim(lower, upper)
        ax.set_aspect("equal", adjustable="box")
        ax.set_title(title, loc="left", fontweight="semibold")
        ax.set_xlabel("CFD reference temperature (K)")
        ax.set_ylabel("1D model temperature (K)")
        ax.xaxis.set_major_locator(MultipleLocator(20))
        ax.yaxis.set_major_locator(MultipleLocator(20))
        ax.grid(True, color="#E6E6E6", linewidth=0.6)

    legend_handles = [
        Line2D([], [], marker=MARKERS[model], linestyle="none", color=COLORS[model],
               markeredgecolor="white", markersize=6.5, label=model)
        for model in PARITY_MODELS
    ]
    legend_handles.extend(
        [
            Line2D([], [], color="#3A3A3A", linewidth=1.1, label="Identity"),
            Line2D([], [], color="#D9D9D9", linewidth=8, alpha=0.7, label=r"$\pm 10$ K band"),
        ]
    )
    fig.legend(
        handles=legend_handles,
        loc="upper center",
        ncol=5,
        frameon=False,
        bbox_to_anchor=(0.5, 1.045),
    )
    fig.suptitle("Temperature agreement against the CFD computational reference", y=1.075, fontsize=11.0)
    if write_outputs:
        outputs = save_figure(fig, "csem_scientific_triage_temperature_parity")
    else:
        outputs = [
            (OUTPUT_DIRS[suffix] / f"csem_scientific_triage_temperature_parity.{suffix}")
            .relative_to(ROOT)
            .as_posix()
            for suffix in ("pdf", "svg", "png")
        ]
    plt.close(fig)
    return outputs, validation


def build_mdot_trend_two_panel_reference(
    training_case_rows: list[dict[str, str]],
    holdout_case_rows: list[dict[str, str]],
    holdout_runtime_rows: list[dict[str, str]],
    setup_rows: list[dict[str, str]],
    nominal_target_rows: list[dict[str, str]],
    pm10_case_rows: list[dict[str, str]],
    localized_rows: list[dict[str, str]],
) -> tuple[list[str], dict[str, Any]]:
    setup_power = {row["case_key"]: float(row["heater_power_W"]) for row in setup_rows}
    nominal_power = {case: setup_power[setup] for case, setup in CASE_TO_SETUP.items()}
    fig, axes = plt.subplots(
        1, 2, figsize=(7.15, 4.35), sharex=True, sharey=True, constrained_layout=True
    )
    validation: dict[str, Any] = {"nominal_models": {}, "test_models": {}}

    training_by_model: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in training_case_rows:
        training_by_model[row["candidate_id"]].append(row)
    runtime_lookup = {
        (row["candidate_id"], row["case_id"]): row for row in holdout_runtime_rows
    }
    test_power = {
        row["case_id"]: float(
            runtime_lookup[(MODEL_IDS["P1"], row["case_id"])]["heater_power_setup_W"]
        )
        for row in holdout_case_rows
        if row["candidate_id"] == MODEL_IDS["P1"]
    }
    test_power.update(
        {
            row["case_id"]: float(row["heater_power_W"])
            for row in localized_rows
            if row["split"] == "test"
        }
    )

    nominal_targets = {
        row["case_id"]: float(row["cfd_mdot_target_magnitude_kg_s"])
        for row in nominal_target_rows
    }
    test_targets = {
        row["case_id"]: float(row["cfd_mdot_target_kg_s"])
        for row in holdout_case_rows
        if row["candidate_id"] == MODEL_IDS["P1"]
    }
    test_targets.update(
        {
            row["case_id"]: float(row["cfd_mdot_target_kg_s"])
            for row in pm10_case_rows
            if row["candidate_id"] == MODEL_IDS["P1"]
        }
    )

    def plot_model(
        ax: plt.Axes,
        publication_id: str,
        nominal: list[dict[str, str]],
        test: list[dict[str, str]],
        candidate_id: str,
    ) -> None:
        nominal = sorted(nominal, key=lambda row: nominal_power[row["case_id"]])
        test = sorted(test, key=lambda row: test_power[row["case_id"]])
        x_nominal = [nominal_power[row["case_id"]] for row in nominal]
        y_nominal = [float(row["predicted_mdot_kg_s"]) for row in nominal]
        x_test = [test_power[row["case_id"]] for row in test]
        y_test = [float(row["predicted_mdot_kg_s"]) for row in test]
        label = DISPLAY_LABELS.get(publication_id, publication_id)
        ax.plot(
            x_nominal,
            y_nominal,
            color=COLORS[publication_id],
            marker=MARKERS[publication_id],
            markeredgecolor="white",
            markeredgewidth=0.5,
            linewidth=1.35,
            markersize=5.8,
            label=label,
            zorder=3,
        )
        ax.scatter(
            x_test,
            y_test,
            marker=MARKERS[publication_id],
            s=38,
            facecolor="white",
            edgecolor=COLORS[publication_id],
            linewidth=1.1,
            zorder=4,
        )
        validation["nominal_models"][publication_id] = {
            "candidate_id": candidate_id,
            "case_ids": [row["case_id"] for row in nominal],
            "row_count": len(nominal),
            "heater_power_W": x_nominal,
            "mdot_kg_s": y_nominal,
            "cfd_target_kg_s": [nominal_targets[row["case_id"]] for row in nominal],
        }
        validation["test_models"][publication_id] = {
            "candidate_id": candidate_id,
            "case_ids": [row["case_id"] for row in test],
            "row_count": len(test),
            "heater_power_W": x_test,
            "mdot_kg_s": y_test,
            "cfd_target_kg_s": [test_targets[row["case_id"]] for row in test],
        }

    for publication_id, model_id in MODEL_IDS.items():
        test = [row for row in holdout_case_rows if row["candidate_id"] == model_id]
        test.extend(row for row in pm10_case_rows if row["candidate_id"] == model_id)
        plot_model(axes[0], publication_id, training_by_model[model_id], test, model_id)

    for publication_id, objective_label in LOCALIZED_IDS.items():
        nominal = [
            row
            for row in localized_rows
            if row["publication_id"] == publication_id and row["split"] == "development"
        ]
        test = [
            row
            for row in localized_rows
            if row["publication_id"] == publication_id and row["split"] == "test"
        ]
        plot_model(
            axes[1],
            publication_id,
            nominal,
            test,
            LOCALIZED_CANDIDATE_IDS[publication_id],
        )

    reference_rows = training_by_model[MODEL_IDS["P1"]]
    cfd_nominal = sorted(reference_rows, key=lambda row: nominal_power[row["case_id"]])
    cfd_nominal_x = [nominal_power[row["case_id"]] for row in cfd_nominal]
    cfd_nominal_y = [nominal_targets[row["case_id"]] for row in cfd_nominal]
    test_cases = sorted(test_targets, key=test_power.__getitem__)
    cfd_test_x = [test_power[case] for case in test_cases]
    cfd_test_y = [test_targets[case] for case in test_cases]
    for ax in axes:
        ax.scatter(
            cfd_nominal_x,
            cfd_nominal_y,
            marker="D",
            s=38,
            facecolor="#222222",
            edgecolor="white",
            linewidth=0.5,
            label="CFD reference",
            zorder=5,
        )
        ax.scatter(
            cfd_test_x,
            cfd_test_y,
            marker="D",
            s=39,
            facecolor="white",
            edgecolor="#222222",
            linewidth=1.1,
            zorder=5,
        )
        ax.set_xlim(225, 380)
        ax.set_ylim(0.0105, 0.0270)
        ax.xaxis.set_major_locator(MultipleLocator(40))
        ax.yaxis.set_major_locator(MultipleLocator(0.002))
        ax.grid(True, color="#E6E6E6", linewidth=0.65)
        ax.ticklabel_format(axis="y", style="plain", useOffset=False)

    axes[0].set_title("(a) Global compensation", loc="left", fontweight="semibold")
    axes[1].set_title("(b) Full-insulation localized", loc="left", fontweight="semibold")
    axes[0].set_ylabel(r"Mass-flow rate, $\dot{m}$ (kg s$^{-1}$)")
    for ax in axes:
        ax.set_xlabel("Heater setup power (W)")
    fig.suptitle("Mass-flow response across development and six-case testing", fontsize=11.0)

    partition_legend = [
        Line2D([], [], marker="o", linestyle="none", markerfacecolor="#666666",
               markeredgecolor="white", markersize=6, label="Development case"),
        Line2D([], [], marker="o", linestyle="none", markerfacecolor="white",
               markeredgecolor="#666666", markersize=6, label="Test-data case"),
    ]
    left_series_legend = axes[0].legend(
        loc="upper left", frameon=True, framealpha=0.94, fontsize=7.4
    )
    axes[0].add_artist(left_series_legend)
    axes[1].legend(loc="upper left", frameon=True, framealpha=0.94, fontsize=7.4)
    axes[0].legend(
        handles=partition_legend,
        loc="lower right",
        frameon=True,
        framealpha=0.94,
        fontsize=7.4,
    )

    validation["references"] = {
        "cfd_nominal": {
            "row_count": len(cfd_nominal_y),
            "heater_power_W": cfd_nominal_x,
            "mdot_kg_s": cfd_nominal_y,
        },
        "cfd_test": {
            "case_ids": test_cases,
            "row_count": len(cfd_test_y),
            "heater_power_W": cfd_test_x,
            "mdot_kg_s": cfd_test_y,
        },
    }
    outputs = save_figure(fig, "csem_scientific_triage_mdot_trend_two_panel_reference")
    plt.close(fig)
    return outputs, validation


def build_mdot_trend(
    training_case_rows: list[dict[str, str]],
    holdout_case_rows: list[dict[str, str]],
    holdout_runtime_rows: list[dict[str, str]],
    setup_rows: list[dict[str, str]],
    nominal_target_rows: list[dict[str, str]],
    pm10_case_rows: list[dict[str, str]],
    localized_rows: list[dict[str, str]],
    *,
    slope_overlay: bool = True,
    output_stem: str = "csem_scientific_triage_mdot_trend",
) -> tuple[list[str], dict[str, Any]]:
    """Overlay every mass-flow series, optionally using all-case linear fits."""
    setup_power = {row["case_key"]: float(row["heater_power_W"]) for row in setup_rows}
    nominal_power = {case: setup_power[setup] for case, setup in CASE_TO_SETUP.items()}
    runtime_lookup = {
        (row["candidate_id"], row["case_id"]): row for row in holdout_runtime_rows
    }
    test_power = {
        row["case_id"]: float(
            runtime_lookup[(MODEL_IDS["P1"], row["case_id"])]["heater_power_setup_W"]
        )
        for row in holdout_case_rows
        if row["candidate_id"] == MODEL_IDS["P1"]
    }
    test_power.update(
        {
            row["case_id"]: float(row["heater_power_W"])
            for row in localized_rows
            if row["split"] == "test"
        }
    )
    nominal_targets = {
        row["case_id"]: float(row["cfd_mdot_target_magnitude_kg_s"])
        for row in nominal_target_rows
    }
    test_targets = {
        row["case_id"]: float(row["cfd_mdot_target_kg_s"])
        for row in holdout_case_rows
        if row["candidate_id"] == MODEL_IDS["P1"]
    }
    test_targets.update(
        {
            row["case_id"]: float(row["cfd_mdot_target_kg_s"])
            for row in pm10_case_rows
            if row["candidate_id"] == MODEL_IDS["P1"]
        }
    )
    training_by_model: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in training_case_rows:
        training_by_model[row["candidate_id"]].append(row)

    fig, ax = plt.subplots(figsize=(8.2, 5.25), constrained_layout=True)
    validation: dict[str, Any] = {"nominal_models": {}, "test_models": {}}

    def plot_model(
        publication_id: str,
        nominal: list[dict[str, str]],
        test: list[dict[str, str]],
        candidate_id: str,
    ) -> None:
        nominal = sorted(nominal, key=lambda row: nominal_power[row["case_id"]])
        test = sorted(test, key=lambda row: test_power[row["case_id"]])
        x_nominal = [nominal_power[row["case_id"]] for row in nominal]
        y_nominal = [float(row["predicted_mdot_kg_s"]) for row in nominal]
        x_test = [test_power[row["case_id"]] for row in test]
        y_test = [float(row["predicted_mdot_kg_s"]) for row in test]
        label = DISPLAY_LABELS.get(publication_id, publication_id)
        x_all = x_nominal + x_test
        y_all = y_nominal + y_test
        highlighted = slope_overlay and publication_id == "Localized-CFD"
        fit: dict[str, Any] = {}
        if slope_overlay:
            slope, intercept = linear_fit(x_all, y_all)
            fit_x = [min(x_all), max(x_all)]
            ax.plot(
                fit_x,
                [slope * x + intercept for x in fit_x],
                color=COLORS[publication_id],
                linewidth=2.1 if highlighted else 1.45,
                label=f"{label}: {slope * 1.0e5:.2f}",
                zorder=6 if highlighted else 2,
            )
            fit = {
                "fit_row_count": len(x_all),
                "slope_kg_s_per_W": slope,
                "intercept_kg_s": intercept,
                "fit_power_range_W": fit_x,
            }
        else:
            ax.plot(
                x_nominal,
                y_nominal,
                color=COLORS[publication_id],
                linewidth=1.3,
                label=label,
                zorder=3,
            )
        ax.scatter(
            x_nominal,
            y_nominal,
            marker=MARKERS[publication_id],
            s=90 if highlighted else 39,
            facecolor=COLORS[publication_id],
            edgecolor="#704700" if highlighted else "white",
            linewidth=1.25 if highlighted else 0.5,
            zorder=8 if highlighted else 4,
        )
        ax.scatter(
            x_test,
            y_test,
            marker=MARKERS[publication_id],
            s=94 if highlighted else 40,
            facecolor="white",
            edgecolor=COLORS[publication_id],
            linewidth=2.0 if highlighted else 1.1,
            zorder=8 if highlighted else 4,
        )
        validation["nominal_models"][publication_id] = {
            "candidate_id": candidate_id,
            "case_ids": [row["case_id"] for row in nominal],
            "row_count": len(nominal),
            "heater_power_W": x_nominal,
            "mdot_kg_s": y_nominal,
            "cfd_target_kg_s": [nominal_targets[row["case_id"]] for row in nominal],
            **fit,
        }
        validation["test_models"][publication_id] = {
            "candidate_id": candidate_id,
            "case_ids": [row["case_id"] for row in test],
            "row_count": len(test),
            "heater_power_W": x_test,
            "mdot_kg_s": y_test,
            "cfd_target_kg_s": [test_targets[row["case_id"]] for row in test],
        }

    for publication_id, model_id in MODEL_IDS.items():
        test = [row for row in holdout_case_rows if row["candidate_id"] == model_id]
        test.extend(row for row in pm10_case_rows if row["candidate_id"] == model_id)
        plot_model(publication_id, training_by_model[model_id], test, model_id)

    for publication_id in LOCALIZED_IDS:
        nominal = [
            row
            for row in localized_rows
            if row["publication_id"] == publication_id and row["split"] == "development"
        ]
        test = [
            row
            for row in localized_rows
            if row["publication_id"] == publication_id and row["split"] == "test"
        ]
        plot_model(publication_id, nominal, test, LOCALIZED_CANDIDATE_IDS[publication_id])

    reference_rows = training_by_model[MODEL_IDS["P1"]]
    nominal_cases = [
        row["case_id"]
        for row in sorted(reference_rows, key=lambda row: nominal_power[row["case_id"]])
    ]
    test_cases = sorted(test_targets, key=test_power.__getitem__)
    cfd_x_nominal = [nominal_power[case] for case in nominal_cases]
    cfd_y_nominal = [nominal_targets[case] for case in nominal_cases]
    cfd_x_test = [test_power[case] for case in test_cases]
    cfd_y_test = [test_targets[case] for case in test_cases]
    cfd_fit: dict[str, Any] = {}
    if slope_overlay:
        cfd_x = cfd_x_nominal + cfd_x_test
        cfd_y = cfd_y_nominal + cfd_y_test
        cfd_slope, cfd_intercept = linear_fit(cfd_x, cfd_y)
        cfd_fit_x = [min(cfd_x), max(cfd_x)]
        ax.plot(
            cfd_fit_x,
            [cfd_slope * x + cfd_intercept for x in cfd_fit_x],
            color="#222222",
            linewidth=1.25,
            linestyle="--",
            label=f"CFD reference: {cfd_slope * 1.0e5:.2f}",
            zorder=2,
        )
        cfd_fit = {
            "fit_row_count": len(cfd_x),
            "slope_kg_s_per_W": cfd_slope,
            "intercept_kg_s": cfd_intercept,
            "fit_power_range_W": cfd_fit_x,
        }
    ax.scatter(
        cfd_x_nominal,
        cfd_y_nominal,
        marker="D",
        s=39,
        facecolor="#222222",
        edgecolor="white",
        linewidth=0.5,
        label=None if slope_overlay else "CFD reference",
        zorder=10,
    )
    ax.scatter(
        cfd_x_test,
        cfd_y_test,
        marker="D",
        s=40,
        facecolor="white",
        edgecolor="#222222",
        linewidth=1.1,
        zorder=10,
    )
    ax.set_xlim(225, 380)
    ax.set_ylim(0.0105, 0.0270)
    ax.xaxis.set_major_locator(MultipleLocator(20))
    ax.yaxis.set_major_locator(MultipleLocator(0.002))
    ax.grid(True, color="#E6E6E6", linewidth=0.65)
    ax.ticklabel_format(axis="y", style="plain", useOffset=False)
    ax.set_xlabel("Heater setup power (W)")
    ax.set_ylabel(r"Mass-flow rate, $\dot{m}$ (kg s$^{-1}$)")
    ax.set_title(
        "All-case mass-flow trends through the maximum heater power"
        if slope_overlay
        else "Mass-flow response across training and six-case test data",
        fontweight="semibold",
    )
    series_legend = ax.legend(
        title=(r"Series: slope ($10^{-5}$ kg s$^{-1}$ W$^{-1}$)" if slope_overlay else None),
        loc="upper left",
        ncol=2,
        frameon=True,
        framealpha=0.94,
        fontsize=7.5 if slope_overlay else 7.8,
        title_fontsize=7.5 if slope_overlay else None,
    )
    ax.add_artist(series_legend)
    ax.legend(
        handles=[
            Line2D([], [], marker="o", linestyle="none", markerfacecolor="#666666",
                   markeredgecolor="white", markersize=6, label="Training data"),
            Line2D([], [], marker="o", linestyle="none", markerfacecolor="white",
                   markeredgecolor="#666666", markersize=6, label="Test data"),
            *(
                [Line2D([], [], color="#666666", linewidth=1.3,
                        label="10-case least-squares fit")]
                if slope_overlay
                else []
            ),
        ],
        loc="lower right",
        frameon=True,
        framealpha=0.94,
        fontsize=7.8,
    )
    validation["references"] = {
        "cfd_nominal": {
            "row_count": len(nominal_cases),
            "heater_power_W": cfd_x_nominal,
            "mdot_kg_s": cfd_y_nominal,
            **cfd_fit,
        },
        "cfd_test": {
            "case_ids": test_cases,
            "row_count": len(test_cases),
            "heater_power_W": cfd_x_test,
            "mdot_kg_s": cfd_y_test,
        },
    }
    outputs = save_figure(fig, output_stem)
    plt.close(fig)
    return outputs, validation


def lookup(rows: list[dict[str, str]], key: str, value: str) -> dict[str, str]:
    matches = [row for row in rows if row[key] == value]
    if len(matches) != 1:
        raise ValueError(f"expected one row with {key}={value!r}; found {len(matches)}")
    return matches[0]


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--mdot-only",
        action="store_true",
        help="regenerate the mass-flow figure while retaining existing temperature-parity assets",
    )
    args = parser.parse_args()
    configure_style()
    for output_dir in OUTPUT_DIRS.values():
        output_dir.mkdir(parents=True, exist_ok=True)
    VALIDATION_DIR.mkdir(parents=True, exist_ok=True)
    data = {name: read_csv(path) for name, path in SOURCES.items()}

    parity_outputs, parity_validation = build_temperature_parity(
        data["parity_sensor_scores"],
        write_outputs=not args.mdot_only,
    )
    reference_outputs, _ = build_mdot_trend_two_panel_reference(
        data["training_case_scores"],
        data["holdout_case_scores"],
        data["holdout_runtime_results"],
        data["cfd_setup_inputs"],
        data["nominal_cfd_mdot_targets"],
        data["pm10_case_scores"],
        data["localized_mdot_cases"],
    )
    one_axis_reference_outputs, _ = build_mdot_trend(
        data["training_case_scores"],
        data["holdout_case_scores"],
        data["holdout_runtime_results"],
        data["cfd_setup_inputs"],
        data["nominal_cfd_mdot_targets"],
        data["pm10_case_scores"],
        data["localized_mdot_cases"],
        slope_overlay=False,
        output_stem="csem_scientific_triage_mdot_trend_one_axis_reference",
    )
    mdot_outputs, mdot_validation = build_mdot_trend(
        data["training_case_scores"],
        data["holdout_case_scores"],
        data["holdout_runtime_results"],
        data["cfd_setup_inputs"],
        data["nominal_cfd_mdot_targets"],
        data["pm10_case_scores"],
        data["localized_mdot_cases"],
    )

    checks: list[dict[str, Any]] = []
    expected_counts = {
        ("training", "TP"): 24,
        ("training", "TW"): 28,
        ("test", "TP"): 36,
        ("test", "TW"): 42,
    }
    for split, sensor_kind in expected_counts:
        for publication_id in PARITY_MODELS:
            key = f"{split}_{sensor_kind}_{publication_id}"
            actual = parity_validation[key]["row_count"]
            expected = expected_counts[(split, sensor_kind)]
            checks.append(
                {
                    "check": f"row_count:{key}",
                    "expected": expected,
                    "actual": actual,
                    "pass": actual == expected,
                }
            )

    training_scorecard = data["training_scorecard"]
    six_case_scores = data["six_case_scores"]
    localized_nominal_scores = data["localized_nominal_scores"]
    localized_test_scores = data["localized_six_case_scorecard"]
    nominal_mdot_scorecard = data["nominal_mdot_scores"]
    nominal_targets = {
        row["case_id"]: float(row["cfd_mdot_target_magnitude_kg_s"])
        for row in data["nominal_cfd_mdot_targets"]
    }
    for split in ("training", "test"):
        for publication_id in PARITY_MODELS:
            if publication_id == "Localized-CFD":
                score_row = (
                    lookup(
                        localized_nominal_scores,
                        "candidate_id",
                        LOCALIZED_CANDIDATE_IDS[publication_id],
                    )
                    if split == "training"
                    else lookup(
                        localized_test_scores,
                        "publication_id",
                        LOCALIZED_SCORE_IDS[publication_id],
                    )
                )
            else:
                score_row = lookup(
                    training_scorecard if split == "training" else six_case_scores,
                    "publication_id",
                    publication_id,
                )
            for sensor_kind, field in (("TP", "tp_rmse_K"), ("TW", "tw_rmse_K")):
                key = f"{split}_{sensor_kind}_{publication_id}"
                actual = parity_validation[key]["rmse_K_recomputed"]
                # The nominal localized refresh retains only its combined
                # TP/TW score; its component values are still reproduced
                # directly from the frozen sensor-level parity population.
                if field not in score_row:
                    continue
                expected = float(score_row[field])
                delta = abs(actual - expected)
                parity_validation[key]["rmse_K_scorecard"] = expected
                parity_validation[key]["absolute_delta_K"] = delta
                checks.append(
                    {
                        "check": f"score_reproduction:{key}",
                        "expected": expected,
                        "actual": actual,
                        "absolute_delta": delta,
                        "tolerance": 1.0e-10,
                        "pass": delta <= 1.0e-10,
                    }
                )
            if split == "training" and publication_id == "Localized-CFD":
                tp = parity_validation[f"{split}_TP_{publication_id}"][
                    "rmse_K_recomputed"
                ]
                tw = parity_validation[f"{split}_TW_{publication_id}"][
                    "rmse_K_recomputed"
                ]
                actual = math.sqrt((tp * tp + tw * tw) / 2.0)
                expected = float(score_row["balanced_tp_tw_rmse_K"])
                delta = abs(actual - expected)
                checks.append(
                    {
                        "check": "score_reproduction:training:balanced:Localized-CFD",
                        "expected": expected,
                        "actual": actual,
                        "absolute_delta": delta,
                        "tolerance": 1.0e-10,
                        "pass": delta <= 1.0e-10,
                    }
                )

    for publication_id, model_id in MODEL_IDS.items():
        nominal_expected = float(
            lookup(nominal_mdot_scorecard, "publication_id", publication_id)[
                "cfd_mdot_mape_pct_salt1_4"
            ]
        )
        test_expected = float(
            lookup(six_case_scores, "publication_id", publication_id)[
                "cfd_mdot_mape_pct"
            ]
        )
        for split, expected, expected_count in (
            ("nominal_models", nominal_expected, 4),
            ("test_models", test_expected, 6),
        ):
            series = mdot_validation[split][publication_id]
            actual = mape(series["mdot_kg_s"], series["cfd_target_kg_s"])
            checks.extend(
                [
                    {
                        "check": f"row_count:mdot:{publication_id}:{split}",
                        "expected": expected_count,
                        "actual": series["row_count"],
                        "pass": series["row_count"] == expected_count,
                    },
                    {
                        "check": f"cfd_mdot_mape:{publication_id}:{split}",
                        "expected": expected,
                        "actual": actual,
                        "absolute_delta": abs(actual - expected),
                        "tolerance": 1.0e-10,
                        "pass": abs(actual - expected) <= 1.0e-10,
                    },
                ]
            )

    for publication_id, objective_label in LOCALIZED_IDS.items():
        nominal_expected = float(
            lookup(
                localized_nominal_scores,
                "candidate_id",
                LOCALIZED_CANDIDATE_IDS[publication_id],
            )["cfd_mdot_mape_pct_salt1_4"]
        )
        test_expected = float(
            lookup(
                localized_test_scores,
                "publication_id",
                LOCALIZED_SCORE_IDS[publication_id],
            )[
                "cfd_mdot_mape_pct"
            ]
        )
        for split, expected, expected_count in (
            ("nominal_models", nominal_expected, 4),
            ("test_models", test_expected, 6),
        ):
            series = mdot_validation[split][publication_id]
            actual = mape(series["mdot_kg_s"], series["cfd_target_kg_s"])
            checks.extend(
                [
                    {
                        "check": f"row_count:mdot:{publication_id}:{split}",
                        "expected": expected_count,
                        "actual": series["row_count"],
                        "pass": series["row_count"] == expected_count,
                    },
                    {
                        "check": f"cfd_mdot_mape:{publication_id}:{split}",
                        "expected": expected,
                        "actual": actual,
                        "absolute_delta": abs(actual - expected),
                        "tolerance": 1.0e-10,
                        "pass": abs(actual - expected) <= 1.0e-10,
                    },
                ]
            )

    for publication_id in list(MODEL_IDS) + list(LOCALIZED_IDS):
        nominal = mdot_validation["nominal_models"][publication_id]
        test = mdot_validation["test_models"][publication_id]
        expected_max = max(nominal["heater_power_W"] + test["heater_power_W"])
        checks.extend(
            [
                {
                    "check": f"slope_fit_row_count:{publication_id}",
                    "expected": 10,
                    "actual": nominal.get("fit_row_count"),
                    "pass": nominal.get("fit_row_count") == 10,
                },
                {
                    "check": f"slope_fit_max_power:{publication_id}",
                    "expected": expected_max,
                    "actual": nominal.get("fit_power_range_W", [None, None])[1],
                    "pass": nominal.get("fit_power_range_W", [None, None])[1]
                    == expected_max,
                },
            ]
        )
    cfd_nominal = mdot_validation["references"]["cfd_nominal"]
    cfd_test = mdot_validation["references"]["cfd_test"]
    cfd_expected_max = max(
        cfd_nominal["heater_power_W"] + cfd_test["heater_power_W"]
    )
    checks.extend(
        [
            {
                "check": "slope_fit_row_count:CFD reference",
                "expected": 10,
                "actual": cfd_nominal.get("fit_row_count"),
                "pass": cfd_nominal.get("fit_row_count") == 10,
            },
            {
                "check": "slope_fit_max_power:CFD reference",
                "expected": cfd_expected_max,
                "actual": cfd_nominal.get("fit_power_range_W", [None, None])[1],
                "pass": cfd_nominal.get("fit_power_range_W", [None, None])[1]
                == cfd_expected_max,
            },
        ]
    )

    outputs = (
        parity_outputs
        + mdot_outputs
        + reference_outputs
        + one_axis_reference_outputs
    )
    payload = {
        "schema_version": 1,
        "generator": "scripts/figures/generate_scientific_triage_figures.py",
        "claim_boundary": (
            "CFD is a computational reference, not experimental validation. "
            "The six test rows are repeated-exposure grading data. P2-CFD and "
            "Localized-CFD are CFD-mdot-target-informed. The nominal "
            "Salt1--Salt4 target refresh is post-solve and no-refit."
        ),
        "score_policy": "TP includes TP2; TW excludes TW4-TW6 and TW10",
        "displayed_models": {
            "temperature_parity": list(PARITY_MODELS),
            "mass_flow_trend": list(MODEL_IDS) + list(LOCALIZED_IDS),
            "mass_flow_one_axis_reference": list(MODEL_IDS) + list(LOCALIZED_IDS),
            "mass_flow_two_panel_reference": list(MODEL_IDS) + list(LOCALIZED_IDS),
        },
        "source_files": {
            name: {
                "path": path.relative_to(ROOT).as_posix(),
                "sha256": sha256(path),
            }
            for name, path in SOURCES.items()
        },
        "outputs": {
            path: {"sha256": sha256(ROOT / path)}
            for path in outputs
        },
        "temperature_parity": parity_validation,
        "mass_flow_trend": mdot_validation,
        "checks": checks,
        "all_checks_pass": all(check["pass"] for check in checks),
    }
    validation_path = VALIDATION_DIR / "csem_scientific_triage_validation.json"
    validation_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    if not payload["all_checks_pass"]:
        failed = [check["check"] for check in checks if not check["pass"]]
        raise SystemExit(f"figure validation failed: {', '.join(failed)}")

    regenerated = (
        len(mdot_outputs) + len(reference_outputs) + len(one_axis_reference_outputs)
        if args.mdot_only
        else len(outputs)
    )
    print(
        f"Regenerated {regenerated} figure files and wrote "
        f"{validation_path.relative_to(ROOT)}"
    )
    print(f"Validated {len(checks)} row-count and score-reproduction checks")


if __name__ == "__main__":
    main()
