#!/usr/bin/env bash
set -euo pipefail
script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
repo_root="$(cd "${script_dir}/../.." && pwd)"

input="${repo_root}/figures/svg/tamu_loop.svg"
output="${repo_root}/figures/pdf/tamu_loop.pdf"

if ! command -v inkscape >/dev/null 2>&1; then
  echo "ERROR: inkscape is required to convert ${input}" >&2
  exit 1
fi

inkscape "${input}" --export-area-drawing --export-filename="${output}"
echo "Wrote ${output}"
