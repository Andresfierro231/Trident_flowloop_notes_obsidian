#!/usr/bin/env python3
"""Plot the nominal TP temperature-elevation model-form progression."""

from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path

import matplotlib.pyplot as plt


CASE_ORDER = ("salt_1", "salt_2", "salt_3", "salt_4")
SENSOR_ORDER = ("TP1", "TP2", "TP3", "TP4", "TP5", "TP6")
HEIGHT_BY_SENSOR = {
    "TP1": 0.9144,
    "TP2": 0.0,
    "TP3": 0.312743219056991,
    "TP4": 0.676979219056991,
    "TP5": 0.862907219056991,
    "TP6": 1.227143219056991,
}
MODEL_ROWS = (
    ("C5_f3_eta_with_junction", "C5"),
    ("C6_f3_no_junction_eta1", "C6"),
    ("P1_shah_global008", "P1"),
)
STYLES = {
    "CFD": {"color": "#222222", "marker": "o", "linestyle": "-", "linewidth": 2.1, "zorder": 6},
    "C5": {"color": "#D55E00", "marker": "^", "linestyle": ":", "linewidth": 1.7, "zorder": 2},
    "C6": {"color": "#CC79A7", "marker": "D", "linestyle": "-.", "linewidth": 1.7, "zorder": 3},
    "P1": {"color": "#009E73", "marker": "v", "linestyle": (0, (5, 2)), "linewidth": 1.7, "zorder": 4},
    "Localized 1D": {"color": "#0072B2", "marker": "s", "linestyle": "--", "linewidth": 2.0, "zorder": 5},
}


def parse_args() -> argparse.Namespace:
    repo_root = Path(__file__).resolve().parents[2]
    parser = argparse.ArgumentParser(
        description="Plot CFD, C5, C6, P1, and localized 1D TP temperatures."
    )
    parser.add_argument(
        "--progression-input",
        type=Path,
        default=repo_root / "evidence" / "predictive_model_score_release_2026_07_28" / "all_model_training_sensor_scores.csv",
    )
    parser.add_argument(
        "--localized-input",
        type=Path,
        default=repo_root / "evidence" / "tp_temperature_elevation_2026_08_10" / "tp_nominal_cfd_localized_1d.csv",
    )
    parser.add_argument(
        "--output-dir", type=Path, default=repo_root / "figures"
    )
    return parser.parse_args()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as stream:
        return list(csv.DictReader(stream))


def load_data(
    progression_path: Path, localized_path: Path
) -> tuple[dict[str, dict[str, dict[str, float]]], dict[str, float]]:
    progression_rows = read_csv(progression_path)
    localized_rows = read_csv(localized_path)
    expected = {(case, sensor) for case in CASE_ORDER for sensor in SENSOR_ORDER}
    data: dict[str, dict[str, dict[str, float]]] = {
        case: {sensor: {} for sensor in SENSOR_ORDER} for case in CASE_ORDER
    }
    selected_progression = [
        row
        for row in progression_rows
        if row["candidate_id"] in {candidate for candidate, _ in MODEL_ROWS}
        and row["sensor_kind"] == "TP"
    ]
    if len(selected_progression) != 72:
        raise ValueError(f"Expected 72 C5/C6/P1 rows; found {len(selected_progression)}")

    for candidate, label in MODEL_ROWS:
        rows = [row for row in selected_progression if row["candidate_id"] == candidate]
        observed = {(row["case_id"], row["sensor"]) for row in rows}
        if observed != expected:
            raise ValueError(f"Incomplete nominal TP rows for {candidate}")
        for row in rows:
            case = row["case_id"]
            sensor = row["sensor"]
            prediction = float(row["prediction_K"])
            target = float(row["cfd_target_K"])
            residual = float(row["signed_error_K"])
            if not math.isclose(prediction - target, residual, abs_tol=1.0e-10):
                raise ValueError(f"Residual mismatch for {candidate} {case} {sensor}")
            data[case][sensor][label] = prediction
            data[case][sensor]["CFD"] = target

    observed_localized = {(row["case_id"], row["sensor"]) for row in localized_rows}
    if len(localized_rows) != 24 or observed_localized != expected:
        raise ValueError("Localized input does not contain 4 cases x 6 TP sensors")
    for row in localized_rows:
        case = row["case_id"]
        sensor = row["sensor"]
        target = float(row["cfd_temperature_K"])
        if not math.isclose(data[case][sensor]["CFD"], target, abs_tol=1.0e-10):
            raise ValueError(f"CFD target mismatch for {case} {sensor}")
        prediction = float(row["model_temperature_K"])
        residual = float(row["signed_error_K"])
        if not math.isclose(prediction - target, residual, abs_tol=1.0e-10):
            raise ValueError(f"Localized residual mismatch for {case} {sensor}")
        data[case][sensor]["Localized 1D"] = prediction

    rmse: dict[str, float] = {}
    for label in ("C5", "C6", "P1", "Localized 1D"):
        errors = [
            data[case][sensor][label] - data[case][sensor]["CFD"]
            for case in CASE_ORDER
            for sensor in SENSOR_ORDER
        ]
        rmse[label] = math.sqrt(sum(error**2 for error in errors) / len(errors))
    return data, rmse


def closed(values: list[float]) -> list[float]:
    return values + [values[0]]


def draw_case(ax: plt.Axes, case_data: dict[str, dict[str, float]]) -> None:
    height = [HEIGHT_BY_SENSOR[sensor] for sensor in SENSOR_ORDER]
    for label in ("CFD", "C5", "C6", "P1", "Localized 1D"):
        temperature = [case_data[sensor][label] for sensor in SENSOR_ORDER]
        ax.plot(
            closed(temperature),
            closed(height),
            markersize=5.0 if label != "CFD" else 5.4,
            label=label,
            **STYLES[label],
        )

    for sensor, y in zip(SENSOR_ORDER, height):
        ax.annotate(
            sensor,
            (case_data[sensor]["CFD"], y),
            xytext=(5, 3),
            textcoords="offset points",
            fontsize=7.2,
            color=STYLES["CFD"]["color"],
        )
        ax.annotate(
            sensor,
            (case_data[sensor]["Localized 1D"], y),
            xytext=(5, -10),
            textcoords="offset points",
            fontsize=7.2,
            color=STYLES["Localized 1D"]["color"],
        )
    ax.set_ylim(-0.06, 1.29)
    ax.grid(axis="y", color="#D9D9D9", linewidth=0.7)
    ax.tick_params(direction="out")


def save_all_formats(fig: plt.Figure, base: Path) -> None:
    figure_root = base.parent
    pdf_path = figure_root / "pdf" / base.with_suffix(".pdf").name
    svg_path = figure_root / "svg" / base.with_suffix(".svg").name
    png_path = figure_root / "png" / base.with_suffix(".png").name
    for path in (pdf_path, svg_path, png_path):
        path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(pdf_path, bbox_inches="tight")
    fig.savefig(svg_path, bbox_inches="tight")
    svg_text = svg_path.read_text(encoding="utf-8")
    svg_path.write_text(
        "\n".join(line.rstrip() for line in svg_text.splitlines()) + "\n",
        encoding="utf-8",
    )
    fig.savefig(png_path, dpi=300, bbox_inches="tight")


def make_figure(
    data: dict[str, dict[str, dict[str, float]]],
    rmse: dict[str, float],
    output_dir: Path,
) -> None:
    fig, axes = plt.subplots(2, 2, figsize=(9.0, 7.6), sharey=True)
    for ax, case in zip(axes.flat, CASE_ORDER):
        draw_case(ax, data[case])
        ax.set_title(case.replace("salt_", "Salt "))
        ax.set_xlabel("Temperature (K)")
    axes[0, 0].set_ylabel("Height above TP2 (m)")
    axes[1, 0].set_ylabel("Height above TP2 (m)")

    handles, _ = axes[0, 0].get_legend_handles_labels()
    legend_labels = [
        "CFD",
        f"C5 ({rmse['C5']:.2f} K)",
        f"C6 ({rmse['C6']:.2f} K)",
        f"P1 ({rmse['P1']:.2f} K)",
        f"Localized 1D ({rmse['Localized 1D']:.2f} K)",
    ]
    fig.suptitle("Nominal TP temperature model progression", y=0.995)
    fig.legend(
        handles,
        legend_labels,
        title="Four-case TP RMSE",
        loc="upper center",
        bbox_to_anchor=(0.5, 0.955),
        ncol=3,
        frameon=False,
        fontsize=8.8,
        title_fontsize=8.8,
    )
    fig.tight_layout(rect=(0, 0, 1, 0.86))
    save_all_formats(
        fig, output_dir / "csem_tp_temperature_vs_elevation_model_forms_nominal_all"
    )
    plt.close(fig)


def main() -> None:
    args = parse_args()
    data, rmse = load_data(args.progression_input, args.localized_input)
    make_figure(data, rmse, args.output_dir)
    print("Validated 120 plotted points: 24 CFD and 96 model predictions")
    print(
        "Four-case TP RMSE (K): "
        + ", ".join(f"{label}={value:.6f}" for label, value in rmse.items())
    )
    print(f"Generated 3 files in {args.output_dir}")


if __name__ == "__main__":
    main()
