#!/usr/bin/env python3
"""Generate evidence-supported dissertation figures for Pass 7.

Outputs are grouped under figures/pdf, figures/png, and figures/svg. Numerical inputs are read from
controlled CSV/JSON evidence files. Conceptual diagrams use only the geometry,
model, and evidence contracts cited in the generated manifest.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import shutil
import subprocess
from pathlib import Path
from textwrap import fill

import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.patches import Circle, FancyArrowPatch, FancyBboxPatch, Polygon, Rectangle

REPO = Path(__file__).resolve().parents[2]
OUT_BY_SUFFIX = {
    "pdf": REPO / "figures" / "pdf",
    "png": REPO / "figures" / "png",
    "svg": REPO / "figures" / "svg",
}
DATA_OUT = REPO / "figures" / "data"

# A restrained, colorblind-aware palette used consistently across diagrams.
NAVY = "#1f4e79"
BLUE = "#4c78a8"
ORANGE = "#f28e2b"
GREEN = "#59a14f"
RED = "#e15759"
PURPLE = "#b07aa1"
GRAY = "#6b7280"
LIGHT = "#eef2f7"
DARK = "#1f2937"
WHITE = "#ffffff"
YELLOW = "#edc948"
TEAL = "#76b7b2"

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 9,
    "axes.titlesize": 11,
    "axes.labelsize": 9,
    "figure.dpi": 120,
    "savefig.dpi": 300,
    "pdf.fonttype": 42,
    "ps.fonttype": 42,
    "svg.hashsalt": "csem-pass7-figures",
})


def rel(path: Path) -> str:
    return str(path.relative_to(REPO))


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def save_all(fig: plt.Figure, stem: str) -> list[Path]:
    outputs = []
    for ext in ("pdf", "svg", "png"):
        p = OUT_BY_SUFFIX[ext] / f"{stem}.{ext}"
        p.parent.mkdir(parents=True, exist_ok=True)
        kwargs = {"bbox_inches": "tight", "pad_inches": 0.03}
        if ext == "png":
            kwargs["dpi"] = 300
        elif ext == "pdf":
            kwargs["metadata"] = {"Creator": "scripts/figures/generate_pass7_figures.py", "CreationDate": None, "ModDate": None}
        elif ext == "svg":
            kwargs["metadata"] = {"Date": None, "Creator": "scripts/figures/generate_pass7_figures.py"}
        fig.savefig(p, **kwargs)
        outputs.append(p)
    plt.close(fig)
    return outputs


def box(ax, xy, w, h, text, *, fc=LIGHT, ec=NAVY, lw=1.2, fontsize=8.5, radius=0.025, z=2, **kwargs):
    patch = FancyBboxPatch(xy, w, h, boxstyle=f"round,pad=0.015,rounding_size={radius}",
                           facecolor=fc, edgecolor=ec, linewidth=lw, zorder=z)
    ax.add_patch(patch)
    ax.text(xy[0] + w/2, xy[1] + h/2, text, ha="center", va="center",
            fontsize=fontsize, color=DARK, zorder=z+1, **kwargs)
    return patch


def arrow(ax, p0, p1, *, color=NAVY, lw=1.4, style="-|>", ms=12, z=3, connectionstyle="arc3"):
    a = FancyArrowPatch(p0, p1, arrowstyle=style, mutation_scale=ms,
                        linewidth=lw, color=color, connectionstyle=connectionstyle,
                        shrinkA=2, shrinkB=2, zorder=z)
    ax.add_patch(a)
    return a


def setup_ax(figsize=(7.4, 4.8)):
    fig, ax = plt.subplots(figsize=figsize)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.axis("off")
    return fig, ax


def fig_tamu_loop() -> tuple[list[Path], list[Path], str]:
    sources = [
        REPO / "figures/svg/tamu_loop.svg",
        REPO / "evidence/ch03_cfd_database/tamu_loop_geometry_evidence.csv",
        REPO / "chapters/03_physical_system_and_evidence.tex",
    ]
    fig, ax = setup_ax((7.4, 5.5))
    ax.set_title("TAMU natural-circulation loop and measurement context", pad=8, fontweight="bold")

    # Schematic centerline, deliberately not to scale.
    pts = [(0.23,0.22),(0.62,0.08),(0.82,0.08),(0.82,0.75),(0.68,0.75),(0.33,0.91),(0.23,0.91),(0.23,0.22)]
    for a,b in zip(pts[:-1],pts[1:]):
        ax.plot([a[0],b[0]],[a[1],b[1]], color=DARK, linewidth=6, solid_capstyle="round", zorder=1)
        ax.plot([a[0],b[0]],[a[1],b[1]], color=WHITE, linewidth=3.2, solid_capstyle="round", zorder=2)
    # Test-section highlight on left vertical.
    ax.plot([0.23,0.23],[0.45,0.66], color=TEAL, linewidth=8, solid_capstyle="butt", zorder=1)
    ax.plot([0.23,0.23],[0.45,0.66], color=WHITE, linewidth=3.2, solid_capstyle="butt", zorder=2)
    # Heater and cooler spans.
    ax.plot([0.31,0.53],[0.19,0.11], color=ORANGE, linewidth=10, alpha=.65, zorder=0)
    ax.plot([0.44,0.66],[0.86,0.76], color=BLUE, linewidth=10, alpha=.55, zorder=0)

    # Flow arrows.
    arrow(ax,(0.34,0.18),(0.52,0.115),color=NAVY,lw=1.8)
    arrow(ax,(0.82,0.62),(0.82,0.36),color=NAVY,lw=1.8)
    arrow(ax,(0.63,0.77),(0.48,0.84),color=NAVY,lw=1.8)
    arrow(ax,(0.23,0.39),(0.23,0.59),color=NAVY,lw=1.8)
    ax.text(0.53,0.02,"declared positive circulation direction",ha="center",va="center",fontsize=8,color=NAVY)

    ax.text(0.39,0.095,"heated incline",rotation=-20,ha="center",va="center",fontweight="bold",color=DARK,fontsize=8.2)
    ax.text(0.55,0.755,"cooled incline / active jacket",rotation=-20,ha="center",va="center",fontweight="bold",color=DARK,fontsize=8.0)
    ax.text(0.17,0.57,"quartz test section",ha="right",va="center",fontweight="bold",color=TEAL,fontsize=8.0)
    ax.text(0.76,0.55,"right downcomer",ha="right",va="center",fontweight="bold",fontsize=8.0)
    ax.text(0.18,0.74,"left vertical leg",ha="right",va="center",fontweight="bold",fontsize=8.0)

    # Approximate sensor tags follow the working comparison map, not survey coordinates.
    tp = {"TP1":(0.84,0.75),"TP2":(0.84,0.08),"TP3":(0.21,0.22),"TP4":(0.21,0.45),"TP5":(0.21,0.66),"TP6":(0.21,0.91)}
    tw = {"TW1":(0.80,0.62),"TW2":(0.80,0.43),"TW3":(0.80,0.20),"TW4":(0.58,0.10),"TW5":(0.48,0.13),"TW6":(0.36,0.17),"TW7":(0.22,0.32),"TW8":(0.22,0.78),"TW9":(0.38,0.86),"TW11":(0.69,0.75)}
    tp_offsets={"TP1":(0.018,0.020),"TP2":(0.018,-0.022),"TP3":(-0.018,-0.020),"TP4":(-0.018,0.018),"TP5":(-0.018,0.020),"TP6":(-0.018,0.020)}
    tw_offsets={"TW1":(0.020,0.022),"TW2":(0.020,0.020),"TW3":(0.020,-0.020),"TW4":(0.000,-0.035),"TW5":(0.000,-0.035),"TW6":(-0.005,0.032),"TW7":(-0.020,-0.026),"TW8":(-0.020,0.028),"TW9":(-0.010,0.038),"TW11":(0.010,-0.035)}
    for name,(x,y) in tp.items():
        ax.add_patch(Circle((x,y),0.009,facecolor=NAVY,edgecolor=WHITE,lw=.7,zorder=5))
        dx,dy=tp_offsets[name]
        ax.text(x+dx,y+dy,name,ha="left" if dx>=0 else "right",va="center",fontsize=7.5,color=NAVY,fontweight="bold")
    for name,(x,y) in tw.items():
        ax.add_patch(Circle((x,y),0.007,facecolor=ORANGE,edgecolor=WHITE,lw=.7,zorder=5))
        dx,dy=tw_offsets[name]
        ax.text(x+dx,y+dy,name,ha="left" if dx>=0 else "right",va="center",fontsize=6.8,color="#a24b00")
    ax.add_patch(Rectangle((0.56,0.80),0.07,0.035,facecolor=BLUE,alpha=.35,edgecolor=BLUE))
    ax.text(0.595,0.865,"TW10: jacket shell",ha="center",va="bottom",fontsize=6.8,color=BLUE)
    ax.add_patch(Rectangle((0.205,0.51),0.05,0.06,facecolor=PURPLE,alpha=.25,edgecolor=PURPLE,linestyle="--"))
    ax.text(0.17,0.49,"PIV region",ha="right",va="center",fontsize=7.2,color=PURPLE,fontweight="bold")

    # Geometry basis inset.
    box(ax,(0.42,0.29),0.32,0.15,
        "Geometry bases\nCFD pipe: 0.87 in ID\nPhysical quartz test section: 0.835 in ID",
        fc="#f8fafc",ec=GRAY,fontsize=8.2)
    ax.text(0.43,0.26,"Sensor positions are schematic working projections;\nnot a survey-grade station map.",
            ha="left",va="top",fontsize=7.0,color=GRAY,style="italic")
    ax.text(0.02,0.01,"Not to scale",ha="left",va="bottom",fontsize=7,color=GRAY)
    outputs = save_all(fig,"ch03_tamu_loop_geometry_instrumentation")
    return outputs, sources, "Conceptual geometry and instrumentation map; sensor locations are explicitly schematic."


def fig_evidence_flow() -> tuple[list[Path], list[Path], str]:
    sources = [
        REPO / "evidence/ch03_cfd_database/case_provenance_table.csv",
        REPO / "evidence/ch03_cfd_database/claim_boundary_table.csv",
        REPO / "evidence/ch03_cfd_database/qoi_dictionary.csv",
        REPO / "evidence/ch03_cfd_database/postprocessing_method_table.csv",
    ]
    fig, ax = setup_ax((7.4, 5.0))
    ax.set_title("Evidence classification and reproducible data flow", pad=8, fontweight="bold")
    # Three independent axes.
    headings = [(0.03,"Source class",["Experiment","CFD evidence","1D result"]),
                (0.35,"Case partition",["Candidate training","Training support","Protected holdout","External test"]),
                (0.68,"Quantity role",["Runtime input","Calibration candidate","Diagnostic","Evaluation target","Forward quantity"])]
    for x,h,items in headings:
        ax.text(x+0.13,0.91,h,ha="center",va="center",fontweight="bold",color=NAVY)
        for j,item in enumerate(items):
            y=0.83-j*0.075
            box(ax,(x,y),0.26,0.052,item,fc=WHITE,ec=BLUE,fontsize=7.8,radius=.012)
    ax.text(0.50,0.46,"Every record carries all three labels",ha="center",va="center",fontsize=9.3,fontweight="bold",color=DARK)
    arrow(ax,(0.50,0.43),(0.50,0.37),color=GRAY)
    stages=[("Register source\nand split role",0.03),("Select retained\ntime window",0.22),("Apply fixed\ngeometry masks",0.41),("Reduce QoI and\nattach uncertainty",0.60),("Publish thesis\nfigure / table",0.79)]
    for text,x in stages:
        box(ax,(x,0.19),0.16,0.11,text,fc=LIGHT,ec=NAVY,fontsize=7.6)
    for (_,x0),(_,x1) in zip(stages[:-1],stages[1:]):
        arrow(ax,(x0+0.16,0.245),(x1,0.245),color=NAVY)
    # Permitted uses and hard boundary.
    box(ax,(0.10,0.03),0.34,0.095,"Permitted: interpretation, bounded calibration,\nwithheld evaluation, uncertainty qualification",fc="#eef8ef",ec=GREEN,fontsize=7.6)
    box(ax,(0.56,0.03),0.34,0.095,"Prohibited: CFD response as runtime input,\nprotected-row tuning, silent source relabeling",fc="#fff1f1",ec=RED,fontsize=7.6)
    outputs=save_all(fig,"ch03_evidence_data_flow")
    return outputs,sources,"Conceptual workflow derived from the Chapter 3 evidence contracts."


def fig_cfd_to_1d() -> tuple[list[Path], list[Path], str]:
    sources=[
        REPO / "chapters/04_cfd_to_1d_reduction.tex",
        REPO / "reports/2026-07-23_pass4_reduction_equation_audit.csv",
        REPO / "evidence/ch03_cfd_database/postprocessing_method_table.csv",
        REPO / "evidence/ch03_cfd_database/qoi_dictionary.csv",
    ]
    fig,ax=setup_ax((7.4,4.7))
    ax.set_title("Conservative reduction from three-dimensional fields to one-dimensional states",pad=8,fontweight="bold")
    # Left CFD control volume.
    ax.add_patch(FancyBboxPatch((0.03,0.19),0.25,0.62,boxstyle="round,pad=0.02",facecolor="#f3f7fb",edgecolor=BLUE,lw=1.5))
    ax.text(0.155,0.76,"Registered CFD field",ha="center",fontweight="bold",color=NAVY)
    # pipe/cv cartoon
    ax.add_patch(Rectangle((0.075,0.35),0.16,0.22,facecolor="#dbeafe",edgecolor=NAVY,lw=1.2))
    ax.plot([0.075,0.235],[0.46,0.46],color=NAVY,lw=1,linestyle="--")
    for x in [0.095,0.135,0.175,0.215]:
        arrow(ax,(x,0.40),(x+0.035,0.43),color=BLUE,lw=1,ms=8)
        arrow(ax,(x,0.50),(x+0.03,0.48),color=RED,lw=1,ms=8)
    ax.text(0.155,0.31,"$p,T,\\rho,\\boldsymbol{u}$\nwall heat flux",ha="center",va="top",fontsize=8)
    ax.text(0.155,0.23,"fixed planes, surfaces,\nand retained window",ha="center",fontsize=7.5,color=GRAY)
    # Operators.
    ops=[("$\\dot m=\\int_A \\rho u_n\\,dA$",0.34,0.66),
         ("$T_b$ from enthalpy flux",0.34,0.52),
         ("static + kinetic + hydrostatic\npressure accounting",0.34,0.38),
         ("$\\dot Q_w=-\\int_{A_w}q''_{out}\\,dA$",0.34,0.24)]
    for text,x,y in ops:
        box(ax,(x,y),0.28,0.09,text,fc=WHITE,ec=TEAL,fontsize=7.5)
    for y in [0.705,0.565,0.425,0.285]:
        arrow(ax,(0.28,y),(0.34,y),color=GRAY)
        arrow(ax,(0.62,y),(0.68,y),color=GRAY)
    # 1D output.
    ax.add_patch(FancyBboxPatch((0.68,0.19),0.29,0.62,boxstyle="round,pad=0.02",facecolor="#f7faf7",edgecolor=GREEN,lw=1.5))
    ax.text(0.825,0.76,"One-dimensional record",ha="center",fontweight="bold",color="#2f6b2f")
    outitems=["segment $T_b$ and wall state","solved loop $\\dot m$","pressure contributions","heat-rate pathways","sensor projections","status + uncertainty"]
    for j,t in enumerate(outitems):
        y=0.66-j*0.075
        box(ax,(0.72,y),0.21,0.047,t,fc=WHITE,ec=GREEN,fontsize=7.2,radius=.009)
    box(ax,(0.32,0.04),0.36,0.09,"Evaluation-only CFD responses remain targets or diagnostics;\nthey do not prescribe the forward solution.",fc="#fff5f5",ec=RED,fontsize=7.6)
    outputs=save_all(fig,"ch04_cfd_to_1d_reduction")
    return outputs,sources,"Conceptual reduction contract; equations are displayed only at the operator level."


def fig_pressure() -> tuple[list[Path], list[Path], str]:
    sources=[
        REPO / "chapters/04_cfd_to_1d_reduction.tex",
        REPO / "reports/2026-07-23_pass4_reduction_equation_audit.csv",
        REPO / "evidence/ch07_pressure_negative/section_effective_residual_table.csv",
        REPO / "evidence/ch07_pressure_negative/ordinary_basis_failure_matrix.csv",
    ]
    fig,ax=setup_ax((7.4,4.8))
    ax.set_title("Pressure-reduction sequence and explicit contribution accounting",pad=8,fontweight="bold")
    stages=[("Area-averaged\nstatic pressure",0.03,BLUE),
            ("Add kinetic\ncorrection",0.23,TEAL),
            ("Remove hydrostatic\nchange",0.43,GREEN),
            ("Section irreversible\ndemand",0.63,ORANGE),
            ("Model comparison\nand remainder",0.83,RED)]
    for text,x,c in stages:
        box(ax,(x,0.64),0.14,0.14,text,fc=WHITE,ec=c,fontsize=7.7)
    for (_,x0,_),(_,x1,_) in zip(stages[:-1],stages[1:]):
        arrow(ax,(x0+0.14,0.71),(x1,0.71),color=GRAY)
    terms=[("Distributed\nfriction",0.02,0.35,BLUE),
           ("Development /\nreset",0.215,0.35,TEAL),
           ("Local or section-\neffective",0.41,0.35,ORANGE),
           ("Recirculation /\nrecovery",0.605,0.35,PURPLE),
           ("Explicit\nremainder",0.80,0.35,RED)]
    for text,x,y,c in terms:
        box(ax,(x,y),0.17,0.115,text,fc=LIGHT,ec=c,fontsize=6.8)
    ax.text(0.50,0.225,"$\\Delta p_{irr}=\\Delta p_f+\\Delta p_{dev}+\\Delta p_{local}+\\Delta p_{recirc}+\\Delta p_{rem}$",
            ha="center",va="center",fontsize=10,color=DARK)
    box(ax,(0.12,0.035),0.76,0.105,
        "A signed static-pressure rise is not automatically a negative loss coefficient.\nPlane placement, hydrostatics, kinetic recovery, and recirculation must be resolved first.",
        fc="#fff5f5",ec=RED,fontsize=8.0)
    outputs=save_all(fig,"ch04_pressure_contribution_accounting")
    return outputs,sources,"Method schematic; no component coefficient is inferred from unresolved signed residuals."


def fig_energy_wall() -> tuple[list[Path], list[Path], str]:
    sources=[
        REPO / "chapters/04_cfd_to_1d_reduction.tex",
        REPO / "chapters/05_coupled_fluid_walls_model.tex",
        REPO / "evidence/latest_model_updates_2026_07_22/wall_thermal_circuit/segment_wall_circuit_components.csv",
        REPO / "evidence/latest_model_updates_2026_07_22/wall_thermal_circuit/handoff_inputs.csv",
    ]
    fig,ax=setup_ax((7.4,5.5))
    ax.set_title("Segment energy accounting and fluid-wall resistance path",pad=8,fontweight="bold")
    # fluid CV
    box(ax,(0.06,0.39),0.38,0.25,"Fluid control volume $V_i$\n$\\dot m(h_{out}-h_{in})=\\sum \\dot Q_i+\\dot Q_{rem}$",
        fc="#edf6ff",ec=BLUE,fontsize=9)
    arrow(ax,(0.00,0.515),(0.06,0.515),color=NAVY,lw=1.8); ax.text(0.01,0.55,"$\\dot m h_{in}$",fontsize=8)
    arrow(ax,(0.44,0.515),(0.52,0.515),color=NAVY,lw=1.8); ax.text(0.45,0.55,"$\\dot m h_{out}$",fontsize=8)
    # source/sinks
    for text,x,y,c,dirn in [
        ("heater source",0.10,0.80,ORANGE,"down"),("cooler removal",0.27,0.80,BLUE,"down"),
        ("test-section path",0.02,0.12,PURPLE,"up"),("exchange / storage",0.18,0.12,TEAL,"up"),("explicit residual",0.34,0.12,RED,"up")]:
        box(ax,(x,y),0.125,0.075,text,fc=WHITE,ec=c,fontsize=7.3)
        if dirn=="down": arrow(ax,(x+0.0625,y),(x+0.0625,0.64),color=c)
        else: arrow(ax,(x+0.0625,y+0.075),(x+0.0625,0.39),color=c)
    # wall circuit
    ax.text(0.72,0.88,"Radial thermal-resistance path",ha="center",fontweight="bold",color=NAVY)
    nodes=[("$T_b$",0.53,BLUE),("$T_{w,i}$",0.64,ORANGE),("$T_{w,o}$",0.75,PURPLE),("$T_s$",0.86,GREEN),("$T_\\infty$",0.96,GRAY)]
    for name,x,c in nodes:
        ax.add_patch(Circle((x,0.60),0.035,facecolor=WHITE,edgecolor=c,lw=1.5))
        ax.text(x,0.60,name,ha="center",va="center",fontsize=8.5)
    resist=[("$1/(h_iA)$",0.585),("$R_{wall}$",0.695),("$R_{ins}$",0.805),("$1/(h_oA)+R_{rad}$",0.91)]
    for (label,x),(n0,x0,_),(n1,x1,_) in zip(resist,nodes[:-1],nodes[1:]):
        ax.plot([x0+0.035,x1-0.035],[0.60,0.60],color=DARK,lw=1.4)
        ax.text(x,0.64,label,ha="center",va="bottom",fontsize=7.3)
    ax.text(0.75,0.48,"Each pathway remains separate;\nmissing heat is not hidden in $Nu$ or $UA$.",ha="center",va="top",fontsize=8,color=RED)
    box(ax,(0.52,0.15),0.43,0.16,"Positive sign convention\n$\\dot Q>0$ into the fluid\nNative outward wall heat flux is converted once.",fc="#f8fafc",ec=GRAY,fontsize=8)
    outputs=save_all(fig,"ch04_energy_wall_resistance")
    return outputs,sources,"Combined control-volume and radial-resistance schematic with explicit residual preservation."


def fig_model_architecture() -> tuple[list[Path], list[Path], str]:
    sources=[
        REPO / "chapters/05_coupled_fluid_walls_model.tex",
        REPO / "evidence/one_d_physics_solver_description_2026_07_28/README.md",
        REPO / "evidence/one_d_physics_solver_description_2026_07_28/thesis_alignment_corrections.md",
    ]
    fig,ax=setup_ax((7.4,5.4))
    ax.set_title("Steady one-dimensional loop model and nested solution",pad=8,fontweight="bold")

    # Ordered loop parents, grouped by physical function.
    xs=[0.06,0.24,0.42,0.60,0.78]
    labels=["Heated\nincline","Quartz test\nsection","Rising\nsection","Cooling\njacket","Downcomer\nand return"]
    for i,(x,lbl) in enumerate(zip(xs,labels)):
        box(ax,(x,0.60),0.14,0.12,lbl,fc="#edf6ff",ec=BLUE,fontsize=7.7)
        ax.text(x+0.07,0.55,r"$T_{in},\;T_{out},\;T_{avg}$",ha="center",va="center",fontsize=7.3,color=DARK)
        if i<len(xs)-1:
            arrow(ax,(x+0.14,0.66),(xs[i+1],0.66),color=NAVY,lw=1.7)
    arrow(ax,(0.85,0.77),(0.13,0.77),color=NAVY,lw=1.2,connectionstyle="arc3,rad=0.22")
    ax.text(0.50,0.82,"periodic bulk-temperature field and one solved loop mass flow $\\dot m$",ha="center",fontsize=8,color=NAVY)

    # Algebraic wall network, intentionally not an independent state.
    box(ax,(0.20,0.38),0.60,0.105,
        "Algebraic radial resistance networks\n$T_b \\rightarrow R_i' \\rightarrow R_w' \\rightarrow R_{ins}' \\rightarrow R_o' \\rightarrow T_\\infty$",
        fc="#fff4e8",ec=ORANGE,fontsize=8)
    ax.text(0.50,0.33,"pipe-wall and outer-surface temperatures are calculated outputs; no wall storage is integrated",
            ha="center",va="center",fontsize=7.4,color=ORANGE)

    # Nested solution and inputs/outputs.
    box(ax,(0.05,0.10),0.24,0.13,"Prescribed inputs\ngeometry, powers, ambient,\nair inlet state, fixed properties",fc="#f8fafc",ec=GRAY,fontsize=7.6)
    box(ax,(0.38,0.10),0.24,0.13,"Inner bisection\n" + r"$\mathcal{R}_T=T_{end}-T_0=0$",fc=LIGHT,ec=GREEN,fontsize=8)
    box(ax,(0.71,0.10),0.24,0.13,"Outer bisection\n" + r"$\mathcal{R}_p=\Delta p_{loss}-\Delta p_b=0$",fc=LIGHT,ec=NAVY,fontsize=8)
    arrow(ax,(0.29,0.165),(0.38,0.165),color=GRAY)
    arrow(ax,(0.62,0.165),(0.71,0.165),color=GRAY)
    arrow(ax,(0.83,0.23),(0.83,0.38),color=NAVY)
    arrow(ax,(0.50,0.23),(0.50,0.38),color=GREEN)

    ax.text(0.50,0.91,"Sources and sinks remain separate: heater, test section, ambient loss, cooler, junctions, and optional exchange.",
            ha="center",va="center",fontsize=7.5,color=DARK)
    outputs=save_all(fig,"ch05_coupled_model_architecture")
    return outputs,sources,"Conceptual diagram of the implemented steady bulk-fluid solver with algebraic wall resistance networks and nested roots."

def fig_model_form_ladder() -> tuple[list[Path], list[Path], str]:
    source=REPO / "evidence/model_form_figure_package/model_form_ladder_panel.csv"
    df=pd.read_csv(source).sort_values("rank")
    fig,ax=plt.subplots(figsize=(7.4,6.1))
    ax.set_xlim(0,1); ax.set_ylim(0.0,len(df)+0.8); ax.axis("off")
    ax.set_title("Model-form development ladder and current disposition",fontweight="bold",pad=8)
    status_colors={"specification_only":GRAY,"diagnostic_only":TEAL,"future":BLUE,"blocked":RED}
    for j,row in enumerate(df.itertuples(index=False),start=1):
        y=len(df)-j+0.9
        c=status_colors.get(row.visual_status,GRAY)
        ax.add_patch(Circle((0.07,y),0.045,facecolor=c,edgecolor=WHITE,lw=1.0))
        ax.text(0.07,y,str(int(row.rank)),ha="center",va="center",color=WHITE,fontweight="bold")
        ax.text(0.13,y+0.16,row.short_label,ha="left",va="center",fontweight="bold",color=DARK,fontsize=8.5)
        ax.text(0.13,y-0.05,fill(str(row.model_form_to_try),48),ha="left",va="center",fontsize=7.1,linespacing=1.15)
        status=str(row.visual_status).replace("_"," ")
        ax.add_patch(FancyBboxPatch((0.70,y-0.12),0.25,0.24,boxstyle="round,pad=0.01,rounding_size=.025",facecolor=WHITE,edgecolor=c,lw=1.2))
        ax.text(0.825,y,status,ha="center",va="center",fontsize=7.2,color=c,fontweight="bold")
        if j<len(df): ax.plot([0.07,0.07],[y-0.55,y-0.88],color="#cbd5e1",lw=2)
    ax.text(0.50,0.16,"The operational predictor is active; the ladder records local model-form status and next evidence checks.",ha="center",va="center",fontsize=7.8,color=RED)
    fig.tight_layout()
    outputs=save_all(fig,"ch08_model_form_development_ladder")
    return outputs,[source],"Direct plot of the controlled model-form ladder; no experimental-basis numeric ranking is shown."

def readiness_data() -> pd.DataFrame:
    rows=[
        ("Operational physics-based predictor","Running","coupled mass-flow and fluid-wall solution from setup-facing inputs"),
        ("Accuracy-oriented affine predictor","Active","approximately 7--10 K errors on declared CFD comparisons"),
        ("Fixed CFD properties and insulation","Supported","held identical to the 3D setup; not uncertainty variables"),
        ("Case partitions and input policy","Supported","roles and prohibited response inputs declared"),
        ("Hydraulic closures","Partial","developing forms screened; recovery and recirculation unresolved"),
        ("Thermal pathways","Partial","heater/cooler active; passive and test-section limits remain"),
        ("Recirculation representation","Architecture only","exchange coefficient and mesh-qualified quantity unresolved"),
        ("Same-quantity numerical uncertainty","Partial","diagnostic medium/fine comparisons only; formal GCI unavailable"),
        ("Final protected physical score","Blocked","complete local-closure set not yet locked"),
        ("Experimental and SAM validation","Not performed","current comparison is CFD based"),
    ]
    return pd.DataFrame(rows,columns=["required_element","status","interpretation"])

def fig_readiness() -> tuple[list[Path], list[Path], str]:
    sources=[
        REPO / "chapters/08_predictive_model_assessment.tex",
        REPO / "draft_coordination/model_status/current_model_status.md",
        REPO / "evidence/model_form_figure_package/blocked_scorecard_waterfall_panel.csv",
    ]
    df=readiness_data()
    DATA_OUT.mkdir(parents=True,exist_ok=True)
    data_path=DATA_OUT / "ch08_predictive_readiness.csv"
    df.to_csv(data_path,index=False)
    fig,ax=plt.subplots(figsize=(7.4,5.5))
    ax.set_xlim(0,1); ax.set_ylim(-0.5,len(df)-0.5); ax.axis("off")
    ax.set_title("Predictive model assessment and current status",fontweight="bold",pad=8)
    colors={"Running":GREEN,"Active":TEAL,"Supported":GREEN,"Partial":YELLOW,"Architecture only":TEAL,"Blocked":RED,"Not performed":GRAY}
    for i,row in df.iloc[::-1].reset_index(drop=True).iterrows():
        y=i
        c=colors[row.status]
        ax.add_patch(Rectangle((0.02,y-0.34),0.96,0.68,facecolor="#fbfcfe",edgecolor="#e5e7eb",lw=.6))
        ax.text(0.04,y,row.required_element,ha="left",va="center",fontsize=7.7,fontweight="bold")
        ax.add_patch(FancyBboxPatch((0.39,y-0.19),0.16,0.38,boxstyle="round,pad=0.01,rounding_size=.025",facecolor=c,edgecolor=c))
        ax.text(0.47,y,row.status,ha="center",va="center",fontsize=7.2,color=WHITE if row.status not in {"Partial"} else DARK,fontweight="bold")
        ax.text(0.58,y,fill(row.interpretation,53),ha="left",va="center",fontsize=6.8,color=DARK)
    fig.tight_layout()
    outputs=save_all(fig,"ch08_predictive_readiness_summary")
    return outputs,sources+[data_path],"Predictive assessment statuses transcribed from the controlled Chapter 8 table and current model status."


def prepare_recirculation() -> tuple[list[Path], list[Path], str]:
    script=REPO / "evidence/source_packages/velocity_magnitude_pictures/scripts/rebuild_review_composites.py"
    src=REPO / "evidence/source_packages/velocity_magnitude_pictures/figures/composites/y_velocity_side_z_trimmed_composite_labeled.png"
    if not src.is_file():
        subprocess.run(["python3",str(script)],cwd=REPO,check=True)
    dst=OUT_BY_SUFFIX["png"] / "ch07_recirculation_y_velocity.png"
    dst_pdf=OUT_BY_SUFFIX["pdf"] / "ch07_recirculation_y_velocity.pdf"
    dst.parent.mkdir(parents=True,exist_ok=True)
    dst_pdf.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dst)
    image=plt.imread(dst)
    height,width=image.shape[:2]
    fig=plt.figure(figsize=(width/300.0,height/300.0),dpi=300)
    ax=fig.add_axes([0,0,1,1])
    ax.imshow(image); ax.axis("off")
    fig.savefig(
        dst_pdf,
        format="pdf",
        bbox_inches=None,
        pad_inches=0,
        metadata={
            "Creator":"scripts/figures/generate_pass7_figures.py",
            "CreationDate":None,
            "ModDate":None,
        },
    )
    plt.close(fig)
    sources=[script,src,REPO / "evidence/source_packages/velocity_magnitude_pictures/y_velocity_side_z_status.json"]
    return [dst,dst_pdf],sources,"Used the retained hash-bound composite (rebuilding only when absent) and exported both PNG and PDF."


def prepare_recirculation_cross_section() -> tuple[list[Path], list[Path], str]:
    package=REPO / "evidence/source_packages/upcomer_cross_section_salt14_figure"
    src=package / "salt1_4_upcomer_midplane_signed_uy_polygon_horizontal.pdf"
    status=package / "composite_polygon_status.json"
    dst=OUT_BY_SUFFIX["pdf"] / "ch03_upcomer_midplane_signed_uy_polygon_horizontal.pdf"
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(src,dst)
    return [dst],[src,status],"Promoted the audited PDF-native Salt1--Salt4 midpoint cross-section composite."

FIGURES={
    "tamu_loop": fig_tamu_loop,
    "evidence_flow": fig_evidence_flow,
    "cfd_to_1d": fig_cfd_to_1d,
    "pressure": fig_pressure,
    "energy_wall": fig_energy_wall,
    "model_architecture": fig_model_architecture,
    "recirculation": prepare_recirculation,
    "recirculation_cross_section": prepare_recirculation_cross_section,
    "model_form": fig_model_form_ladder,
    "readiness": fig_readiness,
}


def write_manifest(records):
    path=DATA_OUT / "figure_manifest.csv"
    path.parent.mkdir(parents=True, exist_ok=True)
    fields=["figure_id","output_path","output_sha256","source_path","source_sha256","generation_command","status_note"]
    with path.open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
        for rec in records:
            for out in rec["outputs"]:
                for src in rec["sources"]:
                    w.writerow({
                        "figure_id":rec["id"],"output_path":rel(out),"output_sha256":sha256(out),
                        "source_path":rel(src),"source_sha256":sha256(src),
                        "generation_command":f"python3 scripts/figures/generate_pass7_figures.py --only {rec['id']}",
                        "status_note":rec["note"],
                    })
    return path


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--only",choices=sorted(FIGURES),help="Generate one figure target")
    args=p.parse_args()
    for output_dir in OUT_BY_SUFFIX.values():
        output_dir.mkdir(parents=True, exist_ok=True)
    DATA_OUT.mkdir(parents=True, exist_ok=True)
    selected=[args.only] if args.only else list(FIGURES)
    records=[]
    for fid in selected:
        outputs,sources,note=FIGURES[fid]()
        records.append({"id":fid,"outputs":outputs,"sources":sources,"note":note})
        print(f"generated {fid}: {', '.join(rel(x) for x in outputs)}")
    if not args.only:
        manifest=write_manifest(records)
        print(f"manifest: {rel(manifest)}")

if __name__=="__main__":
    main()
