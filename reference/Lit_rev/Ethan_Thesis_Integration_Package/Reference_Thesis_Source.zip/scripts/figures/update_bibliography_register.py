#!/usr/bin/env python3
"""Refresh hashes and counts for the dissertation's LitRev bibliography resources."""
from __future__ import annotations

import argparse
import csv
import hashlib
import re
from datetime import date
from pathlib import Path

ENTRY_RE = re.compile(rb"@[A-Za-z]+\s*\{\s*([^,\s]+)")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def count_entries(path: Path) -> int:
    return len(ENTRY_RE.findall(path.read_bytes()))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source-project")
    parser.add_argument("--source-path")
    parser.add_argument("--snapshot-date")
    args = parser.parse_args()

    repo = Path(__file__).resolve().parents[1]
    bib_dir = repo / "bibliography"
    register = bib_dir / "source_import_register.csv"
    raw = bib_dir / "litrev_references.bib"
    compatible = bib_dir / "litrev_references_bibtex.bib"
    selection = bib_dir / "litrev_imported_keys.csv"

    source_project = args.source_project or "controlling LitRev read-only project"
    source_path = args.source_path or "bibliography/references.bib"
    snapshot_date = args.snapshot_date or date.today().isoformat()
    if register.is_file():
        rows = list(csv.DictReader(register.open(encoding="utf-8")))
        if rows:
            if not args.source_project:
                source_project = rows[0].get("source_project") or source_project
            if not args.source_path:
                source_path = rows[0].get("source_path") or source_path
            if not args.snapshot_date:
                snapshot_date = rows[0].get("snapshot_date") or snapshot_date

    selected_count = 0
    if selection.is_file():
        selected_count = sum(1 for _ in csv.DictReader(selection.open(encoding="utf-8")))

    fieldnames = [
        "resource", "source_project", "source_path", "snapshot_date",
        "sha256", "entry_count", "edit_policy",
    ]
    with register.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerow({
            "resource": "bibliography/litrev_references.bib",
            "source_project": source_project,
            "source_path": source_path,
            "snapshot_date": snapshot_date,
            "sha256": sha256(raw),
            "entry_count": count_entries(raw),
            "edit_policy": "read-only upstream snapshot; refresh by script",
        })
        writer.writerow({
            "resource": "bibliography/litrev_references_bibtex.bib",
            "source_project": source_project,
            "source_path": "generated from local raw snapshot, excluding selected direct imports",
            "snapshot_date": snapshot_date,
            "sha256": sha256(compatible),
            "entry_count": count_entries(compatible),
            "edit_policy": "generated; do not edit directly",
        })
        writer.writerow({
            "resource": "bibliography/litrev_imported_keys.csv",
            "source_project": source_project,
            "source_path": "selected keys copied from the raw snapshot into references.bib",
            "snapshot_date": snapshot_date,
            "sha256": sha256(selection),
            "entry_count": selected_count,
            "edit_policy": "selection and provenance manifest; update when direct imports change",
        })
    print(f"Updated bibliography register: {register}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
