#!/usr/bin/env python3
"""Require CSEM figure assets to live in extension-specific subfolders."""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
FIGURES = ROOT / "figures"
EXPECTED = {
    ".pdf": "pdf",
    ".png": "png",
    ".svg": "svg",
    ".tex": "tex",
    ".csv": "data",
    ".json": "data",
}


def main() -> int:
    misplaced: list[dict[str, str]] = []
    unexpected: list[str] = []
    counts = {folder: 0 for folder in sorted(set(EXPECTED.values()))}
    for path in sorted(FIGURES.rglob("*")):
        if not path.is_file() or path == FIGURES / "README.md":
            continue
        relative = path.relative_to(FIGURES)
        expected = EXPECTED.get(path.suffix.lower())
        if expected is None:
            unexpected.append(relative.as_posix())
            continue
        actual = relative.parts[0]
        counts[expected] += 1
        if actual != expected:
            misplaced.append(
                {
                    "path": relative.as_posix(),
                    "expected_folder": expected,
                    "actual_folder": actual,
                }
            )
    payload = {
        "figure_root": FIGURES.relative_to(ROOT).as_posix(),
        "counts": counts,
        "misplaced": misplaced,
        "unexpected_extensions": unexpected,
        "ok": not misplaced and not unexpected,
    }
    print(json.dumps(payload, indent=2))
    return 0 if payload["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
