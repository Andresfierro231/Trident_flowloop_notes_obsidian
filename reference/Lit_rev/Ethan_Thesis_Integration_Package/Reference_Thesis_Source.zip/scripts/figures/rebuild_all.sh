#!/usr/bin/env bash
set -euo pipefail
repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$repo_root"
python3 scripts/evidence/audit_repository_evidence.py
python3 scripts/figures/generate_pass7_figures.py
python3 scripts/figures/generate_pass7_tables.py
