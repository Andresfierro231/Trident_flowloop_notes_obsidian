#!/usr/bin/env python3
"""Build Pass 7 figure/table inventories and provenance reports.

The script inventories the pre-pass repository, records approved and blocked
figure targets, verifies generated assets and table inputs, and writes concise
machine-readable and human-readable reports. It does not generate scientific
values or infer missing data.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import re
from collections import Counter
from pathlib import Path

REPO = Path(__file__).resolve().parents[2]
REPORTS = REPO / "reports"

FIGURE_EXTS = {".png", ".jpg", ".jpeg", ".svg", ".pdf", ".eps"}
DATA_EXTS = {".csv", ".tsv", ".json", ".jsonl", ".txt", ".dat", ".xlsx", ".xls", ".npy", ".npz", ".h5", ".hdf5", ".parquet", ".vtk", ".vtu", ".pvtu", ".pvd", ".foam"}
SCRIPT_EXTS = {".py", ".sh", ".m", ".ipynb"}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def rel(path: Path, root: Path) -> str:
    return path.relative_to(root).as_posix()


def write_csv(path: Path, rows: list[dict], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def classify_data(path: Path) -> str:
    s = path.as_posix().lower()
    name = path.name.lower()
    if any(token in s for token in ("native_source", "/raw/", "source_packages")) and not any(token in name for token in ("status", "manifest", "summary")):
        return "native-or-staged-source"
    if any(token in name for token in ("manifest", "status", "registry", "index", "readme", "guardrail", "provenance")):
        return "metadata-or-provenance"
    if any(token in name for token in ("summary", "table", "panel", "score", "metric", "qoi", "gci", "interval", "profile", "fit", "result")):
        return "processed-or-reduced-evidence"
    return "evidence-or-support-data"


def inventory_existing_figures(baseline: Path) -> list[dict]:
    rows = []
    for p in sorted(baseline.rglob("*")):
        if not p.is_file() or p.suffix.lower() not in FIGURE_EXTS:
            continue
        rp = rel(p, baseline)
        # Restrict PDFs to manuscript/evidence figure folders so papers and PDFs are not misclassified.
        if p.suffix.lower() == ".pdf" and "figures" not in p.parts:
            continue
        if rp.startswith("figures/"):
            scope = "manuscript-asset"
        elif rp.startswith("evidence/") and "figures" in p.parts:
            scope = "evidence-figure-asset"
        elif rp.startswith("evidence/") and p.suffix.lower() in {".png", ".jpg", ".jpeg", ".svg"}:
            scope = "evidence-image-asset"
        else:
            continue
        rows.append({
            "relative_path": rp,
            "scope": scope,
            "extension": p.suffix.lower(),
            "size_bytes": p.stat().st_size,
            "sha256": sha256(p),
            "pre_pass_status": "existing",
        })
    return rows


def inventory_scripts(baseline: Path) -> list[dict]:
    rows = []
    for p in sorted(baseline.rglob("*")):
        if not p.is_file() or p.suffix.lower() not in SCRIPT_EXTS:
            continue
        rp = rel(p, baseline)
        low = rp.lower()
        if not any(token in low for token in ("plot", "figure", "composite", "postprocess", "post_process", "render", "visual", "panel", "image")):
            continue
        if "archive/" in low:
            status = "historical"
        elif rp == "scripts/figures/plot_tp_tw_vs_elevation.py":
            status = "active-existing"
        elif "source_packages/velocity_magnitude_pictures/scripts/rebuild_review_composites.py" in rp:
            status = "active-existing-used-pass7"
        else:
            status = "supporting-existing"
        rows.append({
            "relative_path": rp,
            "extension": p.suffix.lower(),
            "status": status,
            "size_bytes": p.stat().st_size,
            "sha256": sha256(p),
        })
    return rows


def inventory_data(baseline: Path) -> list[dict]:
    rows = []
    for p in sorted((baseline / "evidence").rglob("*")):
        if not p.is_file() or p.suffix.lower() not in DATA_EXTS:
            continue
        rp = rel(p, baseline)
        rows.append({
            "relative_path": rp,
            "extension": p.suffix.lower(),
            "classification": classify_data(p),
            "size_bytes": p.stat().st_size,
            "sha256": sha256(p),
        })
    return rows


def figure_targets() -> list[dict]:
    return [
        {"target_id":"F3-1","chapter":"3","target":"TAMU loop geometry and instrumentation","status":"produced-with-caveat","output":"figures/pdf/ch03_tamu_loop_geometry_instrumentation.pdf","script":"scripts/figures/generate_pass7_figures.py","command":"python3 scripts/figures/generate_pass7_figures.py --only tamu_loop","source_basis":"figures/svg/tamu_loop.svg; geometry hierarchy; CFD and physical-diameter author clarifications; Chapter 3","limitation":"Sensor tags are schematic working projections, not survey-grade coordinates."},
        {"target_id":"F3-2/F3-3","chapter":"3","target":"Evidence classification and source-to-product flow","status":"produced","output":"figures/pdf/ch03_evidence_data_flow.pdf","script":"scripts/figures/generate_pass7_figures.py","command":"python3 scripts/figures/generate_pass7_figures.py --only evidence_flow","source_basis":"case provenance; claim boundaries; QoI dictionary; postprocessing method table","limitation":"Conceptual process figure; it does not imply independent experiments or case families."},
        {"target_id":"F3-4","chapter":"3","target":"Complete retained-window time traces","status":"blocked","output":"","script":"","command":"","source_basis":"retained-window tables and unavailable complete source traces","limitation":"Salt1 and complete quantity-specific traces/windows are not included."},
        {"target_id":"F4-1/F4-2/F4-5","chapter":"4","target":"Loop segmentation, averaging, and CFD/sensor/1D reduction","status":"produced-with-caveat","output":"figures/pdf/ch04_cfd_to_1d_reduction.pdf","script":"scripts/figures/generate_pass7_figures.py","command":"python3 scripts/figures/generate_pass7_figures.py --only cfd_to_1d","source_basis":"Chapter 4 reduction equations; current model status; segment atlas; geometry hierarchy; recirculation topology evidence","limitation":"Uses 12 explicitly named segments; exact sensor projections remain blocked."},
        {"target_id":"F4-3","chapter":"4","target":"Pressure-plane selection and pressure-contribution accounting","status":"produced-method-schematic","output":"figures/pdf/ch04_pressure_contribution_accounting.pdf","script":"scripts/figures/generate_pass7_figures.py","command":"python3 scripts/figures/generate_pass7_figures.py --only pressure","source_basis":"Chapter 4 pressure equations; postprocessing method table; pressure-negative evidence","limitation":"Facility-specific pressure-plane positions are not shown because the registry is unavailable."},
        {"target_id":"F4-4","chapter":"4","target":"Energy-flow and wall-resistance accounting","status":"produced","output":"figures/pdf/ch04_energy_wall_resistance.pdf","script":"scripts/figures/generate_pass7_figures.py","command":"python3 scripts/figures/generate_pass7_figures.py --only energy_wall","source_basis":"Chapter 4 energy equations; governing-equation glossary; cooler and exchange status packets","limitation":"No unsupported coefficient is inserted."},
        {"target_id":"F5-1","chapter":"5","target":"Coupled one-dimensional fluid-wall model architecture","status":"produced","output":"figures/pdf/ch05_coupled_model_architecture.pdf","script":"scripts/figures/generate_pass7_figures.py","command":"python3 scripts/figures/generate_pass7_figures.py --only model_architecture","source_basis":"Chapter 5 governing architecture; current model status; segment sequence","limitation":"Architecture does not imply closure acceptance."},
        {"target_id":"F7-1","chapter":"7","target":"Upcomer recirculation / exchange-flow evidence","status":"reproduced-from-existing-internal-script","output":"figures/png/ch07_recirculation_y_velocity.png","script":"evidence/source_packages/velocity_magnitude_pictures/scripts/rebuild_review_composites.py","command":"python3 scripts/figures/generate_pass7_figures.py --only recirculation","source_basis":"staged CFD-rendered Salt1-Salt4 y-velocity panels and status JSON","limitation":"Qualitative topology evidence only; not an exchange coefficient or mesh-qualified quantitative closure."},
        {"target_id":"F8-1","chapter":"8","target":"Model-form development and comparison","status":"produced","output":"figures/pdf/ch08_model_form_development_ladder.pdf","script":"scripts/figures/generate_pass7_figures.py","command":"python3 scripts/figures/generate_pass7_figures.py --only model_form","source_basis":"model_form_ladder_panel.csv","limitation":"Records model-form disposition; no row is a finalized predictive model."},
        {"target_id":"F8-2","chapter":"8","target":"Predictive-readiness summary","status":"produced","output":"figures/pdf/ch08_predictive_readiness_summary.pdf","script":"scripts/figures/generate_pass7_figures.py","command":"python3 scripts/figures/generate_pass7_figures.py --only readiness","source_basis":"Chapter 8 readiness table; current model status; blocked scorecard evidence","limitation":"Reports readiness status, not a validation score."},
        {"target_id":"B3-1","chapter":"3","target":"Survey-grade sensor and station overlay","status":"blocked","output":"","script":"","command":"","source_basis":"sensor projection summary only","limitation":"Survey-grade TP/TW coordinates and controlled station map are absent."},
        {"target_id":"B4-1","chapter":"4","target":"Facility-specific pressure-plane map","status":"blocked","output":"","script":"","command":"","source_basis":"method descriptions only","limitation":"Controlled pressure-plane registry and exact plane coordinates are absent."},
        {"target_id":"B8-1","chapter":"8","target":"Final numerical physical-model scorecard","status":"blocked","output":"","script":"","command":"","source_basis":"readiness and model-form evidence","limitation":"No runtime-compliant physical candidate has been finalized or protected-scored."},
    ]


def table_manifest() -> list[dict]:
    rows = []
    specs = [
        ("T8-1", "Chapter 8 physical model-form comparison", "tables/data/ch08_physical_model_form_comparison.csv", "tables/generated/ch08_physical_model_form_comparison.tex", "chapters/08_predictive_model_assessment.tex", "python3 scripts/figures/generate_pass7_tables.py"),
        ("T8-2", "Chapter 8 predictive-readiness assessment", "tables/data/ch08_predictive_readiness.csv", "tables/generated/ch08_predictive_readiness.tex", "chapters/08_predictive_model_assessment.tex", "python3 scripts/figures/generate_pass7_tables.py"),
    ]
    for tid, title, data, output, chapter, command in specs:
        dp, op = REPO/data, REPO/output
        with dp.open(newline="", encoding="utf-8") as f:
            data_rows = list(csv.DictReader(f))
        provenance = sorted({
            item.strip()
            for r in data_rows
            for item in r.get("source_provenance", "").split(";")
            if item.strip()
        })
        rows.append({
            "table_id": tid,
            "title": title,
            "source_data": data,
            "source_data_sha256": sha256(dp),
            "source_provenance": "; ".join(provenance),
            "generated_output": output,
            "generated_output_sha256": sha256(op),
            "inserted_in": chapter,
            "generation_command": command,
            "manual_edit_permitted": "no",
        })
    return rows


def inspect_chapter_inserts() -> list[dict]:
    rows=[]
    pattern=re.compile(r"\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}|\\input\{(tables/generated/[^}]+)\}")
    for chapter in sorted((REPO/"chapters").glob("*.tex")):
        for line_no,line in enumerate(chapter.read_text(encoding="utf-8").splitlines(),1):
            m=pattern.search(line)
            if not m: continue
            target=m.group(1) or m.group(2)
            if target.startswith(("figures/pdf/", "figures/png/", "figures/svg/")) or target.startswith("tables/generated/"):
                rows.append({"chapter_path":rel(chapter,REPO),"line":line_no,"inserted_asset":target})
    return rows


def md_table(rows: list[dict], fields: list[str], labels: list[str] | None=None) -> list[str]:
    labels=labels or fields
    out=["| "+" | ".join(labels)+" |","|"+"|".join(["---"]*len(fields))+"|"]
    for r in rows:
        out.append("| "+" | ".join(str(r.get(f," ")).replace("|","\\|").replace("\n"," ") for f in fields)+" |")
    return out


def main() -> None:
    ap=argparse.ArgumentParser()
    ap.add_argument("--baseline", required=True, help="Path to the pre-pass source repository")
    args=ap.parse_args()
    baseline=Path(args.baseline).resolve()
    if not baseline.is_dir():
        raise SystemExit(f"Baseline repository not found: {baseline}")
    REPORTS.mkdir(exist_ok=True)

    figures=inventory_existing_figures(baseline)
    scripts=inventory_scripts(baseline)
    data=inventory_data(baseline)
    targets=figure_targets()
    tables=table_manifest()
    inserts=inspect_chapter_inserts()

    write_csv(REPORTS/"2026-07-23_pass7_existing_figure_inventory.csv", figures,
              ["relative_path","scope","extension","size_bytes","sha256","pre_pass_status"])
    write_csv(REPORTS/"2026-07-23_pass7_script_inventory.csv", scripts,
              ["relative_path","extension","status","size_bytes","sha256"])
    write_csv(REPORTS/"2026-07-23_pass7_raw_data_inventory.csv", data,
              ["relative_path","extension","classification","size_bytes","sha256"])
    write_csv(REPORTS/"2026-07-23_pass7_figure_target_status.csv", targets,
              ["target_id","chapter","target","status","output","script","command","source_basis","limitation"])
    write_csv(REPORTS/"2026-07-23_pass7_table_manifest.csv", tables,
              ["table_id","title","source_data","source_data_sha256","source_provenance","generated_output","generated_output_sha256","inserted_in","generation_command","manual_edit_permitted"])
    write_csv(REPORTS/"2026-07-23_pass7_chapter_asset_inserts.csv", inserts,
              ["chapter_path","line","inserted_asset"])

    ext_counts=Counter(r["extension"] for r in data)
    class_counts=Counter(r["classification"] for r in data)
    produced=[r for r in targets if r["status"].startswith("produced") or r["status"].startswith("reproduced")]
    blocked=[r for r in targets if r["status"]=="blocked"]

    inventory_md=[
        "# Pass 7 Figure, Script, and Data Inventory","",
        "Generated from the untouched Pass 6 source repository before Pass 7 production.","",
        "## Inventory totals","",
        f"- Existing manuscript/evidence figure assets: **{len(figures)}**.",
        f"- Existing plotting, rendering, composite, or postprocessing scripts: **{len(scripts)}**.",
        f"- Evidence data and metadata files: **{len(data)}**.",
        f"- Approved or partially approved figure targets produced: **{len(produced)}**.",
        f"- Figure targets remaining blocked: **{len(blocked)}**.",
        f"- Generated tables: **{len(tables)}**.","",
        "## Evidence-data file types","",
    ]
    inventory_md += md_table([{"extension":k,"count":v} for k,v in sorted(ext_counts.items())],["extension","count"],["Extension","Count"])
    inventory_md += ["","## Evidence-data classifications",""]
    inventory_md += md_table([{"classification":k,"count":v} for k,v in sorted(class_counts.items())],["classification","count"],["Classification","Count"])
    inventory_md += ["","## Detailed inventories","",
        "- `reports/2026-07-23_pass7_existing_figure_inventory.csv`",
        "- `reports/2026-07-23_pass7_script_inventory.csv`",
        "- `reports/2026-07-23_pass7_raw_data_inventory.csv`",
        "- `reports/2026-07-23_pass7_figure_target_status.csv`",
        "- `reports/2026-07-23_pass7_table_manifest.csv`",
        "- `figures/data/figure_manifest.csv`",
        "",
        "The data inventory records availability, not automatic permission for predictive use. Evidence-role and supersession rules remain controlling.",
    ]
    (REPORTS/"2026-07-23_pass7_figure_table_inventory.md").write_text("\n".join(inventory_md)+"\n",encoding="utf-8")

    blocked_md=["# Pass 7 Blocked Figure Targets","",
        "No blocked figure was approximated from missing coordinates, source traces, pressure planes, coefficients, or protected scores.",""]
    blocked_md += md_table(blocked,["target_id","chapter","target","source_basis","limitation"],["ID","Chapter","Target","Available basis","Blocking evidence"])
    blocked_md += ["","## Release rule","",
        "These targets may be produced only after the corresponding source data and provenance records are added to the controlling evidence map. Existing conceptual figures must not be relabeled as survey-grade or facility-specific maps.",]
    (REPORTS/"2026-07-23_pass7_blocked_targets.md").write_text("\n".join(blocked_md)+"\n",encoding="utf-8")

    regen=["# Pass 7 Regeneration Commands","",
        "Run from the repository root.","",
        "## Complete production set","","```bash","scripts/figures/rebuild_all.sh","```","",
        "## Individual figures","",
    ]
    for r in produced:
        regen += [f"### {r['target_id']}: {r['target']}","", "```bash",r["command"],"```",""]
    regen += ["## Generated Chapter 8 tables","","```bash","python3 scripts/figures/generate_pass7_tables.py","```","",
        "Exact source paths and SHA-256 hashes are recorded in `figures/data/figure_manifest.csv` and `reports/2026-07-23_pass7_table_manifest.csv`."]
    (REPORTS/"2026-07-23_pass7_regeneration_commands.md").write_text("\n".join(regen)+"\n",encoding="utf-8")

    report=["# Pass 7 Reproducible Figure and Table Production Report","",
        "Date: 2026-07-23 (America/Chicago)","",
        "## Production result","",
        f"Pass 7 produced **{len(produced)} approved figure targets** and **{len(tables)} generated Chapter 8 tables**. Numerical or geometric information was taken only from repository evidence cited in the manifests. Conceptual schematics are labeled as such and contain no inferred facility coordinates or unsupported closure coefficients.","",
        "## Produced figures","",
    ]
    report += md_table(produced,["target_id","chapter","target","output","limitation"],["ID","Chapter","Figure","Output","Evidence boundary"])
    report += ["","## Generated tables","",]
    report += md_table(tables,["table_id","title","source_data","generated_output","generation_command"],["ID","Table","Controlled CSV","Generated TeX","Command"])
    report += ["","## Reproducibility controls","",
        "- All new schematics and status figures are generated by `scripts/figures/generate_pass7_figures.py`.",
        "- The recirculation composite is rebuilt by the existing internal CFD-panel script and copied without manual image editing.",
        "- Every figure output and source file is hashed in `figures/data/figure_manifest.csv`.",
        "- Chapter 8 tables are generated from provenance-bearing CSV files; generated TeX is not manually edited.",
        "- `scripts/figures/rebuild_all.sh` regenerates the complete approved set.",
        "- Figures remain subordinate to the manuscript's evidence-role and predictive-input restrictions.",
        "",
        "## Blocked targets","",
    ]
    report += md_table(blocked,["target_id","chapter","target","limitation"],["ID","Chapter","Target","Reason blocked"])
    report += ["","## Chapter insertion audit","",
        f"The production pass inserted **{len(inserts)} generated assets**. Exact chapter paths and line numbers are recorded in `reports/2026-07-23_pass7_chapter_asset_inserts.csv`.","",
        "## Full inventories","",
        "See `reports/2026-07-23_pass7_figure_table_inventory.md` and the associated CSV files for all pre-existing figures, scripts, and evidence data available in the Pass 6 ZIP.",]
    (REPORTS/"2026-07-23_pass7_figure_table_production_report.md").write_text("\n".join(report)+"\n",encoding="utf-8")

    print(f"Inventoried {len(figures)} existing figure assets, {len(scripts)} scripts, and {len(data)} evidence data files.")
    print(f"Recorded {len(produced)} produced targets, {len(blocked)} blocked targets, and {len(tables)} generated tables.")


if __name__ == "__main__":
    main()
