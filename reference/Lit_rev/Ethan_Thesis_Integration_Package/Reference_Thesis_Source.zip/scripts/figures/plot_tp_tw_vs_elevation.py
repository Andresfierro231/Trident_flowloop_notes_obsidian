#!/usr/bin/env python3
"""Plot experimental centerline (TP) and wall (TW) temperatures vs elevation.

The default settings reproduce the Salt Test 2 plot:
- TP1-TP6: blue solid line with circular markers
- TW1-TW9 and TW11: green dashed line with square markers
- Elevation referenced to TP2 = 0 m
- TW10 omitted by default because the cooling-jacket shell temperature is far
  outside the temperature range of the other sensors.

Examples
--------
python plot_tp_tw_temperature_elevation.py
python plot_tp_tw_temperature_elevation.py --case salt1
python plot_tp_tw_temperature_elevation.py --case water4 --units C
python plot_tp_tw_temperature_elevation.py --include-tw10
python plot_tp_tw_temperature_elevation.py --output figures/tp_tw.png --show
"""

from __future__ import annotations

import argparse
from pathlib import Path
from typing import Final

import matplotlib.pyplot as plt


KELVIN_OFFSET: Final = 273.15

# Approximate sensor vertical coordinates from the loop geometry [m].
# The source coordinates use TP3 as y = 0. The plot shifts all coordinates so
# TP2 is at elevation 0 m, matching the reference figure.
Y_ABSOLUTE_M: Final[dict[str, float]] = {
    "TP1": 0.6016567809430090,
    "TP2": -0.3127432190569910,
    "TP3": 0.0,
    "TP4": 0.364236,
    "TP5": 0.550164,
    "TP6": 0.9144,
    "TW1": 0.3730567809430090,
    "TW2": 0.1444567809430090,
    "TW3": -0.0841432190569915,
    "TW4": -0.2345574142927440,
    "TW5": -0.1563716095284960,
    "TW6": -0.0781858047642479,
    "TW7": 0.182118,
    "TW8": 0.732282,
    "TW9": 0.8362141952357520,
    "TW10": 0.7580283904715040,
    "TW11": 0.6798425857072560,
}

TP2_DATUM_M: Final = Y_ABSOLUTE_M["TP2"]
ELEVATION_M: Final[dict[str, float]] = {
    sensor: y - TP2_DATUM_M for sensor, y in Y_ABSOLUTE_M.items()
}

# Experimental temperatures [K].
DATA_K: Final[dict[str, dict[str, float]]] = {
    "salt1": {
        "TP1": 449.37, "TP2": 443.27, "TP3": 441.37,
        "TP4": 446.41, "TP5": 447.50, "TP6": 452.53,
        "TW1": 440.00, "TW2": 441.57, "TW3": 440.97,
        "TW4": 442.26, "TW5": 465.38, "TW6": 461.07,
        "TW7": 448.31, "TW8": 446.75, "TW9": 446.73,
        "TW10": 390.03, "TW11": 444.87,
    },
    "salt2": {
        "TP1": 453.26, "TP2": 446.63, "TP3": 446.67,
        "TP4": 449.74, "TP5": 451.64, "TP6": 456.72,
        "TW1": 443.86, "TW2": 445.08, "TW3": 443.57,
        "TW4": 445.49, "TW5": 471.69, "TW6": 467.02,
        "TW7": 453.23, "TW8": 450.32, "TW9": 450.67,
        "TW10": 389.74, "TW11": 448.41,
    },
    "salt3": {
        "TP1": 465.81, "TP2": 458.52, "TP3": 459.32,
        "TP4": 462.57, "TP5": 463.65, "TP6": 466.47,
        "TW1": 455.00, "TW2": 456.08, "TW3": 454.90,
        "TW4": 458.00, "TW5": 485.59, "TW6": 480.13,
        "TW7": 464.84, "TW8": 461.67, "TW9": 462.49,
        "TW10": 399.09, "TW11": 460.55,
    },
    "salt4": {
        "TP1": 481.34, "TP2": 475.74, "TP3": 475.95,
        "TP4": 478.89, "TP5": 479.32, "TP6": 481.36,
        "TW1": 469.77, "TW2": 471.15, "TW3": 470.42,
        "TW4": 474.86, "TW5": 503.72, "TW6": 496.76,
        "TW7": 481.26, "TW8": 477.37, "TW9": 477.88,
        "TW10": 409.93, "TW11": 476.14,
    },
    "water1": {
        "TP1": 314.03, "TP2": 313.48, "TP3": 314.48,
        "TP4": 314.84, "TP5": 314.89, "TP6": 314.77,
        "TW1": 312.62, "TW2": 313.10, "TW3": 312.91,
        "TW4": 313.38, "TW5": 316.83, "TW6": 320.21,
        "TW7": 315.05, "TW8": 313.57, "TW9": 314.49,
        "TW10": 303.49, "TW11": 313.60,
    },
    "water2": {
        "TP1": 320.02, "TP2": 319.04, "TP3": 320.06,
        "TP4": 320.59, "TP5": 320.57, "TP6": 320.47,
        "TW1": 317.86, "TW2": 318.53, "TW3": 318.29,
        "TW4": 318.88, "TW5": 322.98, "TW6": 327.44,
        "TW7": 321.10, "TW8": 319.27, "TW9": 319.92,
        "TW10": 305.76, "TW11": 319.20,
    },
    "water3": {
        "TP1": 323.80, "TP2": 323.14, "TP3": 324.02,
        "TP4": 324.92, "TP5": 324.79, "TP6": 324.68,
        "TW1": 322.07, "TW2": 322.55, "TW3": 322.27,
        "TW4": 322.90, "TW5": 327.62, "TW6": 332.38,
        "TW7": 324.62, "TW8": 323.42, "TW9": 323.91,
        "TW10": 307.38, "TW11": 323.16,
    },
    "water4": {
        "TP1": 333.45, "TP2": 332.71, "TP3": 333.61,
        "TP4": 334.64, "TP5": 334.56, "TP6": 334.38,
        "TW1": 331.74, "TW2": 331.96, "TW3": 331.60,
        "TW4": 332.38, "TW5": 338.21, "TW6": 344.14,
        "TW7": 333.99, "TW8": 332.68, "TW9": 333.83,
        "TW10": 311.46, "TW11": 332.58,
    },
}

TP_ORDER: Final[list[str]] = ["TP1", "TP2", "TP3", "TP4", "TP5", "TP6"]
TW_ORDER_WITHOUT_SHELL: Final[list[str]] = [
    "TW1", "TW2", "TW3", "TW4", "TW5", "TW6",
    "TW7", "TW8", "TW9", "TW11", "TW1",
]
TW_ORDER_WITH_SHELL: Final[list[str]] = [
    "TW1", "TW2", "TW3", "TW4", "TW5", "TW6",
    "TW7", "TW8", "TW9", "TW10", "TW11", "TW1",
]

# Annotation offsets in screen points, tuned to resemble the original figure.
LABEL_OFFSETS: Final[dict[str, tuple[int, int]]] = {
    "TP1": (4, 3), "TP2": (4, -13), "TP3": (4, 2),
    "TP4": (4, 4), "TP5": (4, 4), "TP6": (4, 4),
    "TW1": (-27, 3), "TW2": (-24, 3), "TW3": (-25, 3),
    "TW4": (-22, -3), "TW5": (-24, 3), "TW6": (-24, 3),
    "TW7": (-23, 3), "TW8": (-23, 3), "TW9": (-23, 3),
    "TW10": (-26, 3), "TW11": (-27, 3),
}


def convert_temperature(value_k: float, units: str) -> float:
    return value_k if units == "K" else value_k - KELVIN_OFFSET


def automatic_xlim(
    temperatures: list[float],
    *,
    case: str,
    units: str,
    include_tw10: bool,
) -> tuple[float, float]:
    # Preserve the visible range of the reference Salt Test 2 figure.
    if case == "salt2" and units == "K" and not include_tw10:
        return 442.0, 473.0

    t_min = min(temperatures)
    t_max = max(temperatures)
    span = max(t_max - t_min, 1.0)
    margin = 0.08 * span
    return t_min - margin, t_max + margin


def create_plot(
    case: str,
    units: str,
    output: Path,
    *,
    include_tw10: bool = False,
    annotate: bool = True,
    show: bool = False,
) -> None:
    data_k = DATA_K[case]
    tw_order = TW_ORDER_WITH_SHELL if include_tw10 else TW_ORDER_WITHOUT_SHELL

    tp_x = [convert_temperature(data_k[s], units) for s in TP_ORDER]
    tp_y = [ELEVATION_M[s] for s in TP_ORDER]

    tw_x = [convert_temperature(data_k[s], units) for s in tw_order]
    tw_y = [ELEVATION_M[s] for s in tw_order]

    fig, ax = plt.subplots(figsize=(8.0, 5.4))

    ax.plot(
        tp_x,
        tp_y,
        "-o",
        color="blue",
        linewidth=1.8,
        markersize=5.5,
        label="TP",
    )
    ax.plot(
        tw_x,
        tw_y,
        "--s",
        color="green",
        linewidth=1.6,
        markersize=5.0,
        label="TW",
    )

    if annotate:
        for sensor, x, y in zip(TP_ORDER, tp_x, tp_y, strict=True):
            dx, dy = LABEL_OFFSETS[sensor]
            ax.annotate(
                sensor,
                (x, y),
                xytext=(dx, dy),
                textcoords="offset points",
                fontsize=9,
            )

        # Do not annotate the repeated closing TW1 point twice.
        for sensor, x, y in zip(tw_order[:-1], tw_x[:-1], tw_y[:-1], strict=True):
            dx, dy = LABEL_OFFSETS[sensor]
            ax.annotate(
                sensor,
                (x, y),
                xytext=(dx, dy),
                textcoords="offset points",
                fontsize=9,
            )

    visible_temperatures = tp_x + tw_x
    ax.set_xlim(
        *automatic_xlim(
            visible_temperatures,
            case=case,
            units=units,
            include_tw10=include_tw10,
        )
    )
    ax.set_ylim(-0.06, 1.26)

    ax.set_title("Temperature vs Elevation (Experiment)")
    ax.set_xlabel(f"Temperature ({units})")
    ax.set_ylabel("Elevation (m)")
    ax.legend(loc="upper right")
    ax.grid(False)

    fig.tight_layout()
    output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output, dpi=250, bbox_inches="tight")

    if show:
        plt.show()
    else:
        plt.close(fig)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Plot experimental TP and TW temperatures versus elevation."
    )
    parser.add_argument(
        "--case",
        choices=sorted(DATA_K),
        default="salt2",
        help="Experimental case to plot (default: %(default)s).",
    )
    parser.add_argument(
        "--units",
        choices=("K", "C"),
        default="K",
        help="Temperature units for the x-axis (default: %(default)s).",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=None,
        help="Output path. Default: tp_tw_temperature_elevation_<case>.png",
    )
    parser.add_argument(
        "--include-tw10",
        action="store_true",
        help="Include TW10, the cooling-jacket shell temperature.",
    )
    parser.add_argument(
        "--no-annotations",
        action="store_true",
        help="Do not label individual sensors.",
    )
    parser.add_argument(
        "--show",
        action="store_true",
        help="Open an interactive plot window after saving.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    output = args.output or Path(f"tp_tw_temperature_elevation_{args.case}.png")

    create_plot(
        case=args.case,
        units=args.units,
        output=output,
        include_tw10=args.include_tw10,
        annotate=not args.no_annotations,
        show=args.show,
    )
    print(f"Saved: {output.resolve()}")


if __name__ == "__main__":
    main()