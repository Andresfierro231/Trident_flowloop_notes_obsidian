#!/usr/bin/env python3
"""Compare the P1 nominal 1D heat ledger with matched CFD heat channels."""

from __future__ import annotations

import argparse
import csv
import math
from collections import defaultdict
from pathlib import Path


CASE_MAP = {
    "salt_1": "salt1_nominal",
    "salt_2": "salt2_jin_nominal",
    "salt_3": "salt3_jin_nominal",
    "salt_4": "salt4_nominal",
}
CHANNELS = ("heater", "cooler", "ordinary_ambient", "test_section", "junction")


def parse_args() -> argparse.Namespace:
    repo_root = Path(__file__).resolve().parents[1]
    default_ethan = repo_root.parents[2] / "ethan_runs"
    parser = argparse.ArgumentParser()
    parser.add_argument("--ethan-root", type=Path, default=default_ethan)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=repo_root / "evidence" / "heat_path_prediction_audit_2026_07_29",
    )
    return parser.parse_args()


def read_cfd_terms(path: Path) -> dict[str, dict[str, float]]:
    terms: dict[str, dict[str, float]] = defaultdict(dict)
    with path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            terms[row["case_key"]][row["term"]] = float(row["mean_W"])
    return terms


def read_p1_ledger(path: Path) -> dict[str, dict[str, float]]:
    totals: dict[str, dict[str, float]] = defaultdict(lambda: defaultdict(float))
    with path.open(newline="", encoding="utf-8") as handle:
        for row in csv.DictReader(handle):
            case_id = row["case_id"]
            if case_id not in CASE_MAP:
                continue
            if row["protected_target_used"].strip().lower() != "false":
                raise RuntimeError(f"protected target flag is not false for {case_id}")
            parent = row["parent_name"]
            q_source = float(row["Q_source_W"])
            q_hx = float(row["Q_hx_sink_W"])
            q_ambient = float(row["Q_ambient_W"])
            if parent == "heated_incline":
                totals[case_id]["heater"] += q_source
            if parent == "test_section":
                totals[case_id]["test_section"] += q_source - q_ambient
            else:
                totals[case_id]["ordinary_ambient"] += q_ambient
            totals[case_id]["cooler"] += q_hx
            totals[case_id]["junction"] = 0.0
    if set(totals) != set(CASE_MAP):
        raise RuntimeError(f"unexpected nominal cases: {sorted(totals)}")
    return totals


def cfd_channels(terms: dict[str, float]) -> dict[str, float]:
    return {
        "heater": terms["heater_to_fluid_W"],
        "cooler": -terms["cooler_to_fluid_W"],
        "ordinary_ambient": -sum(
            terms[name]
            for name in (
                "lower_transport_to_fluid_W",
                "downcomer_to_fluid_W",
                "upcomer_to_fluid_W",
                "upper_transport_to_fluid_W",
            )
        ),
        "test_section": terms["test_section_to_fluid_W"],
        "junction": -terms["junction_to_fluid_W"],
    }


def write_csv(path: Path, fieldnames: list[str], rows: list[dict[str, object]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    args = parse_args()
    source_root = args.ethan_root / "work_products" / "2026-07"
    p1_path = (
        source_root
        / "2026-07-28"
        / "2026-07-28_thesis_predictive_closure_campaign"
        / "candidate_runs"
        / "P1_shah_global008"
        / "segment_ledgers.csv"
    )
    cfd_path = (
        source_root
        / "2026-07-27"
        / "2026-07-27_predictive_1d_thesis_evidence"
        / "cfd_case_energy_terms_terminal10.csv"
    )
    p1 = read_p1_ledger(p1_path)
    cfd = read_cfd_terms(cfd_path)

    case_rows: list[dict[str, object]] = []
    errors: dict[str, list[tuple[float, float]]] = defaultdict(list)
    for case_id, cfd_case in CASE_MAP.items():
        observed = cfd_channels(cfd[cfd_case])
        for channel in CHANNELS:
            predicted = p1[case_id][channel]
            reference = observed[channel]
            error = predicted - reference
            errors[channel].append((predicted, reference))
            case_rows.append(
                {
                    "candidate_id": "P1_shah_global008",
                    "case_id": case_id,
                    "channel": channel,
                    "one_d_W": f"{predicted:.6f}",
                    "cfd_W": f"{reference:.6f}",
                    "signed_error_W": f"{error:.6f}",
                    "absolute_error_W": f"{abs(error):.6f}",
                    "absolute_percent_error": (
                        "" if channel == "test_section" else f"{100.0 * abs(error) / abs(reference):.6f}"
                    ),
                    "comparison_status": "nominal_post_solve_diagnostic",
                }
            )

    summary_rows: list[dict[str, object]] = []
    for channel in CHANNELS:
        pairs = errors[channel]
        mae = sum(abs(predicted - reference) for predicted, reference in pairs) / len(pairs)
        rmse = math.sqrt(
            sum((predicted - reference) ** 2 for predicted, reference in pairs) / len(pairs)
        )
        mape = sum(
            abs(predicted - reference) / abs(reference) for predicted, reference in pairs
        ) / len(pairs)
        summary_rows.append(
            {
                "candidate_id": "P1_shah_global008",
                "channel": channel,
                "case_count": len(pairs),
                "mae_W": f"{mae:.6f}",
                "rmse_W": f"{rmse:.6f}",
                "mape_percent": "" if channel == "test_section" else f"{100.0 * mape:.6f}",
                "interpretation": {
                    "heater": "moderate source-transfer mismatch",
                    "cooler": "large underprediction of active cooler removal",
                    "ordinary_ambient": "large overprediction caused by compensated global boundary",
                    "test_section": "use absolute error because the CFD target crosses zero",
                    "junction": "channel absent from P1",
                }[channel],
            }
        )

    args.output_dir.mkdir(parents=True, exist_ok=True)
    write_csv(
        args.output_dir / "channel_by_case.csv",
        [
            "candidate_id",
            "case_id",
            "channel",
            "one_d_W",
            "cfd_W",
            "signed_error_W",
            "absolute_error_W",
            "absolute_percent_error",
            "comparison_status",
        ],
        case_rows,
    )
    write_csv(
        args.output_dir / "channel_summary.csv",
        [
            "candidate_id",
            "channel",
            "case_count",
            "mae_W",
            "rmse_W",
            "mape_percent",
            "interpretation",
        ],
        summary_rows,
    )
    print(f"wrote {len(case_rows)} case-channel rows and {len(summary_rows)} summaries")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
