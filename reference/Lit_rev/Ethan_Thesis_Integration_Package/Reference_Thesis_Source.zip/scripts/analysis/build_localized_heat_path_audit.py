#!/usr/bin/env python3
"""Build the localized-model versus CFD heat-path attribution audit.

The paper-local inputs are compact copies or deterministic extracts of frozen
upstream ledgers.  The default action regenerates the result CSVs, publication
table, and figure without reading the Ethan workspace.  ``--refresh-inputs``
is the explicit provenance-preserving import path; ``--check`` validates the
retained inputs and calculations without changing files.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import shutil
import tempfile
from collections import defaultdict
from pathlib import Path
from typing import Iterable


ROOT = Path(__file__).resolve().parents[2]
EVIDENCE = ROOT / "evidence" / "localized_heat_path_audit_2026_08_10"
TABLE = ROOT / "tables" / "generated" / "localized_heat_path_summary.tex"
FIGURE = ROOT / "figures" / "pdf" / "localized_heat_path_comparison.pdf"

OBJECTIVES = (
    "experimental_mdot",
    "cfd_mdot_comparator",
)
OBJECTIVE_LABELS = {
    "experimental_mdot": r"localized $\alpha_R=0.60$",
    "cfd_mdot_comparator": r"localized $\alpha_R=1.10$",
}
CASE_ORDER = ("salt_1", "salt_2", "salt_3", "salt_4")
CASE_LABELS = {case: case.replace("salt_", "Salt") for case in CASE_ORDER}
CFD_CASE_MAP = {
    "salt1_nominal": "salt_1",
    "salt2_jin_nominal": "salt_2",
    "salt3_jin_nominal": "salt_3",
    "salt4_nominal": "salt_4",
}
JUNCTION_ORDER = ("lower_left", "lower_right", "upper_left", "upper_right")
JUNCTION_LABELS = {
    "lower_left": "lower left",
    "lower_right": "lower right",
    "upper_left": "upper left",
    "upper_right": "upper right",
}
PARENT_TO_JUNCTION = {
    "bottom_horizontal_exit": "lower_left",
    "bottom_horizontal_inlet": "lower_right",
    "top_horizontal_inlet": "upper_left",
    "top_horizontal_exit": "upper_right",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    default_upstream = ROOT.parents[2] / "ethan_runs"
    parser.add_argument("--upstream-root", type=Path, default=default_upstream)
    parser.add_argument(
        "--refresh-inputs",
        action="store_true",
        help="refresh compact inputs from the read-only Ethan work products",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="validate sources and regenerate into a temporary directory",
    )
    return parser.parse_args()


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, fieldnames: Iterable[str], rows: Iterable[dict[str, object]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(fieldnames), lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def source_paths(upstream: Path) -> dict[str, Path]:
    base = upstream / "work_products" / "2026-07"
    return {
        "cfd_nominal": (
            base
            / "2026-07-28"
            / "2026-07-28_thesis_pressure_heat_source_sink_narrative"
            / "nominal_heat_source_sink_summary.csv"
        ),
        "localized_heat": (
            base
            / "2026-07-31"
            / "2026-07-31_localized_two_coordinate_predictive_model"
            / "frozen_heat_ledger.csv"
        ),
        "cfd_junction": (
            base
            / "2026-07-16"
            / "2026-07-16_junction_split_heat_ledger_and_model_gate"
            / "junction_split_heat_ledger.csv"
        ),
        "cfd_junction_salt1": (
            upstream
            / "work_products"
            / "2026-08"
            / "2026-08-10"
            / "2026-08-10_salt1_junction_heat_postprocess"
            / "salt1_junction_split_heat_ledger.csv"
        ),
        "localized_raw": (
            base
            / "2026-07-31"
            / "2026-07-31_localized_two_coordinate_predictive_model"
            / "raw_runs"
        ),
    }


def repo_uri(upstream: Path, path: Path) -> str:
    return "repo://ethan_runs/" + path.relative_to(upstream).as_posix()


def refresh_inputs(upstream: Path) -> None:
    paths = source_paths(upstream)
    EVIDENCE.mkdir(parents=True, exist_ok=True)
    copies = {
        paths["cfd_nominal"]: EVIDENCE / "cfd_nominal_heat_source_sink_summary.csv",
        paths["localized_heat"]: EVIDENCE / "localized_frozen_heat_ledger.csv",
    }
    manifest: list[dict[str, object]] = []
    for source, destination in copies.items():
        if not source.is_file():
            raise FileNotFoundError(source)
        shutil.copyfile(source, destination)
        manifest.append(
            {
                "source_uri": repo_uri(upstream, source),
                "source_sha256": sha256(source),
                "local_artifact": destination.relative_to(ROOT).as_posix(),
                "transform": "byte_exact_copy",
            }
        )

    junction_fields = (
        "case_key",
        "case_id",
        "source_id",
        "physical_junction_bucket",
        "realized_external_loss_positive_W",
        "fraction_of_case_junction_loss",
        "source_path",
    )
    junction_rows: list[dict[str, object]] = []
    for source in (paths["cfd_junction"], paths["cfd_junction_salt1"]):
        if not source.is_file():
            raise FileNotFoundError(source)
        selected = [
            row
            for row in read_csv(source)
            if row.get("case_id") in CASE_ORDER
            and row.get("physical_junction_bucket") in JUNCTION_ORDER
        ]
        if len(selected) not in (4, 12):
            raise RuntimeError(
                f"expected 4 or 12 physical junction rows in {source}; found {len(selected)}"
            )
        junction_rows.extend(
            {field: row.get(field, "") for field in junction_fields}
            for row in selected
        )
        manifest.append(
            {
                "source_uri": repo_uri(upstream, source),
                "source_sha256": sha256(source),
                "local_artifact": (
                    "evidence/localized_heat_path_audit_2026_08_10/"
                    "cfd_junction_split_heat_ledger.csv"
                ),
                "transform": "select_physical_junction_rows_and_concatenate",
            }
        )
    write_csv(
        EVIDENCE / "cfd_junction_split_heat_ledger.csv",
        junction_fields,
        junction_rows,
    )

    extracted: list[dict[str, object]] = []
    run_tags = {
        "experimental_mdot": "r0p600",
        "cfd_mdot_comparator": "r1p100",
    }
    for objective in OBJECTIVES:
        for case_id in CASE_ORDER:
            case_number = case_id.split("_")[1]
            source = (
                paths["localized_raw"]
                / f"RW_outer_bridge2p500_{run_tags[objective]}__rad__coupled__salt_{case_number}.json"
            )
            payload = json.loads(source.read_text(encoding="utf-8"))
            source_hash = sha256(source)
            selected = [
                row
                for row in payload["segments"]
                if row["parent_name"] in PARENT_TO_JUNCTION
                and float(row.get("radial_junction_W", 0.0)) > 0.0
            ]
            if len(selected) != 4:
                raise RuntimeError(f"expected four junction hosts in {source}; found {len(selected)}")
            for row in selected:
                local_added = float(row["radial_junction_W"])
                residual_bridge = float(row["radial_residual_bridge_W"])
                total_region = float(row["Q_ambient_W"])
                extracted.append(
                    {
                        "objective_label": objective,
                        "case_id": case_id,
                        "model_parent": row["parent_name"],
                        "physical_junction_bucket": PARENT_TO_JUNCTION[row["parent_name"]],
                        "local_outer_wall_K": f"{float(row['radial_outer_wall_K']):.15g}",
                        "ordinary_host_sink_W": f"{total_region - local_added:.15g}",
                        "setup_junction_sink_W": f"{local_added - residual_bridge:.15g}",
                        "residual_bridge_sink_W": f"{residual_bridge:.15g}",
                        "total_junction_region_sink_W": f"{total_region:.15g}",
                        "source_uri": repo_uri(upstream, source),
                        "source_json_sha256": source_hash,
                    }
                )
            manifest.append(
                {
                    "source_uri": repo_uri(upstream, source),
                    "source_sha256": source_hash,
                    "local_artifact": (
                        "evidence/localized_heat_path_audit_2026_08_10/"
                        "localized_junction_region_source.csv"
                    ),
                    "transform": "extract_four_predeclared_junction_host_rows",
                }
            )

    write_csv(
        EVIDENCE / "localized_junction_region_source.csv",
        [
            "objective_label",
            "case_id",
            "model_parent",
            "physical_junction_bucket",
            "local_outer_wall_K",
            "ordinary_host_sink_W",
            "setup_junction_sink_W",
            "residual_bridge_sink_W",
            "total_junction_region_sink_W",
            "source_uri",
            "source_json_sha256",
        ],
        extracted,
    )
    write_csv(
        EVIDENCE / "SOURCE_MANIFEST.csv",
        ["source_uri", "source_sha256", "local_artifact", "transform"],
        manifest,
    )


def load_inputs(base: Path = EVIDENCE) -> tuple[
    dict[str, dict[str, float]],
    dict[tuple[str, str], dict[str, float]],
    dict[tuple[str, str], dict[str, float]],
    dict[tuple[str, str, str], dict[str, float]],
]:
    cfd: dict[str, dict[str, float]] = {}
    for row in read_csv(base / "cfd_nominal_heat_source_sink_summary.csv"):
        case_id = CFD_CASE_MAP.get(row["case_key"])
        if case_id:
            cfd[case_id] = {
                "cooler": float(row["cooler_removal_mean_W"]),
                "ordinary": float(row["ambient_wall_loss_mean_W"]),
                "junction": float(row["junction_stub_loss_mean_W"]),
            }

    localized: dict[tuple[str, str], dict[str, float]] = {}
    for row in read_csv(base / "localized_frozen_heat_ledger.csv"):
        key = (row["objective_label"], row["case_id"])
        if (
            row["objective_label"] in OBJECTIVES
            and row["case_id"] in CASE_ORDER
            and row["split"] == "frozen_nominal_reproducibility"
        ):
            setup = float(row["setup_junction_sink_W"])
            bridge = float(row["residual_bridge_sink_W"])
            localized[key] = {
                "cooler": float(row["cooler_sink_W"]),
                "ordinary": float(row["ordinary_ambient_sink_W"]),
                "setup": setup,
                "bridge": bridge,
                "added_local": setup + bridge,
            }

    model_regions: dict[tuple[str, str], dict[str, float]] = defaultdict(dict)
    for row in read_csv(base / "localized_junction_region_source.csv"):
        key = (row["objective_label"], row["case_id"])
        model_regions[key][row["physical_junction_bucket"]] = float(
            row["total_junction_region_sink_W"]
        )

    cfd_regions: dict[tuple[str, str, str], dict[str, float]] = {}
    for row in read_csv(base / "cfd_junction_split_heat_ledger.csv"):
        bucket = row["physical_junction_bucket"]
        if row["case_id"] in CASE_ORDER and bucket in JUNCTION_ORDER:
            cfd_regions[(row["case_id"], bucket, "cfd")] = {
                "W": float(row["realized_external_loss_positive_W"]),
                "fraction": float(row["fraction_of_case_junction_loss"]),
            }

    expected_cases = set(CASE_ORDER)
    if set(cfd) != expected_cases:
        raise RuntimeError(f"CFD cases do not match nominal set: {sorted(cfd)}")
    expected_localized = {(objective, case) for objective in OBJECTIVES for case in CASE_ORDER}
    if set(localized) != expected_localized or set(model_regions) != expected_localized:
        raise RuntimeError("localized nominal cases or regional rows are incomplete")
    return cfd, localized, model_regions, cfd_regions


def mean(values: Iterable[float]) -> float:
    values = list(values)
    return sum(values) / len(values)


def build_results(base: Path = EVIDENCE) -> tuple[list[dict[str, object]], ...]:
    cfd, localized, model_regions, cfd_regions = load_inputs(base)
    case_rows: list[dict[str, object]] = []
    comparison_rows: list[dict[str, object]] = []
    junction_rows: list[dict[str, object]] = []
    junction_summary: list[dict[str, object]] = []

    paths = {
        "cooler": ("cooler", "cooler"),
        "ordinary_attribution": ("ordinary", "ordinary"),
        "setup_GJ_decomposition": ("setup", "junction"),
        "residual_GB_decomposition": ("bridge", "junction"),
        "added_local_GJ_plus_GB": ("added_local", "junction"),
        "junction_region_total": ("junction_region", "junction"),
    }
    for objective in OBJECTIVES:
        pairs: dict[str, list[tuple[float, float]]] = defaultdict(list)
        for case_id in CASE_ORDER:
            model = localized[(objective, case_id)]
            reference = cfd[case_id]
            model_region_total = sum(model_regions[(objective, case_id)].values())
            model_shared_total = model["cooler"] + model["ordinary"] + model["added_local"]
            cfd_shared_total = reference["cooler"] + reference["ordinary"] + reference["junction"]
            case_rows.append(
                {
                    "objective_label": objective,
                    "case_id": case_id,
                    "cfd_cooler_sink_W": f"{reference['cooler']:.6f}",
                    "cfd_ordinary_ambient_sink_W": f"{reference['ordinary']:.6f}",
                    "cfd_junction_stub_sink_W": f"{reference['junction']:.6f}",
                    "localized_cooler_sink_W": f"{model['cooler']:.6f}",
                    "localized_ordinary_ambient_sink_W": f"{model['ordinary']:.6f}",
                    "localized_setup_GJ_sink_W": f"{model['setup']:.6f}",
                    "localized_residual_GB_sink_W": f"{model['bridge']:.6f}",
                    "localized_added_GJ_plus_GB_sink_W": f"{model['added_local']:.6f}",
                    "localized_junction_region_total_sink_W": f"{model_region_total:.6f}",
                    "cfd_cooler_share": f"{reference['cooler'] / cfd_shared_total:.9f}",
                    "cfd_ordinary_share": f"{reference['ordinary'] / cfd_shared_total:.9f}",
                    "cfd_junction_share": f"{reference['junction'] / cfd_shared_total:.9f}",
                    "localized_cooler_share": f"{model['cooler'] / model_shared_total:.9f}",
                    "localized_ordinary_share": f"{model['ordinary'] / model_shared_total:.9f}",
                    "localized_added_local_share": f"{model['added_local'] / model_shared_total:.9f}",
                    "comparison_status": "post_solve_attribution_diagnostic_nonidentical_source_and_patch_QOIs",
                }
            )
            model_with_region = {**model, "junction_region": model_region_total}
            for name, (model_key, cfd_key) in paths.items():
                pairs[name].append((model_with_region[model_key], reference[cfd_key]))

        for name, values in pairs.items():
            comparison_rows.append(
                {
                    "objective_label": objective,
                    "comparison": name,
                    "case_count": len(values),
                    "model_min_W": f"{min(x for x, _ in values):.6f}",
                    "model_max_W": f"{max(x for x, _ in values):.6f}",
                    "cfd_min_W": f"{min(y for _, y in values):.6f}",
                    "cfd_max_W": f"{max(y for _, y in values):.6f}",
                    "mean_model_to_cfd_ratio": f"{mean(x / y for x, y in values):.6f}",
                    "mape_percent": f"{100.0 * mean(abs(x - y) / y for x, y in values):.6f}",
                    "mean_signed_bias_W": f"{mean(x - y for x, y in values):.6f}",
                    "claim_boundary": "attribution diagnostic; not strict component validation",
                }
            )

        tvd_values: list[float] = []
        for case_id in CASE_ORDER:
            model_total = sum(model_regions[(objective, case_id)].values())
            tvd = 0.0
            for bucket in JUNCTION_ORDER:
                cfd_row = cfd_regions[(case_id, bucket, "cfd")]
                model_w = model_regions[(objective, case_id)][bucket]
                model_fraction = model_w / model_total
                tvd += abs(model_fraction - cfd_row["fraction"])
                junction_rows.append(
                    {
                        "objective_label": objective,
                        "case_id": case_id,
                        "physical_junction_bucket": bucket,
                        "cfd_sink_W": f"{cfd_row['W']:.6f}",
                        "localized_region_sink_W": f"{model_w:.6f}",
                        "model_to_cfd_ratio": f"{model_w / cfd_row['W']:.6f}",
                        "cfd_fraction": f"{cfd_row['fraction']:.9f}",
                        "localized_fraction": f"{model_fraction:.9f}",
                        "fraction_difference_percentage_points": f"{100.0 * (model_fraction - cfd_row['fraction']):.6f}",
                        "comparison_status": "different_spatial_footprints_and_CFD_time_windows",
                    }
                )
            tvd_values.append(0.5 * tvd)
        for bucket in JUNCTION_ORDER:
            rows = [
                row
                for row in junction_rows
                if row["objective_label"] == objective
                and row["physical_junction_bucket"] == bucket
            ]
            junction_summary.append(
                {
                    "objective_label": objective,
                    "physical_junction_bucket": bucket,
                    "mean_cfd_fraction": f"{mean(float(row['cfd_fraction']) for row in rows):.9f}",
                    "mean_localized_fraction": f"{mean(float(row['localized_fraction']) for row in rows):.9f}",
                    "mean_fraction_difference_percentage_points": f"{mean(float(row['fraction_difference_percentage_points']) for row in rows):.6f}",
                    "mean_total_variation_distance": "",
                }
            )
        junction_summary.append(
            {
                "objective_label": objective,
                "physical_junction_bucket": "all_junctions",
                "mean_cfd_fraction": "1.000000000",
                "mean_localized_fraction": "1.000000000",
                "mean_fraction_difference_percentage_points": "0.000000",
                "mean_total_variation_distance": f"{mean(tvd_values):.9f}",
            }
        )
    return case_rows, comparison_rows, junction_rows, junction_summary


def write_results(output: Path = EVIDENCE) -> tuple[list[dict[str, object]], ...]:
    results = build_results(EVIDENCE)
    case_rows, comparison_rows, junction_rows, junction_summary = results
    write_csv(output / "heat_path_case_comparison.csv", case_rows[0].keys(), case_rows)
    write_csv(output / "heat_path_summary_metrics.csv", comparison_rows[0].keys(), comparison_rows)
    write_csv(output / "junction_region_comparison.csv", junction_rows[0].keys(), junction_rows)
    write_csv(output / "junction_distribution_summary.csv", junction_summary[0].keys(), junction_summary)
    return results


def range_text(values: list[float]) -> str:
    return f"{min(values):.1f}--{max(values):.1f}"


def write_latex_table(case_rows: list[dict[str, object]], path: Path = TABLE) -> None:
    primary = [row for row in case_rows if row["objective_label"] == "experimental_mdot"]
    rows = [
        (
            "Active cooler",
            [float(row["cfd_cooler_sink_W"]) for row in primary],
            [float(row["localized_cooler_sink_W"]) for row in primary],
        ),
        (
            "Ordinary ambient attribution",
            [float(row["cfd_ordinary_ambient_sink_W"]) for row in primary],
            [float(row["localized_ordinary_ambient_sink_W"]) for row in primary],
        ),
        (
            "Junction-region attribution",
            [float(row["cfd_junction_stub_sink_W"]) for row in primary],
            [float(row["localized_junction_region_total_sink_W"]) for row in primary],
        ),
    ]
    lines = [
        r"\begin{table}[tbp]",
        r"\centering",
        r"\scriptsize",
        r"\caption[Localized-model heat-loss attribution]{Nominal Salt1--Salt4 heat-loss attribution for CFD and the localized low-resistance model.  Ratios compare post-solve attribution buckets, not identical component measurements: the CFD values are realized wall-flux groups, whereas the model uses its solved boundary circuit and a broader junction-host assignment.}",
        r"\label{tab:localized-heat-path-audit}",
        r"\begin{tabularx}{\textwidth}{@{}>{\raggedright\arraybackslash}Xrrr@{}}",
        r"\toprule",
        r"Loss attribution & CFD range (W) & Localized range (W) & Mean model/CFD \\",
        r"\midrule",
    ]
    for label, cfd_values, model_values in rows:
        lines.append(
            f"{label} & {range_text(cfd_values)} & {range_text(model_values)} & "
            f"{mean(m / c for m, c in zip(model_values, cfd_values)):.2f} \\\\"
        )
    lines.extend([r"\bottomrule", r"\end{tabularx}", r"\end{table}", ""])
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def write_figure(
    case_rows: list[dict[str, object]],
    junction_rows: list[dict[str, object]],
    path: Path = FIGURE,
) -> None:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.patches import Patch

    primary = [row for row in case_rows if row["objective_label"] == "experimental_mdot"]
    primary_junction = [
        row for row in junction_rows if row["objective_label"] == "experimental_mdot"
    ]
    colors = {"cooler": "#3274a1", "ordinary": "#e1812c", "junction": "#c44e52"}
    corner_colors = {
        "lower_left": "#4c72b0",
        "lower_right": "#55a868",
        "upper_left": "#c44e52",
        "upper_right": "#8172b2",
    }
    fig, axes = plt.subplots(2, 1, figsize=(8.4, 7.1), constrained_layout=True)

    ax = axes[0]
    width = 0.34
    centers = list(range(len(CASE_ORDER)))
    for offset, system in ((-width / 2, "CFD"), (width / 2, "Localized")):
        bottom = [0.0] * len(CASE_ORDER)
        for key, label in (("cooler", "Cooler"), ("ordinary", "Ordinary ambient"), ("junction", "Junction/local")):
            if system == "CFD":
                field = {
                    "cooler": "cfd_cooler_share",
                    "ordinary": "cfd_ordinary_share",
                    "junction": "cfd_junction_share",
                }[key]
            else:
                field = {
                    "cooler": "localized_cooler_share",
                    "ordinary": "localized_ordinary_share",
                    "junction": "localized_added_local_share",
                }[key]
            values = [100.0 * float(row[field]) for row in primary]
            x_values = [center + offset for center in centers]
            ax.bar(
                x_values,
                values,
                width,
                bottom=bottom,
                color=colors[key],
                edgecolor="black",
                linewidth=0.35,
                hatch="" if system == "CFD" else "//",
                label=label if system == "CFD" else None,
            )
            for x, base, value in zip(x_values, bottom, values):
                ax.text(
                    x,
                    base + value / 2.0,
                    f"{value:.1f}%",
                    ha="center",
                    va="center",
                    fontsize=6.3,
                    color="white" if value >= 10.0 else "black",
                    fontweight="semibold" if value >= 10.0 else "normal",
                )
            bottom = [a + b for a, b in zip(bottom, values)]
        if any(not math.isclose(value, 100.0, rel_tol=0.0, abs_tol=5e-7) for value in bottom):
            raise RuntimeError(f"normalized {system} sink stacks do not close to 100%: {bottom}")
    ax.set_xticks(centers, [CASE_LABELS[case] for case in CASE_ORDER])
    ax.set_ylim(0, 100)
    ax.set_ylabel("Share of each ledger's compared sinks (%)")
    ax.set_title("(a) Normalized sink shares; each stack = 100%")
    ax.grid(axis="y", alpha=0.25)
    ax.legend(
        handles=[
            Patch(facecolor=colors["cooler"], edgecolor="black", label="Cooler"),
            Patch(facecolor=colors["ordinary"], edgecolor="black", label="Ordinary ambient"),
            Patch(facecolor=colors["junction"], edgecolor="black", label="Junction/local"),
            Patch(facecolor="white", edgecolor="black", label="CFD"),
            Patch(facecolor="white", edgecolor="black", hatch="//", label="Localized"),
        ],
        ncol=1,
        frameon=False,
        loc="center left",
        bbox_to_anchor=(1.01, 0.5),
        fontsize=7.5,
    )

    ax = axes[1]
    cases = CASE_ORDER
    pair_centers: list[float] = []
    pair_labels: list[str] = []
    for index, case_id in enumerate(cases):
        pair_centers.extend([2.5 * index, 2.5 * index + 0.85])
        pair_labels.extend(["CFD", "Localized"])
    bottoms = [0.0] * len(pair_centers)
    lookup = {
        (row["case_id"], row["physical_junction_bucket"]): row
        for row in primary_junction
    }
    for bucket in JUNCTION_ORDER:
        values: list[float] = []
        for case_id in cases:
            row = lookup[(case_id, bucket)]
            values.extend([100.0 * float(row["cfd_fraction"]), 100.0 * float(row["localized_fraction"])])
        ax.bar(
            pair_centers,
            values,
            0.72,
            bottom=bottoms,
            color=corner_colors[bucket],
            edgecolor="black",
            linewidth=0.35,
            label=JUNCTION_LABELS[bucket].title(),
        )
        for x, base, value in zip(pair_centers, bottoms, values):
            ax.text(
                x,
                base + value / 2.0,
                f"{value:.1f}%",
                ha="center",
                va="center",
                fontsize=6.3,
                color="white",
                fontweight="semibold",
            )
        bottoms = [a + b for a, b in zip(bottoms, values)]
    ax.set_xticks(pair_centers, pair_labels, rotation=25)
    for index, case_id in enumerate(cases):
        ax.text(2.5 * index + 0.425, -15.5, CASE_LABELS[case_id], ha="center", va="top")
    ax.set_ylim(0, 100)
    ax.set_ylabel("Share of junction-region loss (%)")
    ax.set_title("(b) Four-junction distribution")
    ax.grid(axis="y", alpha=0.25)
    ax.legend(ncol=1, frameon=False, loc="center left", bbox_to_anchor=(1.02, 0.5))
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(
        path,
        bbox_inches="tight",
        metadata={"Creator": "build_localized_heat_path_audit.py", "CreationDate": None, "ModDate": None},
    )
    plt.close(fig)


def validate_sources(base: Path = EVIDENCE) -> list[str]:
    problems: list[str] = []
    manifest_path = base / "SOURCE_MANIFEST.csv"
    if not manifest_path.is_file():
        return [f"missing {manifest_path}"]
    for row in read_csv(manifest_path):
        local = row["local_artifact"]
        if row["transform"] != "byte_exact_copy":
            continue
        path = ROOT / local
        if not path.is_file():
            problems.append(f"missing local input {local}")
        elif sha256(path) != row["source_sha256"]:
            problems.append(f"hash mismatch for {local}")

    try:
        _, localized, model_regions, cfd_regions = load_inputs(base)
        for objective in OBJECTIVES:
            for case_id in CASE_ORDER:
                regional_added = 0.0
                for row in read_csv(base / "localized_junction_region_source.csv"):
                    if row["objective_label"] == objective and row["case_id"] == case_id:
                        regional_added += float(row["setup_junction_sink_W"]) + float(
                            row["residual_bridge_sink_W"]
                        )
                if not math.isclose(
                    regional_added,
                    localized[(objective, case_id)]["added_local"],
                    rel_tol=0.0,
                    abs_tol=1e-9,
                ):
                    problems.append(f"regional localized ledger does not close for {objective}/{case_id}")
                if set(model_regions[(objective, case_id)]) != set(JUNCTION_ORDER):
                    problems.append(f"incomplete model junction set for {objective}/{case_id}")
        for case_id in CASE_ORDER:
            split_total = sum(cfd_regions[(case_id, bucket, "cfd")]["W"] for bucket in JUNCTION_ORDER)
            # The split ledger uses a different terminal wall-flux sample than
            # the final-ten nominal mean; only a tight consistency check is valid.
            nominal = load_inputs(base)[0][case_id]["junction"]
            if abs(split_total - nominal) / nominal > 0.005:
                problems.append(f"CFD split/nominal junction mismatch exceeds 0.5% for {case_id}")
    except Exception as exc:  # report all structural failures through --check
        problems.append(str(exc))
    return problems


def main() -> int:
    args = parse_args()
    if args.refresh_inputs:
        refresh_inputs(args.upstream_root.resolve())
    problems = validate_sources()
    if problems:
        for problem in problems:
            print(f"FAIL: {problem}")
        return 1

    if args.check:
        with tempfile.TemporaryDirectory(prefix="localized_heat_path_check_") as temp:
            temp_path = Path(temp)
            results = write_results(temp_path)
            write_latex_table(results[0], temp_path / "localized_heat_path_summary.tex")
            write_figure(results[0], results[2], temp_path / "localized_heat_path_comparison.pdf")
            if not all((temp_path / name).is_file() for name in (
                "heat_path_case_comparison.csv",
                "heat_path_summary_metrics.csv",
                "junction_region_comparison.csv",
                "junction_distribution_summary.csv",
                "localized_heat_path_summary.tex",
                "localized_heat_path_comparison.pdf",
            )):
                print("FAIL: temporary regeneration is incomplete")
                return 1
        print("PASS: source hashes, ledger closure, calculations, table, and figure")
        return 0

    results = write_results(EVIDENCE)
    write_latex_table(results[0], TABLE)
    write_figure(results[0], results[2], FIGURE)
    print(f"wrote audit outputs under {EVIDENCE.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
