# Two-state upcomer paper integration

Date: 2026-08-02  
Task: `csem-two-state-paper-integration-2026-08-02`  
Status: manuscript integrated; physical admission remains fail-closed

## Outcome

Chapters 1, 4, 5, and 6 now carry the implementation-ready two-state story:
motivation and objective; governing mass, area-aware momentum, and two-state
energy equations; source and exchange terms; top-turnaround and bottom-mixing
conditions; one-way wall treatment; discretization and direct linear solve;
frozen runtime and future split; complete nominal TP/TW/experimental-mdot/
CFD-mdot tables; boundary and mechanism falsifications; pressure leverage;
grid and uncertainty limits; and the bounded conclusion.

The result is deliberately negative.  The closed reverse-advected BVP is
numerically valid but does not retain the earlier nested-reservoir TP/TW gain.
The area-aware momentum term remains a bounded hydraulic contribution.  No
two-state exchange coefficient or physical closure is admitted.

## Manuscript placement

| Content | Manuscript location |
|---|---|
| Motivation, objective, contribution, organization | `chapters/01_introduction.tex` |
| Governing equations, source/exchange terms, boundaries, numerics, frozen split | `chapters/04_reduced_model_methodology.tex`, `subsec:two-state-upcomer-method` and `subsec:two-state-numerics` |
| Complete aggregate and casewise scores | `chapters/05_model_assessment_and_interpretation.tex`, `sec:two-state-results` |
| Native profiles and pressure-leverage figures | same Chapter 5 section and `sec:two-state-pressure-leverage` |
| Rejected mechanisms, uncertainty, and admission limits | Chapter 5 rejected-forms section and two-state results |
| Research-question answer, conclusions, limitations, next experiments | `chapters/06_conclusions.tex` |
| Symbols and units | `chapters/appendix_nomenclature.tex` |

## Equation and nomenclature inventory

| Item | Meaning and unit | Implementation source |
|---|---|---|
| `mdot+ = mdot(1+r)`, `mdot- = mdot r` | Forward/reverse mass magnitudes, kg/s; exact net-mass identity | `tools/analyze/run_two_state_predictivity_campaign.py:408-414` |
| `Phi_A=(1+r)^2/(1-alpha)+r^2/alpha` | Dimensionless upcomer momentum multiplier | `tools/analyze/run_two_state_upcomer_physics_campaign.py:217-228` |
| `Qnet=Qsource-Qhx-Qamb` | Target-free host cell heat, W | `tools/analyze/run_two_state_predictivity_campaign.py:416-423` |
| Forward/reverse energy balances | Countercurrent axial energy transport with equal/opposite exchange | `tools/analyze/run_two_state_predictivity_campaign.py:433-446` |
| `UA_i=chi mdot cp_i Delta-z_i/L_up` | Cell exchange conductance, W/K | `tools/analyze/run_two_state_predictivity_campaign.py:425` |
| `T-(L)=T+(L)` | Top turnaround | `tools/analyze/run_two_state_predictivity_campaign.py:448-451` |
| `mdot+T+(0)-mdot-T-(0)=mdot Tnet(0)` | Bottom temperature-form enthalpy mixing on frozen common-`cp` basis | `tools/analyze/run_two_state_predictivity_campaign.py:452-459` |
| `r`, `alpha`, `chi` | Dimensionless reverse-mass, reverse-area, and exchange design coordinates | `FROZEN_PREDICTIVITY_CONTRACT.json` |

The selected nominal mechanism coordinates are `r=0.02`, `alpha=0.15`, and
`chi=0.02`; `chi=0` is the exchange ablation and `chi=0.04` is a stress row.
They are not parameter confidence bounds.  The selected area multiplier is
`1.2266667`.  The current state uses 51 host upcomer cells.  The exact
acceptance tolerances and contract hash are in the local compact contract.

## Claim-to-evidence ledger

| ID | Manuscript claim | Exact controlling artifact | Boundary |
|---|---|---|---|
| TS-01 | The runtime model is target-free and all 68 ranks terminated before target join. | `evidence/two_state_paper_integration_2026_08_02/frozen_run_matrix.csv`; `FROZEN_PREDICTIVITY_CONTRACT.json`; `RIGOROUS_PREDICTIVITY_DECISION.json` | Nominal retrospective mechanism campaign only. |
| TS-02 | The closed BVP conserves mass/energy and closes turnaround and bottom mixing. | `evidence/two_state_paper_integration_2026_08_02/native_bvp_gates.csv` | Numerical validity, not physical admission. |
| TS-03 | Closed selected TP/TW is 8.005/10.507 K and mdot MAPE is 11.927/39.972%. | `audience_model_tp_tw_mdot_scorecard.csv`; refreshed complete case values in `../evidence/cfd_mdot_salt1_4_refresh_2026_08_03/two_state_case_scorecard_salt1_4.csv` | CFD mdot uses canonical terminal Salt1--Salt4 means in a post-solve no-refit refresh; TW uses the declared exclusion policy. |
| TS-04 | The earlier nested thermal gain is superseded. | `mechanism_model_comparison.csv`; `RIGOROUS_PREDICTIVITY_DECISION.json` | Area-aware momentum result remains valid. |
| TS-05 | The lower-error fixed-inlet row is rejected by a 0.00545--0.00870 kg K/s mixing residual. | `boundary_condition_falsification.csv` | Falsification row; never a candidate. |
| TS-06 | Only TP3 improves on average; TP4--TP6 and TW7--TW8 worsen. | `native_sensor_direction_audit.csv` | Sensors outside the upcomer are unchanged. |
| TS-07 | Grid coarsening does not explain the negative thermal decision. | `native_bvp_grid_convergence.csv` | Applies to the task-owned BVP state, not CFD-QOI mesh UQ. |
| TS-08 | Aggregate minor loss has greatest local mdot leverage; upcomer-only target multipliers are implausibly large. | `component_pressure_sensitivity_summary.csv`; `hydraulic_target_requirement_summary.csv` | Sensitivity/extrapolation, not coefficient fit. |
| TS-09 | The decreasing-friction row is diagnostic because temperature dependence is already carried through properties/Re/buoyancy. | `decreasing_fT_double_count_audit.csv` | Requires independent recirculation observables before promotion. |

Every copied artifact maps to its exact Ethan source and digest in
`evidence/two_state_paper_integration_2026_08_02/SOURCE_MANIFEST.csv`.

## Table and figure disposition

Implemented in the manuscript:

1. Complete eight-row aggregate mechanism table.
2. Complete 12-row casewise baseline/area-host/closed-BVP TP/TW/mdot table.
3. Native countercurrent Salt4 profile figure.
4. Regional pressure-leverage figure.

Useful but intentionally not promoted as additional main-text figures:

- a sensor-direction heat map would duplicate the new text and CSV;
- a boundary-mixing residual plot is unnecessary with only four monotone rows;
- prospective high-heat, RAF/RMF, distributed-pressure, and insulation plots
  must wait for terminal, admitted, no-refit evidence.

## Reproducibility statement

The canonical source scripts are
`tools/analyze/run_two_state_predictivity_campaign.py` and
`tools/analyze/analyze_two_state_predictivity_campaign.py` in the sibling
Ethan workspace.  The frozen contract records script SHA-256 digests.  Runtime
step `3327556.29` used node `c318-008`, 68 one-core ranks, and completed in
6 minutes 6 seconds.  The analysis reproduced the rigorous decision and key
CSV hashes deterministically.  The manuscript compact package is evidence,
not a second executable campaign or a source of new fitted parameters.

## Pending author and terminal decisions

- Whether the two-state section remains in the main chapter or moves to a
  methods/results appendix is an author layout choice; the current placement
  keeps the negative mechanism visible.
- The predeclared high-heat and insulation rows remain sealed until their own
  stationarity, source, pressure, RAF/RMF, and same-QOI uncertainty gates pass.
- No manuscript wording should call the two-state state calibrated,
  validated, predictive physics, or admitted before those gates close.
