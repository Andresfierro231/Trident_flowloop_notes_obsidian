# Localized-model heat-path attribution report

## Purpose

The localized full-insulation model improves TP and TW substantially, but a
temperature score does not establish that the model removes heat through the
same physical paths as CFD.  This audit compares the solved heat ledgers and
the four-junction spatial distribution for the nominal Salt1--Salt4 cases.

## Comparison contract

The aggregate comparison uses three heat-removal attributions shared in
concept by both descriptions:

1. active cooling-jacket removal;
2. ordinary ambient loss; and
3. CFD junction/stub loss versus the model's added local junction terms.

For the four-junction comparison, the model junction-region total includes the
ordinary intact-insulation loss of each one-inch junction host plus its local
setup-derived and fitted conductance terms.  The mapping follows the declared
counterclockwise loop order:

| Model parent | Physical junction |
|---|---|
| `bottom_horizontal_exit` | lower left |
| `bottom_horizontal_inlet` | lower right |
| `top_horizontal_inlet` | upper left |
| `top_horizontal_exit` | upper right |

The aggregate CFD values are final-ten-saved-time means.  The Salt1
four-junction split uses those same ten saved times and closes to its aggregate
within numerical output precision.  The retained Salt2--Salt4 splits use
separate terminal wall-flux samples and sum to within 0.5% of their
corresponding final-ten aggregates.

The heater and test-section entries are deliberately excluded from direct
error statistics.  The localized ledger records the imposed heater source and
the fixed 37-W test source, while CFD reports realized heater-to-fluid transfer
and signed net test-section wall exchange.  Those are not the same quantities.

## Aggregate result

For the low-resistance localized model, the case ranges and mean ratios are:

| Attribution | CFD range (W) | Localized range (W) | Mean model/CFD |
|---|---:|---:|---:|
| Active cooler | 135.6--169.2 | 19.5--25.7 | 0.152 |
| Ordinary ambient | 53.2--75.9 | 98.7--135.4 | 1.797 |
| Junction-region total | 34.2--48.5 | 151.5--214.1 | 4.406 |

The corresponding attribution MAPEs are 84.8%, 79.7%, and 340.6%.  These
statistics quantify disagreement between attribution ledgers; because the
patch footprints and source definitions differ, they must not be reported as
formal component-validation errors.

The junction decomposition explains the large model total.  The fixed
setup-derived term, \(G_J\), removes 15.5--22.0 W and averages 0.452 times the
entire CFD junction/stub loss.  The fitted residual term, \(G_B\), removes
135.5--191.5 W and averages 3.941 times the CFD junction/stub loss.  Together,
\(G_J+G_B\) remove 151.0--213.4 W, or 4.393 times the CFD junction/stub loss.
Thus the residual term, not the setup-derived junction term, controls the
localized model's junction-region heat removal.

Normalizing the three attribution buckets gives the clearest statement of
where the two descriptions place heat:

| Share of three compared sinks | CFD, Salt1--Salt4 | Localized, Salt1--Salt4 |
|---|---:|---:|
| Cooler | 57.4--60.8% | 6.9--7.3% |
| Ordinary ambient | 23.8--26.2% | 36.2--36.7% |
| Junction/local | 15.3--16.5% | 56.1--57.0% |

The model therefore reproduces the measured temperature field while moving
most of its attributed heat removal from the cooling jacket into the fitted
local conductance and ordinary ambient paths.  This is evidence of remaining
thermal compensation, not validated heat-path localization.

Changing only the hydraulic multiplier does not repair the attribution.  For
the \(\alpha_R=1.10\) CFD-flow comparator, the mean model/CFD ratios are 0.156
for the cooler, 1.853 for ordinary ambient, and 4.305 for the junction-region
total.  The conclusion is therefore not an artifact of choosing the
low-resistance hydraulic setting.

## Four-junction distribution

The Salt1--Salt4 CFD split is stable across cases.  On average it assigns
19.7% to the lower-left group, 19.5% to lower right, 24.7% to upper left, and
36.1% to upper right.  The low-resistance localized model assigns 25.8%,
24.4%, 24.9%, and 25.0%, respectively.  Relative to CFD, it shifts about 6.1
percentage points into lower left, 4.8 points into lower right, and 11.1
points out of upper right.  Its mean total-variation distance from the CFD
four-junction distribution is 0.111.

This near-quartering is an expected consequence of assigning one quarter of
both conductances to each host and solving similar local outer-wall
temperatures.  CFD instead concentrates loss at the upper-right junction.
The localized formulation therefore does not yet capture the observed
junction-to-junction asymmetry.

## Interpretation for the thesis

The localized model remains useful because it restores full insulation,
separates the setup-derived junction term from one visible residual term, and
improves temperature agreement.  The heat ledger changes how that improvement
must be described: it demonstrates a compact empirical representation of the
temperature field, not a validated spatial heat-loss model.

The next physical improvement should not be another unconstrained fit to TP
and TW.  It should independently constrain cooler duty and junction-region
loss, then allow unequal junction weights or hardware-based conductances only
if those measurements support them.  Until then, \(G_B\) should remain an
explicit residual coordinate rather than a named support, clamp, or fitting
conductance.

## Reproduction and provenance

The controlling compact package is
`evidence/localized_heat_path_audit_2026_08_10/`.  Run:

```bash
python3.11 scripts/analysis/build_localized_heat_path_audit.py
python3.11 scripts/analysis/build_localized_heat_path_audit.py --check
```

The source hashes and logical upstream locations are recorded in
`evidence/localized_heat_path_audit_2026_08_10/SOURCE_MANIFEST.csv`.
