# Current release reports

- `FINAL_REVISION_SUMMARY.md` — current scientific reconciliation and QA summary.
- `SCIENTIFIC_CLAIM_PROVENANCE.md` — decision-level claim, evidence, and limitation routes.
- `FINAL_FIXME_CLOSURE_REGISTER.csv` — all 73 original review comments and final resolution routes.
- `FIXME0_REAUDIT_2026-07-31.md` — concern-by-concern reader-clarity audit of
  all 39 original class-0 comments against the current six-chapter draft.
- `scientific_triage_qa.md` / `.json` — scientific and build triage.
- `build_qa_latest.md` / `.json` — active six-chapter source/build checks.
- `final_qa.md` / `.json` — current 28-check scientific-readiness gate.
- `PDF_VISUAL_REVIEW.md` — human page-render review; supersedes its earlier 75-page version when updated.

Historical cleanup inventories remain provenance records.  They do not imply
that every historical/support evidence directory was deleted.
