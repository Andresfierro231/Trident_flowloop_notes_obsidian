# Final Scientific-Readiness Revision Summary

Date: 2026-08-04

## Outcome

The active six-chapter thesis has passed a paper-wide scientific-claim
reconciliation, quantitative source audit, clean LaTeX/BibTeX build, automated
release checks, and review of the rendered 140-page PDF.  The final title is
*CFD-to-1D Model Reduction for Molten-Salt Natural-Circulation Loops: Local
Closure Identification and Retrospective Model Assessment*.

The review did not convert the current candidates into prospectively validated
models.  P1, P2-exp, P2-CFD, the two-state model, and the localized conjugate
variants remain objective-specific model-development results assessed on
reused or split-designated retrospective CFD cases.  Target-informed choices
and conditional sensor policies are disclosed where they affect interpretation.

## Principal scientific reconciliations

- Corrected the declared circulation path and aligned the loop, sensor, and
  segment descriptions.
- Distinguished current 1D test-section geometry (0.835-in ID, 0.943-in OD)
  from the approximately 20.94-mm CFD mesh bore and from unresolved
  survey-grade facility geometry.
- Described the CFD as a fluid PIMPLE calculation with resistance-layer
  external-temperature boundary conditions, not a demonstrated conjugate
  multi-region CHT solve.
- Kept three reduction time bases distinct: 300 s for TP/TW/mass-flow
  stationarity, final ten saved times for the energy ledger, and final five
  saved times for the pressure ledger.
- Defined the independent pressure ledger on its plane-sampled area-density
  and mass-flux basis.  Its mechanical term is an identity-inferred
  positive-sense remainder, not measured wall shear or a fitted component
  coefficient.
- Retained the direct pressure perturbations as within-model local
  sensitivities used to prioritize observations, not physical attribution or
  validation of component losses.
- Incorporated the nonlinear heat-path compensation and practical local-rank
  study as evidence that several thermal parameters can compensate one
  another; it does not uniquely identify those parameters.
- Incorporated the localized conjugate full-insulation result as the
  lower-error tested model form on the reported cases, while avoiding a claim
  that its physical explanation or coefficients are uniquely established.
- Replaced the earlier Salt2 “superconvergent” and 0.51% GCI language with the
  later quantity-specific audit.  Different physical times and mesh-specific
  one-cell masks prevent a formal three-grid GCI for these local quantities.
- Defined the exchange mass-flow proxy as one-way positive outward flux from
  the wall-adjacent seeded volume to neighboring core cells.  It is not net
  loop mass flow or a fitted exchange coefficient.
- Stated explicitly that the medium and fine cases do not enter the primary
  model-error comparisons or coefficient fits.  They provide only a local
  upcomer diagnostic: the available medium--fine differences are 0.503% for
  wall duty, 95.499% for the exchange-flow proxy, 24.149% for turnover time,
  and 52.908% for adjacent-core temperature contrast.  These values show that
  the latter proxy magnitudes are mesh-sensitive; they do not establish that
  the physical recirculation changed between grids.

## Score-policy reconciliation

The primary policy includes TP1--TP6 and omits TW10 because the operational
model has no matched shell state.  TW4--TW6 are also omitted under a
development-time reporting/model-selection choice made after residuals
existed; they are not declared invalid sensors.

The 9--10 K balanced headline is therefore conditional.  Restoring TW4--TW6
while retaining the TW10 exclusion changes balanced RMSE as follows:

| Candidate | Nominal primary | Nominal restored | Retrospective primary | Retrospective restored |
|---|---:|---:|---:|---:|
| P1 | 9.280 K | 14.551 K | 9.354 K | 14.381 K |
| P2-CFD | 9.602 K | 14.848 K | 9.710 K | 14.699 K |

These values are recomputed directly from the retained sensor-level rows by
the final-readiness QA script.  The P1/C6 numerical lead is labeled unresolved
at the precision implied by the reference standard errors.

## Current chapter structure

1. **Introduction and Research Objectives**
2. **Thermal-Fluids Formulation and CFD-to-1D Reduction**
3. **TAMU Loop, CFD Reference, and Modeling Targets**
4. **Complete One-Dimensional Model Definition**
5. **Model Assessment, Mechanism Analysis, and Limitations**
6. **Conclusions, Limitations, and Future Work**

The nomenclature, air-property-correlation, and loop-segment appendices follow
the six chapters.

## Evidence and provenance

`evidence/RETAINED_EVIDENCE_MANIFEST.csv` is the deterministic manifest for the
compact controlling packages.  `reports/SCIENTIFIC_CLAIM_PROVENANCE.md` and
`evidence/CLAIM_SOURCE_MANIFEST.csv` provide the decision-level routes for
current claims.  The controlling uncertainty source is the retained
`s13_uncertainty_disposition_2026_07_31` package; the earlier July 23
superconvergence interpretation is historical and does not control the active
manuscript.

## Final verification

- Full build and scientific triage: PASS, 16/16 blocking checks.
- Source/build QA: PASS.
- Final scientific-readiness QA: PASS, 28/28 checks.
- Review-comment closure register: 73/73 rows resolved with active paths.
- Citations/references, duplicate labels, missing graphics: zero failures.
- LaTeX warnings, overfull boxes, oversized floats, and hard errors: zero.
- PDF: 140 pages with current title/author metadata.

Build and verify with:

```bash
bash scripts/compile_and_qa.sh
```
