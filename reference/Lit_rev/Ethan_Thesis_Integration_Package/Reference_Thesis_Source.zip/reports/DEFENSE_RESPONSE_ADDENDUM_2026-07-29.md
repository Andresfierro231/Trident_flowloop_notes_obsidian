# Defense-response addendum

Date: 2026-07-29

This addendum gives concise answers for the scientific limitations most likely
to be challenged in a defense. It supplements, but does not supersede, the
retained evidence packages and the current manuscript.

## Why are P1 and P2-CFD both reported instead of one “best” model?

They optimize different objectives. P1 is the numerical minimum for the
declared balanced TP/TW score: 9.280 K nominally and 9.354 K on the
split-designated retrospective perturbations. With the later no-refit nominal
Salt1--Salt4 target refresh, its CFD mass-flow MAPE is 43.266% nominally and
43.846% on the perturbations. P2-CFD uses a target-informed distributed-loss multiplier
and reduces CFD mass-flow MAPE to 3.538% and 3.409%, while balanced temperature
error rises to 9.602 and 9.710 K. The different leaders reveal compensation
between residence time, buoyancy, hydraulic resistance, and heat removal.
Reporting both is more informative than hiding the tradeoff in one composite
score.

## Why is the Salt2 perturbation set called a retrospective holdout?

The final grading pass did not refit the selected candidate on the two
perturbations, so they test local no-refit robustness. However, their outcomes
had been encountered during earlier development. They are therefore not
pristine or prospective. “Split-designated retrospective holdout” states both
facts and avoids overstating independence.

## What does the global 0.08 insulation-thickness multiplier mean?

It is an empirical reduced-model insulation-thickness compensation, not the
physical 1.40-in CFD insulation. The solver multiplies its base insulation
thickness by 0.08 and then recomputes cylindrical insulation resistance; it
does not multiply the completed resistance by 0.08. The new nominal heat-path
audit makes its effect explicit. P1 has 8.93% heater-channel MAPE, but underpredicts active-cooler
removal by 85.44%, overpredicts ordinary ambient loss by 304.27%, and omits the
34.2--48.5 W junction channel. It produces useful temperatures through
compensating pathways; it does not yet predict where heat is physically lost.

## Is the pressure-ledger mechanical term an irreversible loss?

Only under an additional fully recovered, effectively one-dimensional
interpretation. The retained CFD ledger defines

\[
L_{\mathrm{mech}}
=-\left(\Delta p_{\mathrm{rgh}}+B_\rho+I\right).
\]

It is an identity-inferred section residual. It is not directly sampled wall
shear, entropy generation, or an admitted friction/minor-loss coefficient. In
the 24 nominal span means it is positive and ranges from 1.049 to 7.609 Pa.
Bulk dynamic-head and inertial corrections remain below 0.002 Pa, while the
density-gradient term is materially larger. Recovery-plane placement,
recirculation, and missing same-QOI mesh evidence prevent conversion of the
lower-right remainder into a component coefficient.

## Why are TW4--TW6 omitted from the headline score?

The exclusion is a development-time reporting/model-selection choice, not a
finding that those channels are invalid. Restoring TW4--TW6 while retaining
the unmatched TW10 exclusion raises P1 balanced error from 9.280 to 14.551 K
nominally and from 9.354 to 14.381 K retrospectively. The restored values are
reported so the headline cannot be read independently of the policy.

## Has a final predictive physical candidate been frozen?

No closure-qualified Salt1--Salt4 candidate has passed the complete
source/property, numerical, split, and uncertainty chain. P1 can be executed
from setup inputs and can be preserved as a versioned retrospective baseline,
but its protected outcomes are already exposed and its global thermal
compensation fails the local heat-path audit. Freezing that baseline would
support future reproducibility; it would not retroactively create prospective
validation or scientific admission.

## What is the defensible thesis claim?

The dissertation establishes a reproducible CFD-to-1D reduction, an operational
coupled solver, objective-specific retrospective grades, and model-form
evidence that localizes the unresolved hydraulic and thermal physics. It does
not establish one independently validated closure set for TP, TW, and mass
flow, nor a universal SAM correlation.

## Evidence routes

- `reports/SCIENTIFIC_CLAIM_PROVENANCE.md`
- `evidence/predictive_model_score_release_2026_07_28/`
- `evidence/independent_total_pressure_ledger_2026_07_28/`
- `evidence/heat_path_prediction_audit_2026_07_29/`
- `evidence/final_presentation_readiness_2026_07_28/`
