# SAM-facing closure recommendation path

Date: 2026-07-29

## Claim boundary

The present work can recommend a component-by-component closure architecture
for a future SAM model. It does not yet provide a validated SAM correlation
set. A transportable coefficient requires a declared pressure/heat definition,
a validity range, uncertainty, frozen inputs, and prospective assessment in an
implemented SAM model.

## What is supportable now

| Physical role | Recommended starting representation | Present evidence status |
|---|---|---|
| Smooth, fully developed laminar pipe | Darcy \(f_D=64/Re\), with local properties | Literature reference and diagnostic baseline; it under-represents some CFD apparent losses |
| Short or reset laminar development | Shah-style apparent friction, applied only where a physical reset and parent development length are declared | Best current literature-backed hydraulic baseline; not a universal loop multiplier |
| Bends, reducers, connectors, and junctions | Separate component \(K\) terms at matched recovered planes | Architecture recommendation only; present local-\(K\) extractions are not admission-ready |
| Recirculating upcomer | Throughflow component plus exchange/mixing or a regime-validity flag | Required by the observed reverse-flow topology; no ordinary one-stream \(f_D\), \(Nu\), or \(K\) is admitted |
| Ordinary passive thermal spans | Explicit internal convection, wall/insulation resistance, external convection, and radiation | Model-form recommendation; local heat-path audit shows current magnitudes still compensate |
| Heater | Setup power times an explicitly documented realization efficiency | Runtime-legal form; efficiency remains facility/model specific |
| Cooler | Explicit cooler component or effectiveness--NTU model with setup-side inputs | Appropriate architecture; current P1 cooler duty is underpredicted and is not a validated component correlation |
| Test section and junctions | Separate source/loss roles rather than ordinary ambient pipe loss | Supported as a bookkeeping requirement; coefficient transfer remains blocked |

The central recommendation is therefore a **closure ledger with validity
metadata**, not a single global friction or heat-loss correction.

## Effort and evidence needed

### One to three days: thesis-grade recommendation package

Produce a per-component SAM input matrix containing the equation, parameter
source, units/convention, validity range, fallback, uncertainty status, and
blocked conditions. This is low risk and uses evidence already assembled. It
would strengthen the thesis but would not create a new correlation.

### One to two weeks: facility-specific correlation prototype

Fit legwise hydraulic or thermal correction surfaces using only admissible
training rows, quantify parameter covariance and bootstrap uncertainty, freeze
the forms, and assess them on genuinely untouched cases. This can yield a
TAMU-loop-specific prototype. It should not be advertised as a general molten
salt correlation because the nominal range is narrow and the upcomer remains
recirculation dominated.

### One to three months or more: defensible SAM correlation and validation

Broaden the design space in \(Re\), \(Pr\), \(Ri\), power, boundary conditions,
and geometry; obtain stationary CFD/experimental anchors with matched pressure
planes and same-QOI mesh/time uncertainty; establish nonrecirculating and
recirculating regime anchors; implement the component in SAM; freeze the SAM
inputs; and perform prospective scoring. This is the minimum credible route to
a correlation intended for reuse outside this facility.

## Why a new global friction correlation is not yet defensible

- The useful operating range is small and several nondimensional groups are
  strongly correlated, so a fitted exponent can look precise without being
  identifiable.
- Material upcomer reverse flow invalidates an ordinary single-stream pipe
  interpretation.
- Component-isolated recovered pressure planes and same-QOI uncertainty are
  incomplete for the local features.
- The attempted buoyancy/Richardson correction did not validate, and the
  proposed Reynolds correction remains blocked rather than admitted.
- The current best temperature model contains thermal compensation: agreement
  in TP/TW does not prove that local heat-loss ownership is correct.

## Recommended next low-cost study

Run a closure-ablation/sensitivity study on the already frozen retrospective
baseline: perturb the heater efficiency, cooler model, ordinary ambient loss,
junction role, and each hydraulic leg class one at a time, then report the
Jacobian of TP, TW, and mass flow. This would directly show which closure
compensations drive the P1/P2 tradeoff and would be more valuable than fitting
another unconstrained global multiplier.

## Evidence routes

- `reports/SCIENTIFIC_CLAIM_PROVENANCE.md`
- `evidence/heat_path_prediction_audit_2026_07_29/README.md`
- `reports/DEFENSE_RESPONSE_ADDENDUM_2026-07-29.md`
- Ethan evidence map: `operational_notes/maps/friction-closures.md`
- Ethan SAM-facing synthesis:
  `reports/thesis_dossier/Chapters_and_sections/current/11_sam_facing_interpretation.md`
