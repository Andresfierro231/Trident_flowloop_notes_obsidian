# Moser Feedback Closure

Date: 2026-08-02

This report maps each reviewer concern to the current manuscript correction
and its verification evidence.  It is an audit aid; the thesis chapters remain
the authoritative reader-facing text.

| Reviewer concern | Manuscript correction | Verification |
|---|---|---|
| Unusual or uninformative vocabulary | Replaced workflow metaphors such as *genealogy*, *ledger*, *score*, and *screen* with model definition, mechanical balance, error metric, comparison, or sensitivity test according to the underlying meaning.  Chapter 1 now introduces physical logic before model identifiers. | `scripts/check_terminology.py` scans every active reader-facing TeX file and rejects those terms, plus related workflow terms (`contract`, `runtime`, and `target-free`) except the legally correct phrase “Contract No.” in the acknowledgments. |
| CFD mathematical definition was incomplete | Chapter 3, “Complete CFD model definition,” now collects continuity, momentum, Newtonian stress, sensible-enthalpy energy, and reduced-pressure equations; laminar/Fourier constitutive choices; initial and boundary conditions; wall, heater, test-section, and cooler thermal models; and mesh, time integration, spatial schemes, PIMPLE settings, linear solvers, and tolerances. | Equations `eq:cfd-continuity`--`eq:cfd-prgh-definition`, Table `tab:cfd-boundary-definition`, and the spatial/temporal-discretization subsection.  Sources: OpenFOAM 13, Weller et al., Moukalled et al., and Rozak et al. |
| 1D model could not be independently reimplemented | Chapter 2 now gives all fluid, solid, insulation, and air-property expressions and the complete ordered geometry including each elevation change.  Chapter 4 is retitled “Complete One-Dimensional Model Definition” and collects the finite-cell energy equation, radial wall boundary, PASSIVE-H2 boundary inputs, cooler, buoyancy and pressure closures, local-loss formulas, two-state equations and boundary conditions, root searches, tolerances, acceptance criteria, model-specific parameters, sensor projections, and metrics.  A single reimplementation table routes every model element to its equation and source. | Table `tab:ch4-reimplementation-map`; Tables `tab:ch4-segment-sequence`, `tab:air-property-coefficients`, `tab:ch4-model-definitions`, and `tab:two-state-parameter-definition`; Algorithm 1; Eqs. `eq:model-cell-enthalpy-balance`--`eq:model-root-acceptance`. |
| Citations were inconsistent | Added citations at the point of use for conservation/discretization, OpenFOAM formulation, property origins, nondimensional definitions, Darcy/Shah/Hagenbach pressure relations, cylindrical resistance networks, natural convection, and effectiveness--NTU cooling.  Thesis-specific fits are explicitly labeled as such rather than attributed to literature. | Active bibliography QA resolves every cited key and reports no duplicate active keys, duplicate DOI/title records, or unsupported entry types. |
| Logic and purpose were obscured by detail | Chapter 1 now states the evidence hierarchy and four-step analysis before any internal model label.  Chapter 3 proceeds from input definition to case qualification to physical requirements.  Chapter 4 proceeds from common equations and numerics to model-specific changes and data use.  Chapter 5 uses model change → error change → physical interpretation, with negative results and uncertainty limits retained.  Chapter 6 answers the research questions in the same order. | Chapter roadmaps, the reimplementation map, the model/data-use table, the expected-effects table, and the final claim/limitation table. |

## Claim-to-evidence routes

- CFD setup and equations: Chapter 3; `evidence/CLAIM_SOURCE_MANIFEST.csv`;
  `evidence/UPSTREAM_SOURCE_LOCATOR_MANIFEST.csv`; upstream OpenFOAM case
  dictionaries and Rozak et al.
- 1D implementation: Chapters 2 and 4;
  `evidence/one_d_physics_solver_description_2026_07_28/README.md`; upstream
  `tamu_loop_model_v2` source files resolved through the locator manifest.
- Nominal and retrospective TP/TW/mass-flow results: Chapter 5;
  `evidence/predictive_model_score_release_2026_07_28/`.
- Two-state equations, complete casewise results, negative mechanisms, and
  numerical limits: Chapters 4--6;
  `evidence/two_state_paper_integration_2026_08_02/`.
- Active figure inputs and regeneration: `evidence/FIGURE_SOURCE_MANIFEST.csv`.
- Pressure-demand identity, no-double-counting classes, leverage, and limits:
  Chapters 1--6; Figures 3.4 and 5.4; Tables 3.7 and 5.6;
  `evidence/pressure_demand_ledger_v2_2026_08_03/`.

The paper retains the central limits: the Salt2 perturbations are
retrospective rather than blinded; P2-CFD is target-informed; the global 0.08
insulation-thickness factor is empirical; no leading model is independently
validated; and matched three-grid uncertainty is unavailable for reported TP,
TW, total mass flow, and ambient loss.

## Citation consistency audit

The closeout audit covered all active TeX includes and both active BibTeX
resources, not only the newly edited paragraphs.

- 137 active bibliography records and 45 cited keys were parsed.
- All 137 records have the fields required by their entry type, four-digit
  years, valid bare DOI syntax where a DOI is present, and unique keys under a
  case-insensitive comparison.
- The active resources contain no duplicate key, DOI, or normalized title; no
  unsupported entry type; no BibLaTeX-only field; and no unresolved cited key.
- Active prose uses 50 `\\citep`, five `\\citet`, and one `\\citeauthor`
  command.  It contains no ambiguous plain `\\cite` command.
- The Dittus--Boelter equation now cites Dittus and Boelter plus the VDI Heat
  Atlas rather than Sieder and Tate.  The Carson DOI was normalized from a URL
  to a bare DOI, and two internal source-use notes were removed from the
  reader-facing bibliography.
- Point-of-use review corrected the Chapter 1 locally developing/mixed-flow
  support to duct-development and mixed-convection sources and normalized the
  parenthetical citation forms in Chapters 2--3.

## Validation record

`bash scripts/compile_and_qa.sh` passes: 16/16 focused scientific checks,
28/28 final-readiness checks, clean LaTeX/BibTeX logs, and a 125-page PDF.
`git diff --check`, `scripts/check_bibliography.py`, and
`scripts/check_terminology.py` pass.  Rendered pages 42--43, 51--52, 54,
59--60, 67--68, and 95--96 were visually reviewed for the CFD definition,
pressure balance, 1D definition/reimplementation map, coupled pressure secant,
and pressure leverage; no clipping, malformed float, or illegible table was
found.
