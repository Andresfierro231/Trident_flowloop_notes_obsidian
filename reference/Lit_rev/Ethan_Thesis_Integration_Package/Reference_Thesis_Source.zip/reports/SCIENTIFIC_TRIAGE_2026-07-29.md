# Scientific triage — 2026-07-29

## Purpose

This pass reconciles the highest-risk scientific presentation issues in the
five-chapter dissertation without changing the solver, model parameters,
sensor policy, or frozen scores.

## Controlling evidence

- `evidence/predictive_model_score_release_2026_07_28/`
- `evidence/independent_total_pressure_ledger_2026_07_28/`
- `evidence/cfd_run_matrix_2026_07_28/`
- `evidence/thesis_tw_scoring_policy_2026_07_28/`

The physical-model score policy includes TP2 and excludes TW4--TW6 and TW10.
Salt1--Salt4 are nominal model-development cases. Salt2 -5% and +5% heater
power are a split-designated retrospective holdout whose CFD outcomes had been
encountered during earlier exploratory work.

## Changes in this pass

- P1 is identified as the temperature-leading compensated forward model.
- P2-CFD is identified as a CFD-mass-flow-target-informed calibrated
  comparator, not independent hydraulic validation.
- The affine map is retained as a secondary historical discrepancy benchmark,
  not a co-equal physical prediction path.
- The unresolved global 0.08 insulation-thickness compensation is stated at
  the headline result locations; it is applied before cylindrical resistance
  is calculated.
- Sensor-level temperature parity and mass-flow trend figures are generated
  from the frozen score release and restricted to decision-relevant candidates.
- The stored-OpenFOAM-`p_rgh` momentum ledger and its claim boundaries are made
  reader-facing.
- TP2's exact CFD coordinate and exact named 1D station are documented.

## QA boundary

`bash scripts/compile_and_qa.sh` is the blocking manuscript/scientific gate for
this pass. It rebuilds the PDF and validates the active five-chapter source,
frozen score values and populations, figure provenance, TP2 route, pressure
basis, and claim-status language.

The following pre-existing repository issues remain deferred and must not be
reported as passing:

- the evidence tree contains packages outside the retained-package manifest;
- the historical 73-row FIXME register contains stale chapter routes;
- prior final-cleanup and repository-size claims do not describe the current
  Git tree.

This triage is therefore suitable for another scientific writing review, but
it is not the final repository-cleanup release.
