# FIXME(0) reader-clarity re-audit

Date: 2026-07-31

Audited thesis commit: bb915ae plus the local clarifications identified below

Historical register: FIXME_PRIORITY_CLASSIFICATION_2026-07-31.csv

## Result

All 39 original class-0 concerns remain substantively addressed in the current
six-chapter draft. This audit tested the concern behind each comment against
the prose a reader now encounters; disappearance of the marker was not treated
as proof of resolution.

Three resolutions were strengthened during the re-audit:

- ID 40: replaced the two residual uses of “children” with the already defined
  numerical term “subsegments”;
- ID 43: distinguished the general Shah--London developing-duct source from
  the separate 1978 Shah correlation used explicitly by the next candidate;
- ID 68: defined numerical root acceptance at its first occurrence in the
  assessment chapter and separated it from scientific agreement.

## Concern-by-concern crosswalk

### Chapter 2: formulation and reduction

| ID | Original concern | Current reader-facing resolution | Verdict |
| --- | --- | --- | --- |
| 1 | Missing citations near the coupled balances | The mass, momentum, and energy coupling is introduced with natural-circulation citations in “Coupled natural-circulation balances.” | Pass |
| 3 | Identify which terms are manipulated | The opening balance discussion states that conservation equations remain fixed and names the five closure/boundary choices that candidates change. | Pass |
| 5 | Clarify whether the wall-heat operator is the ambient term | “Wall heat and control-volume energy reduction” distinguishes the generic wall-set integral from ambient, heater, cooler, test-section, junction, and exchange terms. | Pass |

### Chapter 3: CFD evidence and modeling targets

| ID | Original concern | Current reader-facing resolution | Verdict |
| --- | --- | --- | --- |
| 10 | Explain the TP2 topology note | “Loop geometry, materials, and measurements” gives the coordinate, named 1D boundary, intervening connector, and physical conclusion in ordinary prose. | Pass |
| 13 | Clarify what moved in the TP2 sensitivity | The sensitivity subsection states that only the temperature sampling location changed; the model parameter, source, and loss location did not. | Pass |
| 14 | Replace undefined “station” terminology | TP2 is described as a sensor, location, point, mapping, or projection; “station” is not used for this comparison. | Pass |
| 15 | Replace “falsification check” | The passage now calls the calculation a projection sensitivity and states its question directly. | Pass |
| 16 | Explain why the retained TP2 location matters | The subsection concludes that the alternate mapping worsens all residuals, retains the geometry-backed location, and keeps TP2 in aggregate scores. | Pass |
| 17 | State which models use each data split | “Primary cases and evidence split” lists all nine forms, Salt1--Salt4 as development cases, and the unchanged-coefficient perturbation evaluation. | Pass |
| 21 | Interpret the stationarity table | The text identifies the limiting SEM and drift, compares them with model-error scale, and says what stationarity does and does not qualify. | Pass |
| 22 | Separate reverse-flow and backflow quantities | “Regime evidence” defines reverse-flow area as area based and backflow fraction as transport weighted, and warns against combining their ranges. | Pass |
| 25 | Define “final ten saved time steps” | “Thermal evidence” identifies ten stored CFD output times, gives example seconds, and distinguishes this window from the 300-s and five-output windows. | Pass |
| 26 | Explain the test-section correction claim | The test-section exchange is shown to change sign and magnitude, so the prose explains why a constant scalar correction cannot represent it. | Pass |
| 27 | Use conventional language for pressure sampling | The pressure audit now refers to cross-sections placed away from bends, connectors, and fitting faces. | Pass |
| 28 | Interpret the dynamic-head ratio | The text converts 0.226% into the direct conclusion that bulk acceleration changes the span result by less than 0.23% and cannot control it. | Pass |
| 29 | Explain the physical correction | The density-gradient term is defined, placed on the pressure ledger, compared in scale with dynamic head, and tied to temperature and elevation. | Pass |
| 30 | Replace “five-times mean” | The result is described as a mean over the final five saved CFD output times for each case and span. | Pass |
| 31 | Make the pressure table legible | The table uses footnote-size type, two panels, and explicit bracketed [minimum, maximum] intervals. | Pass |
| 33 | Clarify what the pressure ledger can establish | The text states that recovery-region planes cannot identify Darcy friction or a local-loss coefficient and that a signed remainder is not negative dissipation. | Pass |
| 34 | Explain fixed-condition development work | “Modeling targets” distinguishes prescribed-mass-flow and imposed-duty component studies from the fully coupled scored solve. | Pass |
| 35 | Replace “genealogy” | The reader-facing transition uses “candidate progression”; the old term survives only inside an internal LaTeX label. | Pass |

### Chapters 4 and 5: methodology and assessment

| ID | Original concern | Current reader-facing resolution | Verdict |
| --- | --- | --- | --- |
| 37 | Replace “genealogy” in the model story | Chapter 4 consistently presents a “candidate progression” with descriptive model names and archival IDs. | Pass |
| 40 | Define “children” and the discretization units | The numerical architecture defines physical parents and numerical subsegments; the two remaining visible “children” usages were changed to “subsegments.” | Pass—strengthened |
| 41 | Explain where omitted closures enter | The segment energy equation retains separate axial-mixing and recirculation-exchange terms and explains why neither is hidden in Nu or friction. | Pass |
| 42 | Rewrite the developing-pressure introduction | “Hydraulic forms” first defines the fully developed reference, then separately explains the inherited Hagenbach entry increment and Shah apparent friction. | Pass |
| 43 | Reconcile the Shah citations | The prose now states that Shah--London supplies general developing-duct context, whereas Shah (1978) supplies the explicit correlation used by the second candidate. | Pass—strengthened |
| 44 | Cite the Shah apparent relation | The relation is cited directly to shah1978 immediately before its coordinate and equation. | Pass |
| 46 | Define a pressure remainder | It is defined in pascals as required demand minus defensibly assigned straight-pipe and isolated-local contributions, with explicit interpretation limits. | Pass |
| 47 | Define the exchange coefficient | Hmc-prime is defined as main-stream/cell coupling conductance per axial length, with units, sign, equations, and the reason its operational value is zero. | Pass |
| 49 | State exactly what changes from C5 to C6 | The methodology names the two thermal switches and explicitly lists the unchanged pressure form, loss multiplier, and thermal compensation. | Pass |
| 51 | Define and justify empirical factors | The 0.08 thickness factor and hydraulic multipliers are separated, their mathematical effects are stated, and they are labeled model-development choices rather than physical measurements. | Pass |
| 55 | Explain P3/P4 and section-map terms | The candidate table and following prose define the section map, junction/stub term, and P3/P4 roles as negative-control ablations. | Pass |
| 57 | Reduce table precision | The nominal primary score table displays three significant digits and notes that full precision remains in the source scorecard. | Pass |
| 59 | Define the baseline and model differences | The reader-facing candidate matrix places pressure, thermal treatment, loss multiplier, heater fraction, and junction term side by side. | Pass |
| 61 | State the rationale and expected response | The expected-effects table predicts the direction of each controlled transition before Chapter 5 reports the observation. | Pass |
| 62 | Explain “imported junction/stub heat loss” | The term is defined as a separate sink assembled from external-boundary operator rows for connector and stub surfaces, not as pressure loss. | Pass |
| 63 | Reduce unnecessary precision in eta-h | The methodology and candidate table use 0.9897, while the source record retains greater precision. | Pass |
| 64 | State junction-term and heater-factor provenance | The text records Salt2--Salt4 availability for junction/stub rows and identifies eta-h as a prior Salt2 residual scalar, not a measured efficiency. | Pass |
| 68 | Explain “accepted roots” | At first use in Chapter 5, numerical acceptance now means both nested roots converged, properties remained valid, and residual checks passed; it explicitly does not imply agreement with CFD or experiment. | Pass—strengthened |

## Remaining scope

The six surviving FIXME(2) comments request new figures, data, or studies.
They are outside this prose-clarity audit and remain intentionally visible.
No FIXME(0) or FIXME(1) marker remains in the active manuscript.
