# Chapters 4--6 editorial-marker resolution

Date: 2026-08-06  
Baseline: `69a33d3`  
Scope: `chapters/04_reduced_model_methodology.tex`,
`chapters/05_model_assessment_and_interpretation.tex`,
`chapters/06_conclusions.tex`, and the new reconstruction appendix.

The baseline contained 21 editorial markers in Chapter 4 and none in Chapters
5 or 6. A final source-wide check found four older markers in Chapter 3; those
were also resolved so the active thesis has no unresolved markers. Each marker
was removed only after the requested clarification was written. The table
below records the one-to-one Chapter 4 resolution.

| # | Original issue | Resolution | Evidence location |
|---:|---|---|---|
| 1 | Passive-boundary subsection needed a full rewrite | Recast it around generic versus setup-specific heat loss | Ch. 4, “Passive heat loss and active heating and cooling” |
| 2 | Difference and use of the passive-boundary equation were unclear | Stated that it recalculates heat loss from the model wall temperature and never imposes CFD heat | Ch. 4, Eq. `model-passive-h2-row` discussion |
| 3 | A boundary input was incorrectly called a closure model | Defined it as a boundary-input record, separate from conservation and heat-transfer relations | Ch. 4, passive heat-loss opening |
| 4 | Degrees of freedom in the passive treatment were unclear | Listed the allowed model choices and stated that allocation and coverage are fixed during a solve | Ch. 4, paragraph after Eq. `model-passive-h2-row` |
| 5 | Symbols r, g, and c and the word “row” were unclear | Defined r as a record, i as a cell, g as the allocation fraction, and c as the fixed coverage multiplier | Ch. 4, paragraph after Eq. `model-passive-h2-row` |
| 6 | Cooler manipulation was unclear | Stated the baseline value and the three component-test changes: multiplier, imposed duty, or cooler off | Ch. 4, cooler subsection closing paragraph |
| 7 | Parent/child discretization language was confusing | Replaced reader-facing usage with physical section and numerical cell | Ch. 4, geometry, thermal, and hydraulic sections |
| 8 | Origin and authority of F6 were unclear | Tied it to the Chapter 3 CFD pressure reconstruction, Shah reference, narrow Reynolds range, and calibration-only status | Ch. 4, F6 discussion |
| 9 | Upcomer “parent” terminology was confusing | Defined the three physical upcomer sections and their numerical cells | Ch. 4, two-stream pressure discussion |
| 10 | One-stream and two-stream notation and citation status were unclear | Defined 1s and 2s, cited vertical-channel reversal literature, and identified the area multiplier as thesis-derived | Ch. 4, Eq. `two-state-area-momentum` discussion |
| 11 | H′, +/−, and upcomer length were undefined | Defined conductance per length, stream signs, and total rising-section length | Ch. 4, exchange-law discussion |
| 12 | Adjustable recirculation quantities were unclear | Identified r, alpha, and chi as between-test settings that are fixed during a solve | Ch. 4, exchange parameterization discussion |
| 13 | Meaning of chi values 0, 0.02, and 0.04 was unclear | Stated that they are three whole-upcomer tests, not three physical locations or an uncertainty interval | Ch. 4, fixed-parameter paragraph and table |
| 14 | Same chi ambiguity remained in the active table | Rewrote the table entry to match the whole-upcomer definition | Ch. 4, Table `two-state-parameter-definition` |
| 15 | Base-solve/exchange sequence was misplaced | Made the sequence an explicit model-definition statement and moved detailed numerics to the appendix | Ch. 4 and App. “Two-stream calculation details” |
| 16 | Model-variant introduction was incomplete | Replaced it with a complete plain-language inventory and purpose statement | Ch. 4, “Compact model matrix and comparison rules” |
| 17 | “Section map” was undefined | Defined it as a section-by-section thermal-boundary assignment and stated the P3/P4 test purpose | Ch. 4, model-matrix introduction |
| 18 | Loss multiplier and heater factor were unclear | Defined exactly what pressure terms the loss multiplier scales and what heater power eta_h scales | Ch. 4, paragraph before model matrix |
| 19 | Junction/stub column and its omission in P models were unclear | Renamed it as a thermal boundary-input record and explained the C5 inclusion and C6/P omission | Ch. 4, model matrix and following paragraph |
| 20 | Recirculation treatment for the model rows was unclear | Stated that all matrix rows use one stream in the coupled solve and that the two-stream test is a separate P1 post-solve calculation | Ch. 4, paragraph after model matrix |
| 21 | Sensor-projection material belonged with results | Moved the TP/TW projection explanation to the Chapter 5 opening | Ch. 5, opening reader guide |

The four Chapter 3 markers were resolved by replacing “final-five-sample”
jargon with “averaged over the last five saved times,” shortening the
recirculation figure caption and discussion, and removing the reverse-flow-area
column from the pressure table while retaining its physical implication in the
surrounding text.

Additional organization work:

- Detailed root-search settings, boundary-record mapping, and the full
  case-by-case two-stream table now appear in the “Model reconstruction
  details” section of `appendix_segment_atlas.tex`.
- Chapter 5 now presents the headline temperature/flow tradeoff first,
  compresses repetitive case narratives, and explains heat-path compensation
  before the final capability statement.
- Chapter 6 now follows four reader questions: answers, contributions,
  limitations paired with needed evidence, and closing perspective.

Validation completed successfully with `bash scripts/build_thesis.sh` and
`bash scripts/compile_and_qa.sh`. The final run passed all 16 scientific-triage
checks, all source/build checks, and all 28 final-readiness checks. The PDF has
128 pages, with no undefined references or citations, missing figures,
duplicate labels, visible placeholders, overfull boxes, or unresolved source
markers. Image content was not opened or visually inspected.
