# Bibliography Sources

The dissertation uses **Natbib with BibTeX** and the `plainnat` style.

Active resources:

- `../references.bib`: dissertation-local records plus the LitRev records
  selected for direct use in the manuscript.
- `litrev_references_bibtex.bib`: generated BibTeX-compatible copy of all
  remaining LitRev records. Keys maintained directly in `../references.bib`
  are excluded automatically so that every work has one active record.

Read-only source snapshot:

- `litrev_references.bib`: an unedited snapshot of the controlling LitRev
  project's `bibliography/references.bib`. It retains BibLaTeX-oriented fields
  and is not loaded directly by the dissertation.

Provenance controls:

- `litrev_imported_keys.csv` records every LitRev key copied into
  `../references.bib`, its source resource, import date, and manuscript use.
- `source_import_register.csv` records hashes and entry counts for the raw
  snapshot, generated derivative, and selected-key manifest.
- Directly imported entries in `../references.bib` are preceded by a provenance
  comment. The controlling LitRev project remains read-only.

Refresh both local LitRev files from a controlling checkout with:

```bash
python3 scripts/import_litrev_sources.py /path/to/LitRev
```

For ordinary builds, `scripts/build_thesis.sh` regenerates the compatible file
from the existing read-only snapshot, excludes selected direct imports, and
refreshes the import register before invoking BibTeX.
