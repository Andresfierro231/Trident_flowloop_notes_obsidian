# HX-20261102 context packet

- Start with `X.Chat/06_hpc_exchange/2026-11-02/01_to_hpc.md`; answer its seven questions using existing evidence only.
- Included maps provide source/version/owner context. Links to original repositories/archives refer to their owners and are not packaged source/code/data. Confirm current HPC paths before reading.
- Copy the response template to a new dated response; do not overwrite earlier messages.
- This packet contains no new scientific results, original raw data or permission to execute scientific work.
