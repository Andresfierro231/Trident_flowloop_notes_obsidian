# Local ↔ HPC research exchange

- Purpose: user-requested written questions and answers exchanged through Box files; preserve context across machines/chats.
- [Question register](QUESTION_REGISTER.md) tracks status; [first request](2026-11-02/01_to_hpc.md) is ready for the HPC researcher.
- Each exchange gets a dated folder. Add sequence suffixes when multiple exchanges share a date; never overwrite an issued request or an incoming response.
- Outgoing: context, exact questions, source locators, evidence limits and expected response format. Incoming: save original reply and supplied files in the dated `incoming/` folder.
- The responder copies [response template](2026-11-02/02_from_hpc_TEMPLATE.md), keeps question IDs and records actual inspected paths/commit/status. Templates are not answers.
- Local reconciliation: after receiving a reply, add a dated follow-up that states what changed, conflicts, evidence read and proposal/source-map updates. Preserve the raw reply separately.
- Status values: prepared → exported → receipt acknowledged → answered/partly answered → reconciled; record actual events, not assumptions about Box sync or chat delivery.
- Current request is prepared/exported as a file bundle; it has not been acknowledged or answered by HPC.
- This exchange does not replace source-repository Git history or authorize operating-data processing, new scientific runs, CFD, experiments or third-party messages.
- If the HPC session cannot access this Box path, the user can transfer the request ZIP and return the written response here; path access must be reported rather than guessed.
