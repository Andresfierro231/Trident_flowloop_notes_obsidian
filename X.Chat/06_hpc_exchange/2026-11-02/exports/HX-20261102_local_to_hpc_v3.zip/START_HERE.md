# HX-20261102 revision 3

- Read `X.Chat/06_hpc_exchange/2026-11-02/01_to_hpc_v3.md`; same seven research questions, still unanswered.
- Proposal/research goals and questions organize the work; the literature supplies sources and answers.
- New: Obsidian note links use vault-root aliases. `80_repository_links/Papers` is a local symlink and is deliberately not bundled. Recreate it per computer if using the maps in Obsidian; source identities and report-member locators remain available as text.
- No repository/code/raw data were copied by this packet. Supersedes revisions1/2.
